export interface ScpiManagementFeeDetails {
  kind: 'geographic_tiers';
  basis: 'HT';
  revenue_basis: 'loyers encaissés';
  euro_zone_percent: number;
  outside_euro_zone_percent: number;
  blended_rate: null;
  source_period: string;
  source_url: string;
  source_page: number;
  source_sha256: string;
}

export interface ScpiRepartition {
  name: string;
  value: number;
}

export interface Scpi {
  metricProvenance?: Record<string, { reference_date?: string; document_period?: string; source_period?: string; source_url?: string; source_page?: number; pdf_sha256?: string; value_numeric?: number; qa_status?: string }>;
  maximusPublicationStatus?: 'certified' | 'published_with_reserves';
  maximusPublicationReservations?: string[];
  maximusDisabledFeatures?: string[];
  id: number;
  name: string;
  sector: 'bureaux' | 'commerces' | 'residentiel' | 'sante' | 'logistique' | 'hotellerie' | 'diversifie';
  geography: 'france' | 'europe' | 'international';
  yield: number;
  /** PGA ASPIM, en %, validée et strictement datée à la même année que le TD. */
  pga?: number;
  pgaYear?: number;
  pgaSourceUrl?: string;
  pgaQaStatus?: string;
  capitalization: number;
  tof: number;
  price: number;
  discount: number;
  // Statut QA de la décote/surcote (issu de la QA métier reconstitution).
  // 'publishable' = fiable et affichable ; 'manual_review' = à vérifier, ne pas afficher comme fiable.
  discountQaStatus?: 'publishable' | 'manual_review' | 'excluded_non_scpi';
  fees: number;
  // RECOVERY-200 : 'zero' seulement pour un 0 % prouvé ; 'unknown'/'not_applicable' ne sont jamais des zéros.
  feesState?: 'value' | 'zero' | 'unknown' | 'not_applicable';
  isr: boolean;
  european: boolean;
  company: string;
  creation: number;
  minInvest: number;
  repartitionSector?: ScpiRepartition[];
  repartitionGeo?: ScpiRepartition[];
  allocation?: number;
  rating?: number;
  isRecommended?: boolean;
  debt?: number; // Ratio d'endettement en pourcentage
  /** Période vérifiée du taux annuel (ex. 2025-RA), distincte du bulletin courant. */
  distributionReferencePeriod?: string;
  /** Période vérifiée du taux d'endettement (ex. 2025-RA). */
  debtReferencePeriod?: string;
  /** Source officielle propre au taux annuel, jamais déduite de la période trimestrielle. */
  distributionReferenceUrl?: string;
  /** Source officielle propre à l'endettement annuel. */
  debtReferenceUrl?: string;
  // Champs supplémentaires depuis le fichier Excel
  delaiJouissance?: number; // Délai de jouissance en mois
  versementLoyers?: string; // Fréquence de versement des loyers (ex: "Trimestriel", "Mensuel")
  dureeDetentionRecommandee?: number; // Durée de détention recommandée en années
  fraisGestion?: number; // Frais de gestion (HT/%) — only when one official flat rate exists
  fraisGestionDetails?: ScpiManagementFeeDetails; // Separate euro/non-euro official tiers
  valeurRetrait?: number; // Valeur de retrait (€)
  /** Documentation du prix de retrait de la période, distincte du prix de souscription. */
  retraitSourceUrl?: string;
  retraitSourcePage?: number;
  retraitReferencePeriod?: string;
  retraitDefinition?: string;
  valeurReconstitution?: number; // Valeur de reconstitution (€)
  valeurRealisation?: number; // Valeur de réalisation (€)
  /** Historique annuel : distinct des contrôles des indicateurs courants. */
  historyStatus?: string;
  historyYearsExpected?: number;
  historyYearsVerified?: number;
  historyStartYearStatus?: string;
  /** Date effective de la valeur de réalisation, distincte de la date du bulletin. */
  valeurRealisationReferenceDate?: string;
  /** Date et qualification de la durée d'engagement locatif assimilée WALB. */
  walbReferenceDate?: string;
  walbDefinition?: string;
  walbSourceUrl?: string; // Bulletin officiel du KPI de durée locative
  distribution?: number; // Distribution par part (€/part)
  nbImmeubles?: number; // Nombre d'immeubles
  nombreAssocies?: number; // Associés de la SCPI, distincts des locataires
  nombreUnitesLocatives?: number; // Unités louables, jamais assimilées aux locataires
  fraisGestionAssiette?: string; // Texte officiel décrivant l'assiette des frais
  sfdr?: string; // Classification SFDR (ex: "Article 8", "Article 9")
  profilCible?: string; // Profil cible (ex: "Profil équilibré", "Profil prudent")
  profilRisque?: number; // Profil de risque de 1 à 7
  // Données locatives extraites des bulletins trimestriels
  nombreLocataires?: number; // Nombre total de locataires
  walt?: number; // Weighted Average Lease Term (en années)
  walb?: number; // Weighted Average Lease Break (en années)
  // Données trimestrielles extraites des bulletins
  collecteNetteTrimestre?: number; // Collecte nette du trimestre (en €)
  nbCessionsTrimestre?: number; // Nombre de cessions du trimestre
  actualitesTrimestrielles?: string; // Actualités trimestrielles (séparées par " | ")
  actualitePeriode?: string; // Période propre au résumé éditorial vérifié
  actualiteDateDocument?: string;
  actualiteSourceDocument?: string;
  actualiteSourceUrl?: string;
  periodeBulletinTrimestriel?: string; // Période du dernier bulletin (ex: "T3 2025")
  dateBulletin?: string; // Date du bulletin (ex: "30/09/2025")
  liquidite?: string; // Situation de liquidité / marché des parts issue des documents sources
  capitalType?: string; // Régime de capital / marché documenté par les sources
  liquidityBasis?: string; // Base certifiée : withdrawal_queue, secondary_market_order_book, etc.
  liquidityRegimeChanged?: boolean; // Changement de régime rendant les séries non comparables
  reconstitutionGate?: string; // Gate de comparabilité prix / valeur de reconstitution
  partsAttenteRetrait?: number; // Nombre de parts en attente lorsque publié
  partsProposeesVente?: number; // Nombre de parts proposées à la vente sur le marché secondaire lorsque publié
  montantPartsAttenteRetraitM?: number; // Montant des parts en attente en M€ lorsque publié
  nbPartsTotal?: number; // Nombre total de parts lorsque publié
  hasWaitingShares?: boolean; // Indicateur structuré dérivé des données officielles
  maximusWarnings?: string[]; // Points de vigilance factuels issus de la base MaximusSCPI
  maximusDataStatus?: string; // Statut de fraîcheur / extraction des données
  maximusSourcePeriode?: string; // Période de la source MaximusSCPI
  maximusSourceDocument?: string; // Bulletin, note d'information ou source officielle utilisée
  maximusUpdateDate?: string; // Date de mise à jour / vérification de la donnée
  maximusLifecycleStatus?: 'normal' | 'dissolution_proposed' | 'liquidation'; // Situation exceptionnelle de la SCPI
  maximusLifecycleNote?: string; // Explication factuelle du statut exceptionnel
  maximusLifecycleSource?: string; // Source officielle ou réglementaire du statut
  actualiteTrimestrielle?: {
    Trimestre?: string;
    Faits_marquants?: string[];
  }[];
}

export type QuickFilterType = 'tous' | 'europeennes' | 'francaises' | 'isr' | 'high-yield';

export type ObjectiveType = 'revenus' | 'capitaliser' | 'diversifier' | 'fiscalite';

export type PurchaseMethod = 'pleine-propriete' | 'nue-propriete' | 'usufruit' | 'credit';

export interface PurchaseMethodInfo {
  id: PurchaseMethod;
  name: string;
  description: string;
  icon: string;
  fiscalAdvantage: string;
  minInvestment: number;
  targetTmi: number[];
  yieldMultiplier: number;
  taxOptimization: number;
}

export interface InvestmentObjective {
  id: ObjectiveType;
  name: string;
  description: string;
  icon: string;
  color: string;
  criteria: {
    minYield?: number;
    maxRisk?: number;
    preferredSectors?: string[];
    preferredGeography?: string[];
    maxSingleAllocation?: number;
  };
}

export interface Filters {
  sector: string;
  geography: string;
  minYield: number;
  minCapitalization: number;
}
