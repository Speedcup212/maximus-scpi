/* ── Types Dossier Client Expert-Comptable ── */

export interface ExpertSimulationSnapshot {
  id: string;
  createdAt: string;
  updatedAt: string;
  label: string;
  inputs: ExpertHoldingSimulationInputs;
  results: ExpertHoldingSimulationResults;
  summary: ExpertSimulationSummary;
}

export interface ExpertHoldingSimulationInputs {
  dossierName: string;
  companyType: string;
  availableCash: number;
  taxableResultBefore: number;
  useReducedCorporateTaxRate: boolean;
  usufruitAmount: number;
  usufruitDuration: number;
  usufruitKey: number;
  grossDistributionRate: number;
  incomeRevaluationRate: number;
  missionFeesEnabled: boolean;
  missionFeesAmount: number;
  missionFeesInputMode: 'fixed' | 'percent';
  missionFeesTaxMode: 'ht' | 'ttc';
  vatRate: number;
  vatRecoverable: boolean;
  missionFeesAccountingTreatment: string;
  // ── TVA holding ──
  holdingVatProfile?: string;
  vatRecoveryRate?: number;
  // ── Comparaison alternative ──
  alternativeType?: string;
  alternativeGrossRate?: number;
  alternativeRateMode?: string;
}

export interface ExpertHoldingSimulationResults {
  fullOwnershipValue: number;
  annualGrossIncome: number;
  annualAmortization: number;
  yearOneTaxableOperationResult: number;
  taxableResultAfterOperation: number;
  corporateTaxWithoutOperation: number;
  corporateTaxWithOperation: number;
  corporateTaxImpact: number;
  yearOneNetCashFlow: number;
  cumulativeNetCashFlow: number;
  averageAnnualNetReturn: number;
  residualCash: number;
  initialEffort: number;
  // ── Champs rétrocompatibles ──
  gainNetAfterUsufructExtinction?: number;
  netEconomicReturnAfterExtinction?: number;
  annualizedSimpleReturnAfterExtinction?: number;
  cashFlowAverageReturn?: number;
  economicInitialEffort?: number;
  recoverableVatAmount?: number;
  nonRecoverableVatAmount?: number;
  // ── Nouveaux champs économiques ──
  economicGainAfterExtinction?: number;
  economicCumulativeNetCashFlow?: number;
  yearOneLaunchNetCashFlow?: number;
  // ── TRI ──
  indicativeIrr?: number | null;
  irrCashFlows?: number[];
  // ── Comparaison alternative ──
  alternativeAnnualNetYield?: number;
  alternativeCumulativeNetIncome?: number;
  alternativeEndingCapital?: number;
  alternativeTotalValue?: number;
  alternativeComparisonSpread?: number;
  // ── Contrôles cabinet ──
  cabinetChecks?: Array<{
    id: string;
    level: 'info' | 'warning' | 'critical';
    title: string;
    message: string;
    category: string;
  }>;
  [key: string]: unknown;
}

export interface ExpertSimulationSummary {
  companyType: string;
  treasuryAvailable: number;
  totalCashEffort: number;
  residualTreasury: number;
  usufruitAmount: number;
  usufruitDuration: number;
  usufruitKey: number;
  grossDistributionRate: number;
  yearOneNetCashFlow: number;
  yearOneTaxImpact: number;
  averageAnnualNetYield: number;
  cumulativeNetCashFlow: number;
  gainNetAfterUsufructExtinction?: number;
  annualizedSimpleReturnAfterExtinction?: number;
  cashFlowAverageReturn?: number;
  recoverableVatAmount?: number;
  nonRecoverableVatAmount?: number;
  // ── TRI et comparaison ──
  indicativeIrr?: number | null;
  alternativeAnnualNetYield?: number;
  alternativeComparisonSpread?: number;
  economicGainAfterExtinction?: number;
  yearOneLaunchNetCashFlow?: number;
}

export interface ExpertClientDossier {
  id: string;
  clientName: string;
  companyType: string;
  siret?: string;
  managerName?: string;
  status?: string;
  createdAt: string;
  updatedAt: string;
  simulations: ExpertSimulationSnapshot[];
  notes?: string;
}

export interface ExpertGeneratedReport {
  id: string;
  dossierId: string;
  simulationId?: string;
  userId: string;
  reportType: string;
  fileName: string;
  storagePath: string;
  generatedAt: string;
  // ── Versioning ──
  versionNumber?: number;
  reportStatus?: string;
  fileSizeBytes?: number;
  notes?: string;
  deletedAt?: string;
}

/* ── Vérification cabinet Expert-Comptable ── */

export type ExpertVerificationStatus =
  | 'unverified'
  | 'siret_verified_accounting_activity'
  | 'siret_verified_non_accounting_activity'
  | 'siret_not_found'
  | 'declared_oec_registered';

export interface ExpertVerificationProfile {
  status: ExpertVerificationStatus;
  siret: string;
  siren: string;
  firmName: string;
  address: string;
  postalCode: string;
  city: string;
  apeCode: string;
  apeLabel: string;
  administrativeStatus: 'active' | 'closed' | 'unknown';
  professionalEmail: string;
  oecSelfDeclaration: boolean;
  oecSelfDeclaredAt?: string;
  verifiedAt?: string;
}

export interface SiretApiResponse {
  siret: string;
  siren: string;
  nic: string;
  siege_social: boolean;
  etat_administratif: string;
  personne_morale_attributs?: { raison_sociale: string };
  enseigne?: string;
  adresse: string;
  code_postal: string;
  libelle_commune: string;
  activite_principale: string;
  libelle_activite_principale: string;
  unite_legale?: {
    etat_administratif: string;
    personne_morale_attributs?: { raison_sociale: string };
  };
}
