import { Scpi, type ScpiManagementFeeDetails } from '../types/scpi';
import scpiCompleteJson from './SCPI_complet_avec_SFDR_Profil.json';
import scpiCompletJson from './scpi_complet.json';
import { getVerifiedScpiNews } from '../utils/scpiNewsRecord.mjs';
import { filterDocumentedNonLiquidityWarnings } from '../utils/scpiLiquidityText.mjs';
import certifiedScpiCohort from './certified_scpi_cohort.json';
import { aggregateCountryGeography } from '../utils/scpiGeography';
import { subscriptionFeeState } from '../utils/scpiFeeState';
// Force reload: Perial Opportunités Europe prix mis à jour à 44€

// Helper function to parse sectorial distribution from string or JSON
const parseSectorDistribution = (sectorStr: string): Record<string, number> => {
  const result: Record<string, number> = {};
  if (!sectorStr) return result;

  // Try to parse as JSON first (new format)
  try {
    const parsed = JSON.parse(sectorStr);
    if (typeof parsed === 'object' && parsed !== null) {
      return parsed;
    }
  } catch {
    // Not JSON, continue with text parsing
  }

  // Parse as text format (old format): "Bureaux (37,76%), Santé & éducation (24,04%)..."
  const matches = sectorStr.match(/([^(,]+)\((\d+(?:\.\d+)?%?)\)/g);
  if (!matches) return result;

  matches.forEach(match => {
    const parts = match.match(/([^(,]+)\((\d+(?:\.\d+)?%?)\)/);
    if (parts) {
      const name = parts[1].trim().replace(/^,\s*/, '');
      const value = parseFloat(parts[2].replace('%', ''));
      result[name] = value;
    }
  });

  return result;
};

// Helper function to parse geographical distribution from JSON string
const parseGeoDistribution = (geoStr: string): Record<string, number> => {
  try {
    return JSON.parse(geoStr);
  } catch {
    return {};
  }
};

// Helper function to determine sector from sectorial distribution
const determineSector = (repartitionStr: string, sectorDistribution: Record<string, number>): 'bureaux' | 'commerces' | 'residentiel' | 'sante' | 'logistique' | 'hotellerie' | 'diversifie' => {
  if (!repartitionStr) return 'diversifie';

  // Calculer les scores par catégorie en analysant la répartition
  const scores = {
    bureaux: 0,
    commerces: 0,
    residentiel: 0,
    sante: 0,
    logistique: 0,
    hotellerie: 0
  };

  // Analyser chaque secteur de la répartition
  Object.entries(sectorDistribution).forEach(([name, value]) => {
    const lowerName = name.toLowerCase();

    // Bureaux
    if (lowerName.includes('bureau') || lowerName.includes('tertiaire')) {
      scores.bureaux += value;
    }

    // Commerces
    if (lowerName.includes('commerce') || lowerName.includes('retail') ||
        lowerName.includes('alimentaire') || lowerName.includes('galerie') ||
        lowerName.includes('centre-ville') || lowerName.includes('pied d\'immeuble')) {
      scores.commerces += value;
    }

    // Résidentiel
    if (lowerName.includes('résidentiel') || lowerName.includes('logement') ||
        lowerName.includes('habitation') || lowerName.includes('résidence')) {
      scores.residentiel += value;
    }

    // Santé
    if (lowerName.includes('santé') || lowerName.includes('sanitaire') ||
        lowerName.includes('social') || lowerName.includes('éducation') ||
        lowerName.includes('life science')) {
      scores.sante += value;
    }

    // Logistique
    if (lowerName.includes('logistique') || lowerName.includes('entrepôt') ||
        lowerName.includes('activité') || lowerName.includes('messagerie')) {
      scores.logistique += value;
    }

    // Hôtellerie
    if (lowerName.includes('hôtel') || lowerName.includes('hospitalité') ||
        lowerName.includes('loisir') || lowerName.includes('tourisme') ||
        lowerName.includes('séminaire') || lowerName.includes('hébergement')) {
      scores.hotellerie += value;
    }
  });

  // Trouver le secteur dominant
  const maxScore = Math.max(...Object.values(scores));

  // Si aucun score, c'est diversifié
  if (maxScore === 0) {
    return 'diversifie';
  }

  // Compter combien de secteurs ont un score significatif (> 20%)
  const significantSectors = Object.values(scores).filter(score => score > 20).length;

  // Si plusieurs secteurs significatifs (3 ou plus), c'est diversifié
  if (significantSectors >= 3) {
    return 'diversifie';
  }

  // Si le secteur dominant représente moins de 40% ET qu'il y a au moins 2 secteurs > 20%, c'est diversifié
  if (maxScore < 40 && significantSectors >= 2) {
    return 'diversifie';
  }

  // Sinon, retourner le secteur avec le score le plus élevé
  const dominantSector = Object.entries(scores).find(([_, score]) => score === maxScore)?.[0];
  return (dominantSector as any) || 'diversifie';
};

// Helper function to determine geography from geographical distribution
const determineGeography = (geoData: Record<string, number>): 'france' | 'europe' | 'international' => {
  const geoEntries = Object.keys(geoData).map(k => k.toLowerCase());

  const hasInternational = geoEntries.some(key =>
    key.includes('royaume-uni') ||
    key.includes('états-unis') ||
    key.includes('international') ||
    key.includes('ocde')
  );

  const hasEurope = geoEntries.some(key =>
    key.includes('allemagne') ||
    key.includes('espagne') ||
    key.includes('italie') ||
    key.includes('pays-bas') ||
    key.includes('belgique') ||
    key.includes('pologne') ||
    key.includes('irlande') ||
    key.includes('portugal') ||
    key.includes('europe')
  );

  if (hasInternational) return 'international';
  if (hasEurope) return 'europe';
  return 'france';
};

// Helper function to determine if SCPI is European
const isEuropean = (geography: string, geoData: Record<string, number>): boolean => {
  if (geography === 'europe' || geography === 'international') return true;

  const europeanCountries = Object.entries(geoData).filter(([key]) =>
    key.toLowerCase().includes('allemagne') ||
    key.toLowerCase().includes('espagne') ||
    key.toLowerCase().includes('italie') ||
    key.toLowerCase().includes('pays-bas') ||
    key.toLowerCase().includes('belgique') ||
    key.toLowerCase().includes('pologne') ||
    key.toLowerCase().includes('irlande') ||
    key.toLowerCase().includes('portugal')
  );

  const totalEuropean = europeanCountries.reduce((sum, [_, value]) => sum + (value || 0), 0);
  return totalEuropean > 30;
};

// Helper function to clean and convert repartition data
const cleanRepartition = (repartition: Record<string, number>) => {
  return Object.entries(repartition)
    .filter(([_, value]) => value > 0)
    .map(([name, value]) => ({
      name: name.replace(/\([^)]*\)/g, '').trim(),
      value: value
    }));
};

// Helper function to determine if SCPI is recommended by MaximusSCPI
// Critères : TOF ≥ 90%, Décote ≤ 0, Capitalisation ≥ 100M€, Rendement ≥ 5%, Endettement < 30%
const isRecommended = (scpi: any): boolean => {
  // Une fiche en cours d'onboarding ne peut jamais être recommandée avant certification.
  if (['pending_certification', 'published_with_reserves'].includes(scpi.maximus_publication_status) || scpi.maximus_recommendation_status === 'manual_review_required') return false;
  const hasTofAbove90 = scpi['TOF (%)'] >= 90;
  const hasDiscountOrPar = scpi['Surcote/décote (%)'] <= 0;
  const hasCapitalizationAbove100M = scpi['Capitalisation (M€)'] >= 100;
  const hasYieldAbove5 = scpi['Taux de distribution (%)'] >= 5;
  const hasDebtBelow30 = typeof scpi['Endettement (%)'] === 'number' && Number.isFinite(scpi['Endettement (%)']) && scpi['Endettement (%)'] < 30;

  return hasTofAbove90 && hasDiscountOrPar && hasCapitalizationAbove100M && hasYieldAbove5 && hasDebtBelow30;
};

// Helper function to clean numeric values from Excel (handles "NC", null, undefined, strings)
const cleanNumericValue = (value: any): number | undefined => {
  if (value === null || value === undefined || value === '' || value === 'NC' || value === 'N/A') {
    return undefined;
  }
  if (typeof value === 'number') {
    return isNaN(value) ? undefined : value;
  }
  if (typeof value === 'string') {
    // Remove any non-numeric characters except decimal point and minus sign
    const cleaned = value.replace(/[^\d.,-]/g, '').replace(',', '.');
    const num = parseFloat(cleaned);
    return isNaN(num) ? undefined : num;
  }
  return undefined;
};

// A geographic fee structure cannot be converted to one blended/flat rate.
const parseManagementFeeDetails = (value: unknown): ScpiManagementFeeDetails | undefined => {
  if(!value || typeof value !== 'object' || Array.isArray(value))return undefined;
  const v=value as Partial<ScpiManagementFeeDetails>;
  if(v.kind!=='geographic_tiers'||v.basis!=='HT'||v.blended_rate!==null||
     v.revenue_basis!=='loyers encaissés'||
     !Number.isFinite(v.euro_zone_percent)||!(Number(v.euro_zone_percent)>0)||
     !Number.isFinite(v.outside_euro_zone_percent)||!(Number(v.outside_euro_zone_percent)>0)||
     !/^https:\/\/www\.corum\.fr\//.test(v.source_url||'')||
     !/^[a-f0-9]{64}$/.test(v.source_sha256||'')||
     !Number.isInteger(v.source_page)||!(Number(v.source_page)>0))
    return undefined;
  return v as ScpiManagementFeeDetails;
};

// Convert JSON data to Scpi format
// Utiliser le nouveau fichier scpi_complet.json s'il est disponible, sinon utiliser l'ancien
const toCertifiedScpiSlug = (name: string): string =>
  name
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '');

// Branch-specific Netlify Deploy Preview only: exercise candidates without changing
// the production 66-SCPI certified cohort. Never trust a user-facing query string.
const bnppPreviewCandidates = import.meta.env?.VITE_BNPP_CANDIDATE_PREVIEW === 'true'
  ? ['acces-valeur-pierre', 'accimmo-pierre']
  : [];
const certifiedScpiSlugSet = new Set<string>([
  ...certifiedScpiCohort.slugs,
  ...bnppPreviewCandidates,
]);

const rawSourceData = Array.isArray(scpiCompletJson) ? scpiCompletJson : (scpiCompleteJson.Sheet1 || scpiCompleteJson);
const sourceData = rawSourceData.filter((row: any) =>
  certifiedScpiSlugSet.has(toCertifiedScpiSlug(String(row['Nom SCPI'] || '')))
);

// Fonction pour fusionner les entrées multiples d'une même SCPI
// Priorité : entrée principale + données trimestrielles de l'entrée avec période bulletin
function mergeScpiEntries(entries: any[]): any[] {
  const merged: Record<string, any> = {};
  
  entries.forEach((entry) => {
    const nom = entry['Nom SCPI'];
    if (!nom) return;
    
    if (!merged[nom]) {
      // Première entrée trouvée : créer l'entrée de base
      merged[nom] = { ...entry };
    } else {
      // Entrée existante : fusionner les données
      const existing = merged[nom];
      
      // Si cette entrée a une période bulletin trimestriel, prioriser ses données trimestrielles
      if (entry['Période bulletin trimestriel'] && !existing['Période bulletin trimestriel']) {
        // L'entrée existante est principale, l'entrée actuelle est trimestrielle
        // Ajouter les données trimestrielles à l'entrée principale
        if (entry['Actualités trimestrielles']) {
          existing['Actualités trimestrielles'] = entry['Actualités trimestrielles'];
        }
        if (entry['Période bulletin trimestriel']) {
          existing['Période bulletin trimestriel'] = entry['Période bulletin trimestriel'];
        }
        // Mettre à jour les données trimestrielles si elles sont plus récentes
        if (entry['Nombre de locataires'] !== undefined) {
          existing['Nombre de locataires'] = entry['Nombre de locataires'];
        }
        if (entry['WALT'] !== undefined) {
          existing['WALT'] = entry['WALT'];
        }
        if (entry['WALB'] !== undefined) {
          existing['WALB'] = entry['WALB'];
        }
        if (entry['Collecte nette trimestre'] !== undefined) {
          existing['Collecte nette trimestre'] = entry['Collecte nette trimestre'];
        }
        if (entry['TOP (%)'] !== undefined) {
          existing['TOP (%)'] = entry['TOP (%)'];
        }
        // Mettre à jour le nombre d'immeubles si présent dans l'entrée trimestrielle
        const nbImmeublesKey = Object.keys(entry).find(k => k.includes('immeubles') || k.includes('Immeubles'));
        if (nbImmeublesKey && entry[nbImmeublesKey] !== undefined) {
          const existingKey = Object.keys(existing).find(k => k.includes('immeubles') || k.includes('Immeubles'));
          if (existingKey) {
            existing[existingKey] = entry[nbImmeublesKey];
          } else {
            existing[nbImmeublesKey] = entry[nbImmeublesKey];
          }
        }
        // Mettre à jour les répartitions si elles sont plus détaillées dans l'entrée trimestrielle
        if (entry['Répartition Sectorielle JSON'] && Object.keys(entry['Répartition Sectorielle JSON']).length > 0) {
          existing['Répartition Sectorielle JSON'] = entry['Répartition Sectorielle JSON'];
          if (entry['Répartition Sectorielle']) {
            existing['Répartition Sectorielle'] = entry['Répartition Sectorielle'];
          }
        }
        if (entry['Répartition Géographique JSON'] && Object.keys(entry['Répartition Géographique JSON']).length > 0) {
          existing['Répartition Géographique JSON'] = entry['Répartition Géographique JSON'];
          if (entry['Répartition Géographique']) {
            existing['Répartition Géographique'] = entry['Répartition Géographique'];
          }
        }
      } else if (!entry['Période bulletin trimestriel'] && existing['Période bulletin trimestriel']) {
        // L'entrée actuelle est principale, l'existante est trimestrielle
        // Remplacer l'existante par la principale et garder les données trimestrielles
        const temp = { ...existing };
        Object.assign(existing, entry);
        // Conserver les données trimestrielles
        if (temp['Actualités trimestrielles']) {
          existing['Actualités trimestrielles'] = temp['Actualités trimestrielles'];
        }
        if (temp['Période bulletin trimestriel']) {
          existing['Période bulletin trimestriel'] = temp['Période bulletin trimestriel'];
        }
        // Conserver les répartitions de l'entrée principale si elles sont plus détaillées
        if (entry['Répartition Sectorielle JSON'] && Object.keys(entry['Répartition Sectorielle JSON']).length > 0) {
          existing['Répartition Sectorielle JSON'] = entry['Répartition Sectorielle JSON'];
          if (entry['Répartition Sectorielle']) {
            existing['Répartition Sectorielle'] = entry['Répartition Sectorielle'];
          }
        }
        if (entry['Répartition Géographique JSON'] && Object.keys(entry['Répartition Géographique JSON']).length > 0) {
          existing['Répartition Géographique JSON'] = entry['Répartition Géographique JSON'];
          if (entry['Répartition Géographique']) {
            existing['Répartition Géographique'] = entry['Répartition Géographique'];
          }
        }
        // Conserver le nombre d'immeubles de l'entrée principale
        const entryNbImmeublesKey = Object.keys(entry).find(k => k.includes('immeubles') || k.includes('Immeubles'));
        if (entryNbImmeublesKey && entry[entryNbImmeublesKey] !== undefined) {
          const existingKey = Object.keys(existing).find(k => k.includes('immeubles') || k.includes('Immeubles'));
          if (existingKey) {
            existing[existingKey] = entry[entryNbImmeublesKey];
          } else {
            existing[entryNbImmeublesKey] = entry[entryNbImmeublesKey];
          }
        }
      }
    }
  });
  
  return Object.values(merged);
}

// Fusionner les entrées multiples avant de les transformer
const mergedData = mergeScpiEntries(sourceData);

export const scpiData: Scpi[] = mergedData.map((scpi: any, index: number) => {
  const editorialNews = getVerifiedScpiNews(scpi.maximus_editorial_news);
  // Utiliser les champs JSON structurés s'ils existent (nouveau format), sinon parser les chaînes
  let sectorDistribution: Record<string, number> = {};
  let geoDistribution: Record<string, number> = {};
  
  if (scpi['Répartition Sectorielle JSON']) {
    // Nouveau format : déjà un objet JSON
    sectorDistribution = scpi['Répartition Sectorielle JSON'];
  } else {
    // Ancien format : parser la chaîne
    sectorDistribution = parseSectorDistribution(scpi['Répartition Sectorielle'] || '');
  }
  
  if (scpi['Répartition Géographique JSON']) {
    // Nouveau format : déjà un objet JSON
    geoDistribution = scpi['Répartition Géographique JSON'];
  } else {
    // Ancien format : parser la chaîne JSON
    geoDistribution = parseGeoDistribution(scpi['Répartition Géographique'] || '{}');
  }

  // The issuer can publish both regions and countries. For a country-level
  // portfolio comparison, Paris + Île-de-France + Régions are one France exposure.
  // Raw issuer buckets remain unchanged in the source catalog and database.
  geoDistribution = aggregateCountryGeography(geoDistribution);

  const sector = determineSector(scpi['Répartition Sectorielle'] || '', sectorDistribution);
  const geography = determineGeography(geoDistribution);
  const recommended = isRecommended(scpi);

  return {
    id: index + 1,
    metricProvenance: scpi.maximus_metric_provenance || undefined,
    maximusPublicationStatus: ['certified','published_with_reserves'].includes(scpi.maximus_publication_status) ? scpi.maximus_publication_status : undefined,
    maximusPublicationReservations: Array.isArray(scpi.maximus_publication_reservations) ? scpi.maximus_publication_reservations.filter((v: unknown): v is string => typeof v === 'string') : undefined,
    maximusDisabledFeatures: Array.isArray(scpi.maximus_disabled_features) ? scpi.maximus_disabled_features.filter((v: unknown): v is string => typeof v === 'string') : undefined,
    name: scpi['Nom SCPI'],
    sector: sector,
    geography: geography,
    yield: scpi['Taux de distribution (%)'] || 0,
    distributionReferencePeriod: typeof scpi['td_reference_period'] === 'string' ? scpi['td_reference_period'] : undefined,
    distributionReferenceUrl: typeof scpi['td_reference_url'] === 'string' ? scpi['td_reference_url'] : undefined,
    capitalization: (scpi['Capitalisation (M€)'] || 0) * 1000000,
    tof: scpi['TOF (%)'] || 0,
    price: scpi['Prix de souscription (€)'] || 0,
    discount: scpi['Surcote/décote (%)'] !== undefined ? scpi['Surcote/décote (%)'] : 0,
    discountQaStatus: scpi['Décote/Surcote QA'] || undefined,
    fees: scpi['Frais de souscription (TTC/%)'] || 0,
    feesState: subscriptionFeeState(scpi['Frais de souscription (TTC/%)'], scpi.maximus_metric_provenance?.frais_souscription),
    isr: scpi['Label ISR'] === 'Oui',
    european: isEuropean(geography, geoDistribution),
    company: scpi['Société de gestion'],
    creation: scpi['Année de création'],
    minInvest: scpi['Minimum de souscription €'] || 1000,
    repartitionSector: cleanRepartition(sectorDistribution),
    repartitionGeo: cleanRepartition(geoDistribution),
    // rating: now comes from DB (scpi_bulletins.maximus_score) via getScoreBySlug; set undefined at load time
    rating: undefined,
    isRecommended: recommended,
    // A genuine issuer non-disclosure is undefined, never null or a fabricated 0.
    debt: cleanNumericValue(scpi['Endettement (%)']),
    debtReferencePeriod: typeof scpi['debt_reference_period'] === 'string' ? scpi['debt_reference_period'] : undefined,
    debtReferenceUrl: typeof scpi['debt_reference_url'] === 'string' ? scpi['debt_reference_url'] : undefined,
    // Champs supplémentaires depuis le fichier Excel
    delaiJouissance: cleanNumericValue(scpi['Délai de jouissance (mois)']),
    versementLoyers: scpi['Versement des loyers'] || undefined,
    dureeDetentionRecommandee: cleanNumericValue(scpi['Durée de détention recommandée (ans)']),
    fraisGestion: cleanNumericValue(scpi['Frais de gestion (HT/%)']),
    fraisGestionDetails: parseManagementFeeDetails(scpi['Frais de gestion (détail)']),
    valeurRetrait: cleanNumericValue(scpi['Valeur de retrait (€)']),
    retraitSourceUrl: typeof scpi.maximus_prix_retrait_source_url === 'string'
      && /^https:\/\//.test(scpi.maximus_prix_retrait_source_url)
      ? scpi.maximus_prix_retrait_source_url : undefined,
    retraitSourcePage: cleanNumericValue(scpi.maximus_prix_retrait_source_page),
    retraitReferencePeriod: typeof scpi.maximus_prix_retrait_reference_period === 'string'
      ? scpi.maximus_prix_retrait_reference_period : undefined,
    retraitDefinition: typeof scpi.maximus_prix_retrait_definition === 'string'
      ? scpi.maximus_prix_retrait_definition : undefined,
    // Priorité à la valeur de reconstitution PAR PART validée (QA) — même source que la décote/surcote affichée.
    valeurReconstitution: cleanNumericValue(scpi['Valeur de reconstitution par part (€)']) ?? cleanNumericValue(scpi['Valeur de reconstitution (€)']),
    valeurRealisation: cleanNumericValue(scpi['Valeur de réalisation (€)']),
    historyStatus: typeof scpi.maximus_history_status === 'string'
      ? scpi.maximus_history_status : 'NOT_ASSESSED',
    historyYearsExpected: cleanNumericValue(scpi.maximus_history_years_expected),
    historyYearsVerified: cleanNumericValue(scpi.maximus_history_years_verified),
    historyStartYearStatus: typeof scpi.maximus_history_start_year_status === 'string'
      ? scpi.maximus_history_start_year_status : 'missing',
    valeurRealisationReferenceDate: typeof scpi['maximus_valeur_realisation_reference_date'] === 'string'
      ? scpi['maximus_valeur_realisation_reference_date'] : undefined,
    walbReferenceDate: typeof scpi['maximus_walb_reference_date'] === 'string'
      ? scpi['maximus_walb_reference_date'] : undefined,
    walbDefinition: typeof scpi['maximus_walb_definition'] === 'string'
      ? scpi['maximus_walb_definition'] : undefined,
    walbSourceUrl: typeof scpi['maximus_walb_source_url'] === 'string'
      && /^https:\/\/(?:www\.corum\.fr|reim\.bnpparibas-am\.com)\//.test(scpi['maximus_walb_source_url'])
      ? scpi['maximus_walb_source_url'] : undefined,
    distribution: cleanNumericValue(scpi['Distribution (€/part)']),
    nbImmeubles: cleanNumericValue(scpi['Nombre d\'immeubles']),
    nombreLocataires: cleanNumericValue(scpi['Nombre de locataires']),
    nombreAssocies: cleanNumericValue(scpi['Nombre d’associés']) ??
      cleanNumericValue(scpi["Nombre d'associés"]) ??
      cleanNumericValue(scpi.maximus_metric_provenance?.nombre_associes?.value_numeric),
    nombreUnitesLocatives: cleanNumericValue(scpi.maximus_metric_provenance?.nombre_unites_locatives?.value_numeric),
    fraisGestionAssiette: typeof scpi['Frais de gestion - assiette'] === 'string' ? scpi['Frais de gestion - assiette'] : undefined,
    walt: cleanNumericValue(scpi['WALT']),
    walb: cleanNumericValue(scpi['WALB']),
    collecteNetteTrimestre: cleanNumericValue(scpi['Collecte nette trimestre']),
    nbCessionsTrimestre: cleanNumericValue(scpi['Nombre de cessions trimestre']),
    actualitesTrimestrielles: editorialNews?.text,
    actualitePeriode: editorialNews?.period,
    actualiteDateDocument: editorialNews?.documentDate,
    actualiteSourceDocument: editorialNews?.sourceDocument,
    actualiteSourceUrl: editorialNews?.sourceUrl,
    periodeBulletinTrimestriel: scpi['Période bulletin trimestriel'] || undefined,
    dateBulletin: scpi['Date bulletin'] || undefined,
    // Undated legacy prose must not override the certified liquidity regime.
    liquidite: undefined,
    partsAttenteRetrait:
      cleanNumericValue(scpi['Parts en attente de retrait']) ??
      (typeof scpi['liquidite'] === 'number' ? cleanNumericValue(scpi['liquidite']) : undefined) ??
      cleanNumericValue(scpi.maximus_metric_provenance?.parts_attente_retrait?.value_numeric),
    partsProposeesVente:
      cleanNumericValue(scpi['Parts proposées à la vente']) ??
      cleanNumericValue(scpi['Parts en vente']) ??
      cleanNumericValue(scpi['Ordres de vente (parts)']),
    montantPartsAttenteRetraitM: cleanNumericValue(scpi['Montant parts en attente de retrait (M€)']),
    nbPartsTotal: cleanNumericValue(scpi['Nombre de parts']),
    hasWaitingShares: (() => {
      const explicit = cleanNumericValue(scpi['Parts en attente de retrait']) ??
        (typeof scpi['liquidite'] === 'number' ? cleanNumericValue(scpi['liquidite']) : undefined);
      if (explicit !== undefined) return explicit > 0;
      const note = typeof scpi['liquidite'] === 'string' ? scpi['liquidite'].toLowerCase() : '';
      if (/aucune part en attente|aucune demande.*retrait|0 part.*attente/.test(note)) return false;
      if (/\bparts? en attente\b|\bdemandes? de retrait\b/.test(note) && !/en cas de/.test(note)) return true;
      return undefined;
    })(),
    maximusWarnings: filterDocumentedNonLiquidityWarnings(scpi['maximus_warnings']),
    maximusDataStatus: typeof scpi['maximus_data_status'] === 'string' ? scpi['maximus_data_status'] : undefined,
    maximusSourcePeriode: typeof scpi['maximus_source_periode'] === 'string' ? scpi['maximus_source_periode'] : undefined,
    maximusSourceDocument: typeof scpi['maximus_source_document'] === 'string' ? scpi['maximus_source_document'] : undefined,
    maximusUpdateDate: typeof scpi['Date de mise à jour'] === 'string' ? scpi['Date de mise à jour'] : undefined,
    maximusLifecycleStatus: ['normal', 'dissolution_proposed', 'liquidation'].includes(scpi['maximus_lifecycle_status'])
      ? scpi['maximus_lifecycle_status']
      : undefined,
    maximusLifecycleNote: typeof scpi['maximus_lifecycle_note'] === 'string' ? scpi['maximus_lifecycle_note'] : undefined,
    maximusLifecycleSource: typeof scpi['maximus_lifecycle_source'] === 'string' ? scpi['maximus_lifecycle_source'] : undefined,
    // Nouvelle structure optionnelle pour les actualités détaillées
    // Legacy structured facts lack independent source provenance, so are not published.
    actualiteTrimestrielle: undefined,
    sfdr: scpi['SFDR'] || undefined,
    profilCible: scpi['Profil cible'] || undefined,
    // Profil de risque : chercher dans le nouveau format structuré (DIC) ou l'ancien format
    profilRisque: scpi['Profil_de_risque']?.SRRI !== null && scpi['Profil_de_risque']?.SRRI !== undefined
      ? scpi['Profil_de_risque'].SRRI
      : (cleanNumericValue(scpi['niveau_risque_dic']) ||
         cleanNumericValue(scpi['Profil de risque']) || 
         cleanNumericValue(scpi['Profil risque']) ||
         cleanNumericValue(scpi['Profil de risque (1-7)']) ||
         cleanNumericValue(scpi['Risque (1-7)']))
  };
});
