import { generateFAQSchema, generateBreadcrumbSchema, generateSoftwareApplicationSchema } from '../utils/seoOptimizer';

const SITE = 'https://maximusscpi.com';

export const simulatorSeoConfig = {

  'simulateur-scpi': {
    title: 'Simulateur SCPI 2026 : revenus & fiscalité | MaximusSCPI',
    description: 'Simulez un investissement SCPI : revenus bruts et nets, fiscalité, délai de jouissance et projection. Outil gratuit, sans inscription.',
    canonical: `${SITE}/simulateur-scpi/`,
    app: { name: 'Simulateur SCPI MaximusSCPI', description: 'Estimez les revenus et la fiscalité d’un investissement SCPI selon vos hypothèses.', url: `${SITE}/simulateur-scpi/` },
    breadcrumb: ['Accueil', 'Simulateurs', 'Simulateur SCPI'],
    faq: [
      { question: 'Combien rapporte 100 000 € investis en SCPI ?', answer: 'Le revenu dépend du taux de distribution, de la fiscalité, du délai de jouissance et de la situation de l’investisseur. Le simulateur permet de tester plusieurs hypothèses sans considérer le rendement comme garanti.' },
      { question: 'Les revenus d’une SCPI sont-ils garantis ?', answer: 'Non. Les revenus, la valeur des parts et la liquidité ne sont pas garantis. Une SCPI est un placement immobilier de long terme exposé notamment aux marchés immobiliers et au risque de perte en capital.' },
      { question: 'Quelle fiscalité appliquer aux revenus de SCPI ?', answer: 'La fiscalité dépend notamment de la localisation des immeubles, du mode de détention et de la situation fiscale de l’investisseur. Les revenus fonciers français et les revenus étrangers ne se traitent pas de la même manière.' },
    ],
  },
  'simulateur-revenus-nets': {
    title: 'Simulateur SCPI gratuit 2026 : revenus nets | MaximusSCPI',
    description: 'Simulez gratuitement vos revenus SCPI bruts et nets selon le capital investi, le rendement, la fiscalité et le délai de jouissance. Sans inscription.',
    canonical: `${SITE}/simulateur-revenus-nets-scpi/`,
    app: { name: 'Simulateur Revenus Nets SCPI', description: 'Estimez les revenus d’une SCPI détenue en direct avec hypothèses fiscales explicites.', url: `${SITE}/simulateur-revenus-nets-scpi/` },
    breadcrumb: ['Accueil', 'Simulateurs', 'Revenus nets'],
    faq: [
      { question: 'Comment sont imposés les revenus d’une SCPI détenue en direct ?', answer: 'Pour une SCPI détenant des immeubles en France, la quote-part de revenus fonciers relève du barème de l’impôt sur le revenu et des prélèvements sociaux. Pour les revenus immobiliers étrangers, le traitement dépend de la convention fiscale applicable.' },
      { question: 'Quel simulateur SCPI choisir ?', answer: 'MaximusSCPI propose 9 simulateurs gratuits : revenus nets, crédit, démembrement, enveloppes fiscales, profil investisseur, impact fiscal et comparateur démembrement.' },
    ],
  },
  'simulateur-credit': {
    title: 'Simulateur Crédit SCPI 2026 | Effet de Levier | MaximusSCPI',
    description: 'Simulez votre investissement SCPI à crédit. Calcul mensualité, cash-flow, effet de levier. Outil gratuit CGP-CIF.',
    canonical: `${SITE}/simulateur-credit-scpi/`,
    app: { name: 'Simulateur Crédit SCPI', description: 'Simulez l\'achat de SCPI à crédit avec calcul de l\'effet de levier et déductibilité des intérêts', url: `${SITE}/simulateur-credit-scpi/` },
    breadcrumb: ['Accueil', 'Simulateurs', 'Crédit SCPI'],
    faq: [
      { question: 'Peut-on acheter des SCPI à crédit ?', answer: 'Oui. Les banques proposent des prêts affectés à l\'achat de parts SCPI. Les intérêts sont déductibles des revenus fonciers.' },
      { question: 'Quel apport pour acheter des SCPI à crédit ?', answer: 'Les banques exigent généralement 20 à 30% d\'apport. Un simulateur vous aide à dimensionner votre projet.' },
    ],
  },
  'simulateur-demembrement': {
    title: 'Simulateur Démembrement SCPI 2026 | Nue Propriété | MaximusSCPI',
    description: 'Calculez le rendement net de votre SCPI en démembrement. Simulateur nue-propriété/usufruit gratuit.',
    canonical: `${SITE}/simulateur-demembrement-scpi/`,
    app: { name: 'Simulateur Démembrement SCPI', description: 'Calculez le rendement de votre investissement en nue-propriété de SCPI selon la durée choisie', url: `${SITE}/simulateur-demembrement-scpi/` },
    breadcrumb: ['Accueil', 'Simulateurs', 'Démembrement'],
    faq: [
      { question: 'Qu\'est-ce que le démembrement de SCPI ?', answer: 'Le démembrement sépare la nue-propriété (capital) et l\'usufruit (revenus). L\'investisseur en nue-propriété acquiert moins cher et récupère la pleine propriété à l\'échéance.' },
      { question: 'Quelle durée de démembrement choisir ?', answer: 'Les durées courantes sont 10, 15 ou 20 ans. Plus la durée est courte, plus la décote (et donc le rendement annuel) est élevée.' },
    ],
  },
  'simulateur-enveloppes': {
    title: 'Simulateur Enveloppes SCPI 2026 | AV vs Direct | MaximusSCPI',
    description: 'Comparez SCPI en direct vs assurance-vie. Rendement net, fiscalité, horizon 8-15 ans. Simulateur gratuit.',
    canonical: `${SITE}/simulateur-enveloppes-scpi/`,
    app: { name: 'Simulateur Enveloppes SCPI', description: 'Comparez la rentabilité des SCPI en direct et en assurance-vie selon votre TMI et horizon', url: `${SITE}/simulateur-enveloppes-scpi/` },
    breadcrumb: ['Accueil', 'Simulateurs', 'Enveloppes'],
    faq: [
      { question: 'SCPI en direct ou en assurance-vie ?', answer: 'En direct : fiscalité immédiate (IR + PS) mais capital disponible. En assurance-vie : report d\'impôt, abattement après 8 ans, mais frais de contrat.' },
      { question: 'Quand l\'assurance-vie SCPI devient avantageuse ?', answer: 'Souvent à partir de 8 ans de détention et pour les TMI 30% et plus, grâce à l\'abattement et au report d\'imposition.' },
    ],
  },
  'simulateur-tresorerie-is': {
    title: 'Simulateur Trésorerie IS 2026 | SCPI & Impôt sur Sociétés',
    canonical: `${SITE}/simulateur-tresorerie-is/`,
    app: { name: 'Simulateur Trésorerie IS SCPI', description: 'Simulez la trésorerie d\'une SCPI détenue via une société à l\'IS', url: `${SITE}/simulateur-tresorerie-is/` },
    breadcrumb: ['Accueil', 'Simulateurs', 'Trésorerie IS'],
    description: 'Simulez la trésorerie de vos SCPI détenues en société à l\'IS. Cash-flow, impôt, optimisation.',
    faq: [
      { question: 'Pourquoi détenir des SCPI en société à l\'IS ?', answer: 'L\'IS (25%) peut être plus favorable que l\'IR pour les forts patrimoines. Le simulateur aide à projeter la trésorerie.' },
    ],
  },
  'simulateur-impact-fiscal': {
    title: 'Simulateur Impact Fiscal SCPI 2026 | MaximusSCPI',
    description: 'Estimez l\'impact fiscal de votre investissement SCPI. IR, PS, abattements. Simulateur gratuit CGP-CIF.',
    canonical: `${SITE}/simulateur-impact-fiscal-scpi/`,
    app: { name: 'Simulateur Impact Fiscal SCPI', description: 'Calculez l\'impact de vos revenus SCPI sur votre impôt sur le revenu et prélèvements sociaux', url: `${SITE}/simulateur-impact-fiscal-scpi/` },
    breadcrumb: ['Accueil', 'Simulateurs', 'Impact fiscal'],
    faq: [
      { question: 'Quel impact fiscal pour les revenus SCPI ?', answer: 'Les revenus SCPI sont imposables à l\'IR (barème) et aux prélèvements sociaux (17,2%). En assurance-vie, abattement après 8 ans.' },
    ],
  },
  'simulateur-profil-investisseur': {
    title: 'Simulateur Profil Investisseur SCPI 2026 | MaximusSCPI',
    description: 'Déterminez votre profil investisseur pour les SCPI. Questionnaire gratuit, recommandations personnalisées.',
    canonical: `${SITE}/simulateur-profil-investisseur/`,
    app: { name: 'Simulateur Profil Investisseur SCPI', description: 'Questionnaire pour évaluer votre profil et vos objectifs d\'investissement en SCPI', url: `${SITE}/simulateur-profil-investisseur/` },
    breadcrumb: ['Accueil', 'Simulateurs', 'Profil investisseur'],
    faq: [
      { question: 'Quel profil investisseur pour les SCPI ?', answer: 'Les SCPI conviennent aux profils équilibrés ou dynamiques, avec un horizon 8-10 ans minimum.' },
    ],
  },
  'comparateur-demembrement': {
    title: 'Comparateur Démembrement SCPI 2026 | Nue Propriété | MaximusSCPI',
    description: 'Comparez les rendements des SCPI en démembrement par durée. Outil gratuit comparateur nue-propriété.',
    canonical: `${SITE}/comparateur-demembrement-scpi/`,
    app: { name: 'Comparateur Démembrement SCPI', description: 'Comparez les rendements annuels des SCPI en démembrement selon la durée (10, 15, 20 ans)', url: `${SITE}/comparateur-demembrement-scpi/` },
    breadcrumb: ['Accueil', 'Simulateurs', 'Comparateur démembrement'],
    faq: [
      { question: 'Comment comparer les SCPI en démembrement ?', answer: 'Le comparateur MaximusSCPI calcule le rendement annualisé pour chaque SCPI selon la durée de démembrement (décote appliquée).' },
      { question: 'Quelle SCPI en nue-propriété ?', answer: 'Les SCPI européennes à fort rendement offrent souvent les meilleurs rendements en démembrement.' },
    ],
  },
  'simulateur-marche-secondaire': {
    title: 'Diagnostic revente SCPI 2026 | Liquidité, prix & sources | MaximusSCPI',
    description: 'Sélectionnez votre SCPI : Maximus analyse son mode de sortie, sa liquidité, ses valeurs patrimoniales, les données officielles disponibles et leur niveau de fiabilité.',
    canonical: `${SITE}/simulateur-marche-secondaire-scpi/`,
    app: {
      name: 'Diagnostic de revente SCPI',
      description: 'Analysez la liquidité, le mode de sortie, les valeurs patrimoniales et la fraîcheur des sources disponibles pour une SCPI.',
      url: `${SITE}/simulateur-marche-secondaire-scpi/`
    },
    breadcrumb: ['Accueil', 'Simulateurs', 'Diagnostic revente SCPI'],
    faq: [
      { question: 'Comment savoir si une SCPI est revendable aujourd’hui ?', answer: 'Il faut identifier son mode de sortie actuel, le prix réellement applicable, les parts en attente ou le carnet d’ordres, puis vérifier la fraîcheur des sources officielles.' },
      { question: 'Le prix de sortie d’une SCPI est-il garanti ?', answer: 'Non. Il dépend du mécanisme de sortie : prix de retrait pour une SCPI à capital variable, ou prix d’exécution issu de l’offre et de la demande sur un marché secondaire.' },
    ],
  },
  'simulateurs': {
    title: 'Simulateurs SCPI 2026 : Revenus, Crédit, Démembrement | MaximusSCPI',
    description: 'Outils SCPI gratuits : revenus nets, crédit, démembrement, enveloppes, impact fiscal, profil investisseur.',
    canonical: `${SITE}/simulateurs/`,
    breadcrumb: ['Accueil', 'Simulateurs'],
    faq: [
      { question: 'Quels simulateurs SCPI proposer ?', answer: 'MaximusSCPI propose plusieurs outils : simulateur revenus nets, crédit, démembrement, enveloppes fiscales, trésorerie IS, impact fiscal, profil investisseur, comparateur démembrement.' },
      { question: 'Les simulateurs SCPI sont-ils gratuits ?', answer: 'Oui, tous les simulateurs MaximusSCPI sont gratuits et sans inscription. Conçus par un CGP-CIF immatriculé à l’ORIAS.' },
    ],
  },
} as const;

export function getSimulatorSchemaData(view: keyof typeof simulatorSeoConfig) {
  const c = simulatorSeoConfig[view];
  if (!c) return undefined;
  const parts: object[] = [];
  const bcUrls = c.breadcrumb.map((_, i) =>
    i === 0 ? `${SITE}/` : i === 1 ? `${SITE}/simulateurs/` : c.canonical
  );
  parts.push(generateBreadcrumbSchema(c.breadcrumb.map((name, i) => ({ name, url: bcUrls[i] || SITE }))));
  if (c.faq?.length) parts.push(generateFAQSchema(c.faq));
  if ('app' in c && c.app) {
    parts.push(generateSoftwareApplicationSchema(c.app));
  }
  return { '@graph': parts };
}
