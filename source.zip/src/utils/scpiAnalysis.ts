import { Scpi } from '../types/scpi';
import { resolveScpiIndicator } from '../indicators/resolveScpiIndicator';
import { formatScpiDiscountPremium } from './scpiDiscountPremium';
import { isProvenZeroFee } from './scpiFeeState';

/**
 * Décote/surcote telle qu'AFFICHÉE dans le bloc KPI.
 * Source UNIQUE imposée : `resolveScpiIndicator(scpi, 'decote_surcote')` — la même
 * fonction que le KPI. Interdit tout recours direct à scpi.discount / snapshot.
 * Retourne null quand la décote n'est pas fiable/comparable (manual_review,
 * prix/VR non comparables) → on ne mentionne PAS la décote dans les textes.
 */
const getDisplayedDiscount = (scpi: Scpi): number | null => {
  const resolved = resolveScpiIndicator({ ...scpi }, 'decote_surcote');
  return typeof resolved.value === 'number' ? resolved.value : null;
};

/**
 * Échelle de référence pour la capitalisation et la liquidité SCPI
 */
export interface CapitalizationCategory {
  category: 'petite' | 'intermediaire' | 'significative' | 'grande';
  label: string;
  liquidityQualification: string;
  liquidityPotential: 'fragile' | 'correcte' | 'confortable' | 'robuste';
}

/**
 * Détermine la catégorie de capitalisation selon l'échelle de référence marché
 */
export const getCapitalizationCategory = (capitalization: number): CapitalizationCategory => {
  const capitalizationM = capitalization / 1000000; // Convertir en millions
  
  if (capitalizationM < 100) {
    return {
      category: 'petite',
      label: 'Petite SCPI',
      liquidityQualification: 'liquidité potentiellement fragile',
      liquidityPotential: 'fragile'
    };
  } else if (capitalizationM < 300) {
    return {
      category: 'intermediaire',
      label: 'SCPI de taille intermédiaire',
      liquidityQualification: 'liquidité généralement correcte si la collecte est active',
      liquidityPotential: 'correcte'
    };
  } else if (capitalizationM < 800) {
    return {
      category: 'significative',
      label: 'SCPI de taille significative',
      liquidityQualification: 'liquidité confortable en conditions normales de marché',
      liquidityPotential: 'confortable'
    };
  } else {
    return {
      category: 'grande',
      label: 'SCPI de grande taille',
      liquidityQualification: 'liquidité des parts non garantie',
      liquidityPotential: 'robuste'
    };
  }
};

/**
 * Formate la capitalisation avec sa catégorie et qualification de liquidité
 */
export const formatCapitalizationWithLiquidity = (capitalization: number): string => {
  const capCategory = getCapitalizationCategory(capitalization);
  const capitalizationM = capitalization / 1000000;
  const capitalizationB = capitalization / 1000000000;
  
  let formattedCap: string;
  if (capitalizationM >= 1000) {
    formattedCap = `${capitalizationB.toFixed(1)}Md€`;
  } else {
    formattedCap = `${capitalizationM.toFixed(0)}M€`;
  }
  
  return `${formattedCap} (${capCategory.label.toLowerCase()}) – ${capCategory.liquidityQualification}`;
};

export const getScpiAdvantages = (scpi: Scpi): string[] => {
  const advantages: string[] = [];
  
  // Rendement
  if (scpi.yield >= 7) {
    advantages.push(`Rendement de ${scpi.yield.toFixed(2)}%`);
  } else if (scpi.yield >= 5.5) {
    advantages.push(`Rendement de ${scpi.yield.toFixed(2)}%`);
  }
  
  // TOF
  if (scpi.tof >= 95) {
    advantages.push(`Taux d'occupation de ${scpi.tof.toFixed(1)}%`);
  }
  
  // Only disclose a payment cadence when a source-backed frequency is present.
  // Annual distribution yield says nothing about whether cash is paid monthly
  // or quarterly. Never infer "trimestrielle" from yield > 0.
  const frequency=(scpi.versementLoyers||'').trim().toLowerCase();
  if (scpi.yield > 0 && /^mensuell?e?$/.test(frequency)) {
    advantages.push("Distribution mensuelle");
  } else if (scpi.yield > 0 && /^trimestriell?e?$/.test(frequency)) {
    advantages.push("Distribution trimestrielle");
  }
  
  // Diversification sectorielle
  if (scpi.repartitionSector && scpi.repartitionSector.length >= 3) {
    advantages.push(`Diversification sur ${scpi.repartitionSector.length} secteurs`);
  }
  
  // Diversification géographique
  if (scpi.geography === 'europe') {
    const geoCount = scpi.repartitionGeo?.length || 0;
    advantages.push(`Exposition géographique européenne (${geoCount} pays)`);
  } else if (scpi.geography === 'international') {
    const geoCount = scpi.repartitionGeo?.length || 0;
    advantages.push(`Exposition géographique internationale (${geoCount} pays)`);
  }
  
  // Accès institutionnel
  if (scpi.capitalization >= 1000000000) {
    advantages.push(`Capitalisation de ${(scpi.capitalization / 1000000000).toFixed(1)}Md€`);
  }
  
  // Fiscalité
  if (scpi.european || scpi.geography === 'international') {
    advantages.push("Fiscalité via assurance-vie possible");
  }
  
  // Accessibilité
  if (scpi.minInvest <= 1000) {
    advantages.push(`Ticket d'entrée de ${scpi.minInvest.toLocaleString('fr-FR')}€`);
  }
  
  // Société de gestion
  const experiencedManagers = ['La Française REM', 'PERIAL Asset Management', 'Sofidy', 'Amundi Immobilier'];
  if (experiencedManagers.includes(scpi.company)) {
    advantages.push(`Société de gestion : ${scpi.company}`);
  }
  
  // Qualité patrimoniale
  if (scpi.creation >= 2015 && scpi.tof >= 90) {
    advantages.push(`Patrimoine créé en ${scpi.creation}, TOF de ${scpi.tof.toFixed(1)}%`);
  }
  
  // Label ISR
  if (scpi.isr) {
    advantages.push("Label ISR présent");
  }
  
  // Frais
  if (isProvenZeroFee(scpi)) {
    advantages.push("Frais d'entrée à 0%");
  }
  
  // Capitalisation
  if (scpi.capitalization >= 500000000 && scpi.capitalization < 1000000000) {
    advantages.push(`Capitalisation de ${(scpi.capitalization / 1000000).toFixed(0)}M€`);
  }
  
  // Secteurs spécifiques
  if (scpi.sector === 'sante') {
    advantages.push("Secteur d'activité : santé");
  } else if (scpi.sector === 'logistique') {
    advantages.push("Secteur d'activité : logistique");
  } else if (scpi.sector === 'residentiel') {
    advantages.push("Secteur d'activité : résidentiel");
  }
  
  return advantages;
};

export const getScpiPointsAttention = (scpi: Scpi): string[] => {
  const concerns: string[] = [];
  
  // Toujours présent - Fiscalité
  concerns.push("Revenus fonciers soumis à l'impôt sur le revenu et aux prélèvements sociaux");
  
  // Toujours présent - Liquidité
  concerns.push("Délai de revente à prévoir (liquidité non immédiate)");
  
  // Troisième point selon les caractéristiques spécifiques
  const displayedDiscount = getDisplayedDiscount(scpi);
  if (displayedDiscount != null && displayedDiscount > 3) {
    concerns.push(`Surcote/décote de ${formatScpiDiscountPremium(Math.abs(displayedDiscount)).replace(/^\+/, '')} par rapport à la valeur de reconstitution`);
  } else if (scpi.tof < 90) {
    concerns.push(`Taux d'occupation de ${scpi.tof.toFixed(1)}%`);
  } else if (scpi.creation >= 2020) {
    concerns.push(`Société de gestion créée en ${scpi.creation}`);
  } else if (scpi.sector === 'hotellerie') {
    concerns.push("Secteur d'activité : hôtellerie");
  } else if (scpi.sector === 'commerces') {
    concerns.push("Secteur d'activité : commerces");
  } else if (scpi.creation < 2000) {
    concerns.push(`Patrimoine créé en ${scpi.creation}`);
  } else {
    concerns.push("Horizon d'investissement recommandé : 8 à 12 ans minimum");
  }
  
  return concerns.slice(0, 3); // Maximum 3 points d'attention
};

export const getScpiPresentation = (scpi: Scpi): string => {
  const presentations: Record<string, string> = {
    "Activimmo": "SCPI diversifiée créée en 1984 et gérée par Alderan, Activimmo est l'une des plus anciennes SCPI du marché. Elle investit principalement en France dans des bureaux, commerces et actifs diversifiés, offrant une approche patrimoniale équilibrée et une liquidité attractive grâce à sa taille et son ancienneté.",
    "Aestiam Cap'Hebergimmo": "SCPI spécialisée dans l'hébergement d'affaires et les résidences services, gérée par Aestiam depuis 2012. Elle cible des actifs modernes en France répondant aux nouvelles formes d'hébergement professionnel et étudiant, avec une gestion dynamique et des baux sécurisés.",
    "Aestiam Pierre Rendement": "SCPI diversifiée créée en 2006 par Aestiam, investissant dans des bureaux, commerces et locaux d'activité en France. Elle privilégie des actifs situés dans des zones à fort potentiel économique avec une approche rendement-sécurité équilibrée.",
    "Aestiam Placement Pierre": "SCPI patrimoniale gérée par Aestiam depuis 2005, axée sur les bureaux et commerces en Île-de-France et grandes métropoles régionales. Elle vise une stratégie de valorisation à long terme avec des actifs de qualité dans des emplacements stratégiques.",
    "Altixia Cadence 12": "SCPI à capital fixe fermée, créée en 2012 par Altixia REIM. Elle investit dans des actifs tertiaires diversifiés en France avec un objectif de valorisation et de distribution régulière sur un horizon d'investissement défini.",
    "Altixia Commerces": "SCPI spécialisée dans les commerces de proximité et retail parks, gérée par Altixia REIM depuis 2015. Elle se concentre sur des zones de chalandise dynamiques en France avec des baux longue durée et des enseignes reconnues.",
    "Atream Hotel": "SCPI unique sur le marché, spécialisée dans l'hôtellerie européenne depuis 2006 et gérée par Atream. Elle investit dans des hôtels d'affaires et de tourisme exploités par de grandes enseignes internationales, offrant une exposition au secteur du tourisme et des voyages d'affaires.",
    "Buroboutic Métropoles": "SCPI créée en 2018 par Epsicap REIM, spécialisée dans les petites surfaces de bureaux et commerces dans les métropoles françaises. Elle cible des actifs facilement relocalisables avec une diversification locative importante.",
    "Coeur d'Europe": "SCPI européenne gérée par Advenis REIM depuis 2014, investissant dans les bureaux et commerces des capitales et métropoles européennes. Elle offre une diversification géographique européenne avec des actifs prime dans des villes dynamiques.",
    "Coeur de Région": "SCPI régionale créée en 2011 par Advenis REIM, concentrée sur les métropoles régionales françaises. Elle investit dans des bureaux, commerces et locaux d'activité situés dans des villes moyennes à fort potentiel de développement.",
    "Coeur de ville": "SCPI créée en 2012 par Advenis REIM, spécialisée dans les commerces de centre-ville et pieds d'immeubles. Elle vise des emplacements premium dans les rues commerçantes des principales villes françaises avec des baux longue durée.",
    "Comète": "SCPI innovante créée en 2023 par Alderan, spécialisée dans l'immobilier tertiaire international. Comète se distingue par sa stratégie d'investissement dynamique et son approche ESG renforcée, avec une diversification multi-pays.",
    "Cristal Life": "SCPI résidentielle lancée en 2019 par Cristal REIM, investissant dans des logements neufs ou récents en France. Elle bénéficie du régime fiscal Pinel et cible une clientèle d'investisseurs recherchant des revenus locatifs résidentiels sécurisés.",
    "Crédit Mutuel Pierre 1": "SCPI diversifiée du groupe Crédit Mutuel, créée en 2003 et gérée par ACM GFI. Elle investit dans des bureaux, commerces et actifs tertiaires en France avec une gestion prudente et une approche patrimoniale long terme.",
    "ESG Pierre Capital": "SCPI labellisée ISR créée en 2020 par Epsicap REIM, investissant dans des actifs tertiaires responsables en France. Elle intègre des critères ESG stricts dans sa sélection d'actifs et vise une performance durable.",
    "Edissimo": "SCPI historique créée en 1980 et gérée par Atland Voisin, spécialisée dans les commerces de proximité et pieds d'immeubles en France. Elle offre une forte diversification locative avec plus de 900 locaux répartis sur l'ensemble du territoire.",
    "Efimmo 1": "SCPI diversifiée créée en 1987 par Spirica, filiale du Crédit Agricole. Elle investit dans des bureaux, commerces et locaux d'activité en France avec une gestion patrimoniale stable et des distributions régulières.",
    "Ficommerce Proximité": "SCPI commerciale créée en 2007 par Fiducial Gérance, spécialisée dans les commerces de proximité et zones commerciales en France. Elle privilégie les emplacements stratégiques avec des baux longue durée et des enseignes nationales.",
    "Foncière des Praticiens": "SCPI médicale historique créée en 1991, gérée par Cie La Française Asset Management. Elle investit exclusivement dans l'immobilier médical et paramédical en France : cabinets médicaux, maisons de santé pluridisciplinaires et cliniques.",
    "Grand Paris Résidentiel": "SCPI résidentielle spécialisée dans le Grand Paris, créée en 2019 par Advltys. Elle investit dans des logements neufs ou récents dans les zones tendues d'Île-de-France, bénéficiant d'une forte demande locative.",
    "Immorente": "SCPI historique créée en 1959, gérée par Sofidy. C'est l'une des plus anciennes SCPI du marché français, investissant dans des bureaux, commerces et locaux d'activité diversifiés en France avec une gestion patrimoniale éprouvée.",
    "Iroko Zen": "SCPI spécialisée dans l'immobilier de santé, gérée par Iroko depuis 2017. Elle investit dans des établissements de santé modernes et des résidences seniors en Europe, bénéficiant du vieillissement démographique et d'une demande structurelle croissante.",
    "Kyaneos Pierre": "SCPI diversifiée créée en 2007 par Kyaneos AM, investissant dans des bureaux, commerces et actifs tertiaires en France. Elle privilégie une approche opportuniste avec des actifs value-add à fort potentiel de revalorisation.",
    "LF Avenir Santé": "SCPI de santé créée en 2018 par La Française REM, spécialisée dans les établissements de santé, cliniques et EHPAD en France et en Europe. Elle bénéficie de l'expertise reconnue de La Française sur le secteur médico-social.",
    "LF Europimmo": "SCPI européenne historique créée en 2003 par La Française REM, investissant dans des bureaux et commerces en Europe. Elle offre une diversification géographique européenne avec des actifs situés dans les principales capitales économiques.",
    "LF Grand Paris Patrimoine": "SCPI créée en 2015 par La Française REM, spécialisée dans les actifs résidentiels et tertiaires du Grand Paris. Elle vise des immeubles patrimoniaux dans des quartiers recherchés de la capitale et de sa proche banlieue.",
    "Log In": "SCPI logistique créée en 2018 par Advenis REIM, spécialisée dans les entrepôts et plateformes logistiques en France et en Europe. Elle bénéficie de la croissance structurelle de l'e-commerce et des besoins en logistique moderne.",
    "NCap Education Santé": "SCPI thématique créée en 2019 par NCap AM, investissant dans l'immobilier de santé et d'éducation en France. Elle cible des actifs défensifs avec des locataires institutionnels et des baux longue durée sécurisés.",
    "NCap Régions": "SCPI régionale créée en 2018 par NCap AM, investissant dans les métropoles régionales françaises. Elle privilégie des actifs tertiaires dans des villes moyennes dynamiques avec un bon rapport rendement-risque.",
    "Novapierre 1": "SCPI diversifiée créée en 2007 par Paref Gestion, investissant dans des bureaux, commerces et locaux d'activité en France. Elle offre une gestion active avec une stratégie d'arbitrage régulière pour optimiser la performance.",
    "Novapierre Résidentiel": "SCPI résidentielle créée en 2015 par Paref Gestion, spécialisée dans les logements neufs ou récents en France. Elle bénéficie du dispositif Pinel et vise une clientèle recherchant des revenus locatifs résidentiels stables.",
    "Novaxia NEO": "SCPI innovante créée en 2018 par Novaxia Investissement, spécialisée dans la transformation et la réhabilitation d'actifs tertiaires en France. Elle adopte une stratégie value-add avec des projets de repositionnement urbain.",
    "Opportunité Immo": "SCPI diversifiée créée en 2012 par Prima Pierre, investissant dans des bureaux, commerces et actifs opportunistes en France. Elle privilégie une approche flexible avec des acquisitions à fort potentiel de revalorisation.",
    "Optimale": "SCPI créée en 2006 par Sofidy, investissant dans des bureaux, commerces et locaux d'activité diversifiés en France. Elle vise une performance équilibrée entre rendement et valorisation du patrimoine.",
    "Paref Evo": "SCPI diversifiée créée en 2019 par Paref Gestion, investissant dans des actifs tertiaires en France et en Europe. Elle adopte une stratégie dynamique avec une gestion active du patrimoine et des arbitrages réguliers.",
    "Paref Hexa": "SCPI créée en 2017 par Paref Gestion, spécialisée dans les actifs tertiaires situés dans les six principales métropoles régionales françaises : Lyon, Marseille, Toulouse, Bordeaux, Nantes et Lille.",
    "Patrimmo Croissance Impact": "SCPI ISR créée en 2021 par Crédit Mutuel Asset Management, investissant dans des actifs tertiaires responsables en France. Elle intègre une démarche ESG exigeante et vise un impact environnemental et social positif.",
    "Perial Grand Paris": "SCPI créée en 2019 par Perial Asset Management, spécialisée dans les actifs tertiaires du Grand Paris. Elle investit dans des bureaux, commerces et actifs mixtes situés dans les zones les plus dynamiques d'Île-de-France.",
    "Perial Hospitalité Europe": "SCPI hôtelière européenne créée en 2019 par Perial Asset Management, investissant dans des hôtels d'affaires et de tourisme exploités par de grandes enseignes. Elle offre une exposition au secteur de l'hospitalité européenne.",
    "Perial O2": "SCPI diversifiée créée en 2016 par Perial Asset Management, investissant dans des bureaux, commerces et actifs tertiaires en France et en Europe. Elle privilégie des actifs core dans des emplacements stratégiques.",
    "Perial Opportunités Europe": "SCPI européenne créée en 2021 par Perial Asset Management, adoptant une stratégie opportuniste sur les actifs tertiaires européens. Elle vise des acquisitions value-add dans les principales capitales économiques.",
    "Remake Live": "SCPI résidentielle innovante de Remake AM, créée en 2018. Elle se concentre sur l'habitat du futur en France, avec des logements connectés et éco-responsables répondant aux nouveaux modes de vie urbains et aux attentes environnementales.",
    "Selectinvest 1": "SCPI diversifiée créée en 2006 par Norma Capital, investissant dans des bureaux, commerces et locaux d'activité en France. Elle privilégie une gestion patrimoniale prudente avec des actifs situés dans des zones dynamiques.",
    "Selectipierre 2": "SCPI créée en 2007 par Norma Capital, spécialisée dans les actifs tertiaires en France. Elle adopte une stratégie de diversification sectorielle et géographique avec une gestion active du patrimoine.",
    "Sofiprime": "SCPI historique créée en 1991 par Sofidy, investissant dans des bureaux et commerces de qualité en France. Elle vise des actifs prime dans les meilleurs emplacements avec une gestion patrimoniale long terme éprouvée.",
    "Transitions Europe": "SCPI européenne gérée par Arkéa REIM, axée sur la transition énergétique et digitale des bureaux. Créée en 2019, elle investit dans des actifs immobiliers durables et certifiés HQE, principalement en Allemagne, France et Espagne.",
    "Urban Coeur de Commerce": "SCPI commerciale créée en 2017 par Urban Premium, spécialisée dans les commerces de centre-ville et pieds d'immeubles. Elle vise des emplacements premium dans les principales artères commerçantes françaises.",
    "Épargne Foncière": "SCPI historique créée en 1965 par La Française REM, l'une des plus anciennes du marché. Elle investit dans des bureaux, commerces et actifs diversifiés en France avec une gestion patrimoniale éprouvée sur près de 60 ans.",
    "Épargne Pierre Europe": "SCPI européenne créée en 2014 par La Française REM, investissant dans des bureaux et commerces en Europe. Elle offre une diversification géographique avec des actifs situés dans les principales métropoles européennes.",
    "Épargne Pierre": "SCPI diversifiée historique créée en 1977 par La Française REM, investissant principalement en France dans des bureaux, commerces et actifs tertiaires. Elle bénéficie d'une gestion patrimoniale stable et d'une expérience de plus de 45 ans."
  };

  return presentations[scpi.name] || `${scpi.name} est une SCPI ${getSectorName(scpi.sector)} gérée par ${scpi.company}, créée en ${scpi.creation}. Cette SCPI investit principalement ${getGeographyName(scpi.geography)} dans des actifs immobiliers de qualité, offrant une stratégie d'investissement diversifiée et une gestion professionnelle reconnue.`;
};

export const getScpiAnalysis = (scpi: Scpi): string => {
  let analysis = "";
  
  if (scpi.yield >= 7) {
    analysis += "🔥 <strong>Très haute performance :</strong> Cette SCPI affiche un rendement exceptionnel supérieur à 7%. ";
  } else if (scpi.yield >= 5) {
    analysis += "✅ <strong>Bonne performance :</strong> Rendement attractif supérieur à 5%. ";
  } else if (scpi.yield >= 3.5) {
    analysis += "📊 <strong>Performance modérée :</strong> Rendement dans la moyenne du marché. ";
  } else {
    analysis += "⚠️ <strong>Performance faible :</strong> Rendement en dessous de la moyenne. ";
  }
  
  if (scpi.tof >= 95) {
    analysis += "Excellent taux d'occupation (>95%) témoignant d'une gestion solide. ";
  }
  
  const displayedDiscount = getDisplayedDiscount(scpi);
  if (displayedDiscount != null && displayedDiscount < -5) {
    analysis += "🎯 <strong>Opportunité d'achat :</strong> Forte décote sur le marché secondaire. ";
  }
  
  if (isProvenZeroFee(scpi)) {
    analysis += "💰 <strong>Avantage coût :</strong> Sans frais d'entrée, optimise votre investissement initial. ";
  }
  
  if (scpi.isr) {
    analysis += "🌱 <strong>Investissement responsable :</strong> Labellisé ISR pour un impact positif. ";
  }
  
  return analysis;
};

/**
 * Génère les points clés à retenir pour une lecture rapide (5 lignes max)
 * Format : Langage courant, sans jargon financier, pour débutants
 * Inclut des chiffres pour valider chaque affirmation
 * Répond à 5 questions : rapporte-t-il ? risqué ? biens loués ? prix raisonnable ? rôle ?
 * Personnalisé pour chaque SCPI selon ses caractéristiques spécifiques
 */
export const getScpiKeyTakeaways = (scpi: Scpi): string[] => {
  const takeaways: string[] = [];

  const isEurope = scpi.geography === 'europe' || scpi.european;
  const yieldValue = scpi.yield;
  const tofValue = scpi.tof;
  const debtValue = scpi.debt;
  const discountValue = getDisplayedDiscount(scpi);
  const capitalizationM = scpi.capitalization / 1000000;
  const nbImmeubles = scpi.nbImmeubles;
  const walt = scpi.walt;
  const sector = scpi.sector;
  const creation = scpi.creation;
  
  // Caractéristiques combinées pour personnalisation
  const isVeryLargeCap = capitalizationM >= 2000;
  const isLargeCap = capitalizationM >= 800;
  const isMediumCap = capitalizationM >= 300;
  const isHighYield = yieldValue >= 6.5;
  const isMediumYield = yieldValue >= 5.0 && yieldValue < 6.5;
  const isLowYield = yieldValue < 4.5;
  const isLowDebt = debtValue !== undefined && debtValue < 15;
  const isVeryLowDebt = debtValue !== undefined && debtValue < 5;
  const isModerateDebt = debtValue !== undefined && debtValue >= 15 && debtValue < 30;
  const isHighDebt = debtValue !== undefined && debtValue >= 30;
  const isHighTof = tofValue !== undefined && tofValue >= 95;
  const isGoodTof = tofValue !== undefined && tofValue >= 92 && tofValue < 95;
  const isModerateTof = tofValue !== undefined && tofValue >= 88 && tofValue < 92;
  const isLowTof = tofValue !== undefined && tofValue < 88;
  const isVeryDiversified = nbImmeubles !== undefined && nbImmeubles >= 200;
  const isDiversified = nbImmeubles !== undefined && nbImmeubles >= 100;
  const isLongLease = walt !== undefined && walt >= 7;
  const isOldScpi = creation < 2000;
  const isRecentScpi = creation >= 2015;

  // 1. 💰 EST-CE QUE ÇA RAPPORTE CORRECTEMENT ? (Rendement) - Personnalisé selon profil
  let revenus: string = '';
  const yieldFormatted = yieldValue.toFixed(2).replace('.', ',');
  
  // Cas spécifiques par secteur
  if (sector === 'logistique') {
    if (isHighYield) {
      revenus = `💰 Rendement élevé (${yieldFormatted}%), secteur logistique en forte croissance.`;
    } else if (isMediumYield) {
      revenus = `💰 Rendement régulier (${yieldFormatted}%), secteur logistique porteur.`;
    } else {
      revenus = `💰 Rendement modéré (${yieldFormatted}%), secteur logistique stable.`;
    }
  } else if (sector === 'sante') {
    if (isMediumYield || isHighYield) {
      revenus = `💰 Rendement régulier (${yieldFormatted}%), secteur de la santé très défensif.`;
    } else {
      revenus = `💰 Rendement modéré (${yieldFormatted}%), secteur de la santé stable et sécurisé.`;
    }
  } else if (sector === 'hotellerie') {
    if (isHighYield) {
      revenus = `💰 Rendement élevé (${yieldFormatted}%), secteur hôtelier dynamique mais plus volatile.`;
    } else {
      revenus = `💰 Rendement variable (${yieldFormatted}%) selon la saison, secteur hôtelier.`;
    }
  } else if (sector === 'commerces') {
    if (isMediumYield || isHighYield) {
      revenus = `💰 Rendement régulier (${yieldFormatted}%), commerce de proximité résilient.`;
    } else {
      revenus = `💰 Rendement modéré (${yieldFormatted}%), commerce traditionnel stable.`;
    }
  } else if (isEurope) {
    if (yieldValue >= 7.0) {
      revenus = `💰 Rendement élevé (${yieldFormatted}%), mais avec plus de risques liés à l'étranger.`;
    } else if (yieldValue >= 6.0) {
      revenus = `💰 Rendement régulier (${yieldFormatted}%), avec une partie des biens à l'étranger.`;
    } else if (yieldValue >= 5.0) {
      revenus = `💰 Rendement modéré (${yieldFormatted}%), avec une partie des biens à l'étranger.`;
    } else {
      revenus = `💰 Rendement faible (${yieldFormatted}%), avec une partie des biens à l'étranger.`;
    }
  } else {
    // France - logique personnalisée selon taille et profil
    if (isHighYield && isVeryLargeCap) {
      revenus = `💰 Rendement élevé (${yieldFormatted}%), grande SCPI bien établie.`;
    } else if (isHighYield && isLargeCap) {
      revenus = `💰 Rendement élevé (${yieldFormatted}%), SCPI de taille importante.`;
    } else if (isHighYield) {
      revenus = `💰 Rendement élevé (${yieldFormatted}%), mais attention aux risques.`;
    } else if (isMediumYield && isVeryLargeCap) {
      revenus = `💰 Rendement régulier (${yieldFormatted}%), grande SCPI sécurisée.`;
    } else if (isMediumYield && isLowDebt) {
      revenus = `💰 Rendement régulier (${yieldFormatted}%), sans prise de risque excessive.`;
    } else if (isMediumYield) {
      revenus = `💰 Rendement modéré (${yieldFormatted}%), fonctionnement prudent.`;
    } else if (isLowYield && isVeryLargeCap) {
      revenus = `💰 Rendement modéré (${yieldFormatted}%), mise sur la stabilité et la taille.`;
    } else {
      revenus = `💰 Rendement faible (${yieldFormatted}%), mise plutôt sur la valeur des biens.`;
    }
  }
  
  if (revenus) {
    takeaways.push(revenus);
  }

  // 2. 🛡️ EST-CE QUE C'EST RISQUÉ ? (Risque / sécurité) - Personnalisé
  if (debtValue !== undefined) {
    let risque: string = '';
    const debtFormatted = debtValue.toFixed(1).replace('.', ',');
    
    // Distinguer 0% (aucune dette) vs très peu de dettes
    if (debtValue === 0) {
      if (isVeryLargeCap) {
        risque = `🛡️ Aucune dette (${debtFormatted}%), grande SCPI très sécurisée.`;
      } else if (isLargeCap) {
        risque = `🛡️ Aucune dette (${debtFormatted}%), fonctionnement très prudent.`;
      } else {
        risque = `🛡️ Aucune dette (${debtFormatted}%), fonctionnement très prudent.`;
      }
    } else if (isVeryLowDebt && isVeryLargeCap) {
      risque = `🛡️ Très peu de dettes (${debtFormatted}%), grande SCPI très sécurisée.`;
    } else if (isVeryLowDebt && isLargeCap) {
      risque = `🛡️ Très peu de dettes (${debtFormatted}%), fonctionnement très prudent.`;
    } else if (isVeryLowDebt) {
      risque = `🛡️ Très peu de dettes (${debtFormatted}%), fonctionnement prudent.`;
    } else if (isLowDebt && isHighTof && isLargeCap) {
      risque = `🛡️ Peu de dettes (${debtFormatted}%), situation très sécurisée.`;
    } else if (isLowDebt && isHighTof) {
      risque = `🛡️ Peu de dettes (${debtFormatted}%), situation sécurisée.`;
    } else if (isLowDebt) {
      risque = `🛡️ Peu de dettes (${debtFormatted}%), situation sécurisée.`;
    } else if (isModerateDebt && isHighTof) {
      risque = `🛡️ Dettes maîtrisées (${debtFormatted}%), situation stable.`;
    } else if (isModerateDebt) {
      risque = `🛡️ Dettes modérées (${debtFormatted}%), situation stable.`;
    } else if (isHighDebt && isHighTof) {
      risque = `🛡️ Dettes importantes (${debtFormatted}%), mais occupation solide.`;
    } else if (isHighDebt) {
      risque = `🛡️ Dettes importantes (${debtFormatted}%), nécessite de l'attention.`;
    } else {
      risque = `🛡️ Dettes maîtrisées (${debtFormatted}%), situation stable.`;
    }
    
    if (risque) {
      takeaways.push(risque);
    }
  }

  // 3. 🏢 EST-CE QUE LES BIENS SONT LOUÉS ? (Location des biens) - Personnalisé
  if (tofValue !== undefined) {
    let location: string = '';
    const tofFormatted = tofValue.toFixed(1).replace('.', ',');
    
    // Distinguer 100% (tous loués) vs presque tous loués (95-99%)
    if (tofValue >= 99.5) {
      if (isVeryDiversified) {
        location = `🏢 Tous les biens loués (${tofFormatted}%), patrimoine très diversifié et excellente situation.`;
      } else if (isDiversified) {
        location = `🏢 Tous les biens loués (${tofFormatted}%), patrimoine diversifié et situation excellente.`;
      } else if (isLongLease) {
        location = `🏢 Tous les biens loués (${tofFormatted}%), baux longue durée sécurisés.`;
      } else {
        location = `🏢 Tous les biens loués (${tofFormatted}%), situation excellente.`;
      }
    } else if (isHighTof && isVeryDiversified) {
      location = `🏢 Biens presque tous loués (${tofFormatted}%), patrimoine très diversifié et excellente situation.`;
    } else if (isHighTof && isDiversified) {
      location = `🏢 Biens presque tous loués (${tofFormatted}%), patrimoine diversifié et situation excellente.`;
    } else if (isHighTof && isLongLease) {
      location = `🏢 Biens presque tous loués (${tofFormatted}%), baux longue durée sécurisés.`;
    } else if (isHighTof) {
      location = `🏢 Biens presque tous loués (${tofFormatted}%), situation excellente.`;
    } else if (isGoodTof && isVeryDiversified) {
      location = `🏢 Biens majoritairement loués (${tofFormatted}%), patrimoine très diversifié avec quelques changements normaux.`;
    } else if (isGoodTof && isLongLease) {
      location = `🏢 Biens majoritairement loués (${tofFormatted}%), baux longue durée avec quelques changements de locataires.`;
    } else if (isGoodTof) {
      location = `🏢 Biens majoritairement loués (${tofFormatted}%), avec quelques changements de locataires.`;
    } else if (isModerateTof && isDiversified) {
      location = `🏢 Biens majoritairement loués (${tofFormatted}%), patrimoine diversifié avec quelques vacances.`;
    } else if (isModerateTof) {
      location = `🏢 Biens majoritairement loués (${tofFormatted}%), avec quelques changements de locataires.`;
    } else if (isLowTof && isDiversified) {
      location = `🏢 Plusieurs biens vacants (${tofFormatted}%), patrimoine diversifié nécessitant du travail pour les relouer.`;
    } else if (isLowTof) {
      location = `🏢 Plusieurs biens vacants (${tofFormatted}%), nécessite du travail pour les relouer.`;
    } else {
      location = `🏢 Nombreux biens vacants (${tofFormatted}%), situation préoccupante.`;
    }
    
    if (location) {
      takeaways.push(location);
    }
  }

  // 4. 💵 EST-CE QUE LE PRIX EST RAISONNABLE ? (Prix d'achat) - Personnalisé
  if (discountValue !== undefined && discountValue !== null) {
    let prix: string = '';
    const discountFormatted = formatScpiDiscountPremium(discountValue);
    const discountAbs = Math.abs(discountValue);
    const discountAbsFormatted = formatScpiDiscountPremium(discountAbs).replace(/^\+/, '');
    
    // Combinaisons avec taille et TOF - Décote = bonne affaire
    if (discountValue <= -10 && isLargeCap) {
      prix = `💵 Bonne affaire (décote ${discountAbsFormatted}), grande SCPI en décote significative.`;
    } else if (discountValue <= -10) {
      prix = `💵 Bonne affaire (décote ${discountAbsFormatted}), prix d'achat intéressant.`;
    } else if (discountValue <= -5 && isHighTof) {
      prix = `💵 Bonne affaire (décote ${discountAbsFormatted}), prix en dessous de la valeur avec occupation solide.`;
    } else if (discountValue <= -5) {
      prix = `💵 Bonne affaire (décote ${discountAbsFormatted}), prix légèrement en dessous de la valeur.`;
    } else if (discountValue < 0 && discountValue > -5 && isHighTof && isLargeCap) {
      prix = `💵 Prix d'achat aligné avec la valeur (décote ${discountAbsFormatted}), grande SCPI bien occupée.`;
    } else if (discountValue < 0 && discountValue > -5) {
      prix = `💵 Prix d'achat proche de la valeur réelle (décote ${discountAbsFormatted}), sans bonne affaire particulière.`;
    } else if (discountValue === 0 || (discountValue > -1 && discountValue < 1)) {
      if (isHighTof && isLargeCap) {
        prix = `💵 Prix d'achat aligné avec la valeur (${discountFormatted}), grande SCPI bien occupée.`;
      } else {
        prix = `💵 Prix d'achat proche de la valeur réelle (${discountFormatted}), sans bonne affaire particulière.`;
      }
    } else if (discountValue <= 5 && isHighTof) {
      prix = `💵 Prix d'achat un peu élevé (surcote ${discountAbsFormatted}), mais occupation solide.`;
    } else if (discountValue <= 5) {
      prix = `💵 Prix d'achat un peu élevé (surcote ${discountAbsFormatted}) par rapport à la valeur réelle.`;
    } else if (discountValue <= 10 && isHighTof) {
      prix = `💵 Prix d'achat élevé (surcote ${discountAbsFormatted}), mais occupation solide.`;
    } else if (discountValue <= 10) {
      prix = `💵 Prix d'achat élevé (surcote ${discountAbsFormatted}) par rapport à la valeur réelle.`;
    } else {
      prix = `💵 Prix d'achat nettement au-dessus de la valeur réelle (surcote ${discountAbsFormatted}), à éviter.`;
    }
    
    if (prix) {
      takeaways.push(prix);
    }
  }

  // 5. 🧩 À QUOI ÇA SERT DANS UN PORTEFEUILLE ? (Rôle) - Très personnalisé
  let role: string = '';
  
  // Cas spécifiques par combinaison de caractéristiques
  if (isHighYield && isVeryLowDebt && isHighTof && isVeryLargeCap) {
    role = '🧩 Intéressant comme placement principal, excellent équilibre revenus et sécurité.';
  } else if (isHighYield && isLowDebt && isHighTof && isLargeCap) {
    role = '🧩 Intéressant comme placement principal, bon équilibre revenus et sécurité.';
  } else if (isMediumYield && isVeryLowDebt && isHighTof && isVeryLargeCap) {
    role = '🧩 Intéressant comme placement principal, très sécurisé et bien établi.';
  } else if (isLowDebt && isHighTof && isVeryLargeCap && isOldScpi) {
    role = '🧩 Intéressant comme placement principal, SCPI historique sécurisée.';
  } else if (isLowDebt && isHighTof && isLargeCap) {
    role = '🧩 Intéressant comme placement principal, sécurisé et bien établi.';
  } else if (isHighYield && isLowDebt && isGoodTof && isDiversified) {
    role = '🧩 Intéressant comme placement principal, bon équilibre revenus et sécurité.';
  } else if (isHighYield && isLowDebt && isGoodTof) {
    role = '🧩 Intéressant comme placement principal, bon équilibre revenus et sécurité.';
  } else if (isMediumYield && isVeryLowDebt && isGoodTof && isMediumCap) {
    role = '🧩 Intéressant en complément, sécurisé mais revenus modérés.';
  } else if (isVeryLowDebt && isGoodTof && isMediumCap && sector === 'sante') {
    role = '🧩 Intéressant en complément, secteur défensif et sécurisé.';
  } else if (isHighYield && !isLowDebt && isGoodTof) {
    role = '🧩 Intéressant en complément, rapporte bien mais nécessite de l\'attention.';
  } else if (isHighYield && isLowDebt && sector === 'logistique') {
    role = '🧩 Intéressant en complément, secteur porteur avec revenus élevés.';
  } else if (isHighYield && isLowDebt) {
    role = '🧩 Intéressant en complément d\'un portefeuille diversifié.';
  } else if (isMediumYield && isLowDebt && isGoodTof && isDiversified) {
    role = '🧩 Intéressant en complément d\'un portefeuille diversifié.';
  } else if (isMediumYield && isLowDebt && isGoodTof) {
    role = '🧩 Intéressant en complément d\'un portefeuille diversifié.';
  } else if (isLowDebt && isGoodTof && isRecentScpi) {
    role = '🧩 Intéressant en complément, SCPI récente sécurisée.';
  } else if (isLowDebt && isGoodTof) {
    role = '🧩 Intéressant en complément, sécurisé mais revenus modérés.';
  } else if (isLowDebt && isModerateTof && isDiversified) {
    role = '🧩 Intéressant en complément, diversifié mais occupation à surveiller.';
  } else if (sector === 'sante' && isLowDebt) {
    role = '🧩 Intéressant en complément, secteur défensif et sécurisé.';
  } else if (sector === 'logistique' && isMediumYield) {
    role = '🧩 Intéressant en complément, secteur porteur en croissance.';
  } else {
    role = '🧩 Intéressant en complément d\'un portefeuille diversifié.';
  }
  
  if (role) {
    takeaways.push(role);
  }

  // Limiter à 5 lignes maximum
  return takeaways.slice(0, 5);
};

/** Render the verified editorial facts faithfully, without deriving new statements. */
export const getScpiNews = (scpi: Scpi): string => {
  if (!scpi.actualitesTrimestrielles || !scpi.actualitePeriode || !scpi.actualiteDateDocument || !scpi.actualiteSourceDocument || !scpi.actualiteSourceUrl) return '';
  const escapeHtml = (value: string) => value
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
  const facts = scpi.actualitesTrimestrielles.split(' | ').map(fact => fact.trim()).filter(Boolean);
  return facts.length ? `<ul class="list-disc pl-5 space-y-1">${facts.map(fact => `<li>${escapeHtml(fact)}</li>`).join('')}</ul>` : '';
};

const getSectorName = (sector: string): string => {
  const sectorNames: Record<string, string> = {
    'bureaux': 'de bureaux',
    'commerces': 'commerciale',
    'residentiel': 'résidentielle',
    'sante': 'de santé',
    'logistique': 'logistique',
    'hotellerie': 'd\'hôtellerie',
    'diversifie': 'diversifiée'
  };

  return sectorNames[sector] || 'diversifiée';
};

const getGeographyName = (geography: string): string => {
  const geoNames: Record<string, string> = {
    'france': 'en France',
    'europe': 'en Europe',
    'international': 'à l\'international'
  };
  
  return geoNames[geography] || 'en France';
};
