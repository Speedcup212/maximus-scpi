import { hasAnalyticsConsent, hasAudienceOptOut } from './analyticsConsent';
import { getAttribution, persistAttribution } from './attribution';

export type FunnelEventName =
  | 'quiz_started'
  | 'quiz_step_1_completed'
  | 'quiz_step_2_completed'
  | 'quiz_step_3_completed'
  | 'quiz_completed'
  | 'analysis_opened'
  | 'scpi_detail_opened'
  | 'hero_portfolio_clicked'
  | 'portfolio_validation_clicked'
  | 'simulation_start'
  | 'simulation_result'
  | 'qualified_50k'
  | 'rdv_click'
  | 'lead_form_opened'
  | 'lead_form_submitted'
  | 'calendly_opened'
  | 'calendly_booking_completed'
  | 'simulation_email_viewed'
  | 'simulation_email_submitted'
  | 'simulation_email_calendly_clicked';

type FunnelMetadata = Record<string, string | number | boolean | null | undefined>;

const SESSION_KEY = 'maximus_funnel_session_id';

let memorySessionId: string | null = null;

const getSessionId = () => {
  try {
    let sessionId = sessionStorage.getItem(SESSION_KEY);
    if (!sessionId) {
      sessionId = crypto.randomUUID();
      sessionStorage.setItem(SESSION_KEY, sessionId);
    }
    return sessionId;
  } catch {
    // sessionStorage bloqué : identifiant gardé en mémoire pour la page.
    memorySessionId = memorySessionId || crypto.randomUUID();
    return memorySessionId;
  }
};

const sanitizeMetadata = (metadata: FunnelMetadata) => {
  const allowed = new Set([
    'step',
    'source',
    'scpi_id',
    'scpi_name',
    'portfolio_size',
    'form_type',
    'action',
    'lead_request_id',
    'amount',
    'yield_rate',
    'origin',
    'horizon',
    'threshold',
    'utm_source',
    'utm_medium',
    'utm_campaign',
    'tranche_montant',
    'consent_marketing',
  ]);

  return Object.fromEntries(
    Object.entries(metadata)
      .filter(([key, value]) => allowed.has(key) && value !== undefined)
      .map(([key, value]) => [
        key,
        typeof value === 'string' ? value.slice(0, 160) : value,
      ]),
  );
};

const sendFirstPartyEvent = (
  eventName: FunnelEventName,
  sessionId: string,
  metadata: FunnelMetadata,
) => {
  // First-party operational funnel log. Never blocks the user journey.
  void fetch('/api/funnel-event', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    keepalive: true,
    body: JSON.stringify({
      event_name: eventName,
      session_id: sessionId,
      path: window.location.pathname,
      metadata,
    }),
  }).catch(() => undefined);
};

export const trackFunnelEvent = (
  eventName: FunnelEventName,
  metadata: FunnelMetadata = {},
) => {
  if (typeof window === 'undefined' || hasAudienceOptOut()) return;

  if (!hasAnalyticsConsent()) {
    // RECOVERY-203 — mesure d'audience exemptée de consentement (CNIL) :
    // statistiques internes anonymes, pour le seul compte de MaximusSCPI.
    // Aucun tiers (GTM, GA4, Ads), aucune écriture d'UTM en sessionStorage,
    // et aucun lien avec une fiche de contact (lead_request_id retiré).
    const exemptMetadata = sanitizeMetadata({ ...metadata, ...getAttribution() });
    delete exemptMetadata.lead_request_id;
    sendFirstPartyEvent(eventName, getSessionId(), {
      ...exemptMetadata,
      measurement: 'exempt',
    });
    return;
  }

  persistAttribution();
  const safeMetadata = sanitizeMetadata({ ...metadata, ...getAttribution() });
  const sessionId = getSessionId();

  // GTM / GA4 can consume the exact same event names.
  const dataLayer = (window as Window & { dataLayer?: unknown[] }).dataLayer;
  if (Array.isArray(dataLayer)) {
    // The request UUID belongs exclusively in our first-party audit log.
    // Third-party GTM tags must never receive a contact-submission identifier.
    const publicMetadata = Object.fromEntries(
      Object.entries(safeMetadata).filter(([key]) => key !== 'lead_request_id'),
    );
    dataLayer.push({ event: eventName, ...publicMetadata });
  }

  // GA4 receives a confirmed business milestone, not an unvalidated CTA click.
  // Never send contact details, a request ID, or other personal identifiers to GA4.
  // Only the published domain is eligible; local and preview browsing is excluded.
  const ga4Event = eventName === 'lead_form_submitted'
    ? 'generate_lead'
    : eventName === 'calendly_booking_completed'
      ? 'book_appointment'
      : null;
  const hostname = window.location.hostname.toLowerCase();
  if (ga4Event && (hostname === 'maximusscpi.com' || hostname === 'www.maximusscpi.com')) {
    window.gtag?.('event', ga4Event, {
      form_type: safeMetadata.form_type || 'unknown',
      lead_action: safeMetadata.action || 'unknown',
      page_path: window.location.pathname,
    });
  }

  sendFirstPartyEvent(eventName, sessionId, safeMetadata);
};
