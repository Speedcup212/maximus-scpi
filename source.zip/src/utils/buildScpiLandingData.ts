import { scpiLandingPages, ScpiLandingData } from '../data/landingPagesData';
import { scpiData } from '../data/scpiData';
import { createSlugFromName } from './scpiSlugMapper';
import { qualifyYield } from './yieldContext';
import { calculateScpiDiscountPremium, formatScpiDiscountPremium } from './scpiDiscountPremium';
import { Scpi } from '../types/scpi';

/**
 * Source unique de la donnée alimentant le template `OptimizedScpiLandingPage`.
 *
 * Objectif : conserver l'architecture de pages des SCPI déjà publiées,
 * sans imposer Iroko Atlas comme modèle unique. Iroko Atlas illustre la fiche
 * générée ; Comète et Transitions Europe illustrent des fiches éditoriales.
 * Le contenu spécifique et sourcé de chaque SCPI reste distinct.
 *
 * - Si une fiche éditoriale existe (`scpiLandingPages`), on l'utilise telle quelle.
 * - Sinon, on GÉNÈRE une fiche par défaut depuis les données live (`scpiData`),
 *   avec fallbacks propres. Le flag `_generated` permet au template de masquer
 *   le bloc « Verdict MaximusSCPI » (décision validée : pas d'argument non sourcé
 *   pour les SCPI sans contenu rédigé).
 *
 * Retourne `null` uniquement si le slug ne correspond à aucune SCPI connue.
 */

const NA = 'Non disponible';

// Candidate values from an older appraisal must NOT create a discount to the
// current subscription price. Require an independently publishable comparability
// verdict for every newly released product.
function qualifiedDiscount(scpi: Scpi): string {
  if (scpi.maximusDataStatus === 'certified_and_final_reviewed' &&
      scpi.discountQaStatus !== 'publishable') return NA;
  return formatScpiDiscountPremium(calculateScpiDiscountPremium(scpi.price, scpi.valeurReconstitution));
}

function formatCurrency(amount: number | null | undefined): string {
  if (typeof amount !== 'number' || !Number.isFinite(amount)) return NA;
  if (amount >= 1_000_000_000) return (amount / 1_000_000_000).toFixed(1) + ' Md€';
  if (amount >= 1_000_000) return Math.round(amount / 1_000_000) + ' M€';
  return Math.round(amount) + ' €';
}

function formatPercent(value: number | null | undefined): string {
  if (typeof value !== 'number' || !Number.isFinite(value)) return NA;
  return value.toFixed(2) + '%';
}

function repartitionToRecord(
  rep: { name: string; value: number }[] | undefined
): Record<string, number> {
  if (!rep || rep.length === 0) return {};
  const out: Record<string, number> = {};
  for (const { name, value } of rep) {
    if (name && typeof value === 'number' && Number.isFinite(value)) {
      out[name] = value;
    }
  }
  return out;
}

function formatFees(value: number | null | undefined): string {
  if (value === 0) return '0%';
  return formatPercent(value);
}

function buildLiveShortDescription(scpi: Scpi): string {
  const parts = [
    `SCPI gérée par ${scpi.company || 'sa société de gestion'}`,
    Number.isFinite(scpi.yield) ? `taux de distribution ${formatPercent(scpi.yield)}` : null,
    Number.isFinite(scpi.tof) ? `TOF ${formatPercent(scpi.tof)}` : null,
    Number.isFinite(scpi.capitalization) ? `capitalisation ${formatCurrency(scpi.capitalization)}` : null,
  ].filter(Boolean);

  return parts.join(' · ') + '.';
}

function enrichEditorialWithLive(editorial: ScpiLandingData, scpi?: Scpi): ScpiLandingData {
  if (!scpi) return editorial;

  const liveGeo = repartitionToRecord(scpi.repartitionGeo);
  const liveSectors = repartitionToRecord(scpi.repartitionSector);

  return {
    ...editorial,
    nom: scpi.name,
    slug: createSlugFromName(scpi.name),
    h1_question: `SCPI ${scpi.name} : analyse, rendement et points de vigilance`,
    societe_gestion: scpi.company || editorial.societe_gestion,
    annee_creation: scpi.creation || editorial.annee_creation,
    label_isr: !!scpi.isr,
    capitalisation: formatCurrency(scpi.capitalization),
    prix_souscription: formatCurrency(scpi.price),
    rendement: formatPercent(scpi.yield),
    tof: formatPercent(scpi.tof),
    decote: qualifiedDiscount(scpi),
    endettement: typeof scpi.debt === 'number' ? formatPercent(scpi.debt) : editorial.endettement,
    frais_souscription: formatFees(scpi.fees),
    frequence_versement: scpi.versementLoyers || editorial.frequence_versement,
    geographie: Object.keys(liveGeo).length ? liveGeo : editorial.geographie,
    secteurs: Object.keys(liveSectors).length ? liveSectors : editorial.secteurs,
    avantages: buildFactualAdvantages(scpi),
    points_attention: buildFactualWarnings(scpi),
    description_courte: buildLiveShortDescription(scpi),
  };
}

/** Avantages strictement factuels (aucun argument marketing non sourcé). */
function buildFactualAdvantages(scpi: Scpi): string[] {
  const out: string[] = [];
  if (scpi.fees === 0) out.push("0 % de frais de souscription : capital investi à 100 %.");
  if (scpi.isr) out.push("Labellisée ISR (Investissement Socialement Responsable).");
  if (typeof scpi.tof === 'number' && scpi.tof >= 90) {
    out.push(`Taux d'occupation financier élevé (${formatPercent(scpi.tof)}).`);
  }
  if (typeof scpi.capitalization === 'number' && scpi.capitalization >= 100_000_000) {
    out.push(`Capitalisation de ${formatCurrency(scpi.capitalization)}.`);
  }
  if (scpi.european) out.push("Diversification européenne.");
  return out;
}

/** Points de vigilance factuels, sourcés sur les indicateurs. */
function buildFactualWarnings(scpi: Scpi): string[] {
  const out: string[] = [];
  const age = scpi.creation ? new Date().getFullYear() - scpi.creation : null;
  if (age !== null && age < 3) {
    out.push("SCPI récente : track record court, performances peu représentatives sur la durée.");
  }
  if (typeof scpi.fees === 'number' && scpi.fees >= 10) {
    out.push(`Frais de souscription élevés (${formatPercent(scpi.fees)}).`);
  }
  if (scpi.fraisGestionDetails?.kind === 'geographic_tiers') {
    out.push('Frais de gestion géographiques distincts : ' +
      scpi.fraisGestionDetails.euro_zone_percent.toFixed(2).replace('.', ',') +
      ' % HT zone euro / ' +
      scpi.fraisGestionDetails.outside_euro_zone_percent.toFixed(2).replace('.', ',') +
      ' % HT hors zone euro, sur loyers encaissés. Aucun taux moyen calculé.');
  }
  const topSector = scpi.repartitionSector?.slice().sort((a, b) => b.value - a.value)[0];
  if (topSector && topSector.value >= 50) {
    out.push(`Concentration sectorielle : ${topSector.name} représente ${topSector.value.toFixed(0)} % du patrimoine.`);
  }
  return out;
}

/** Variantes de clé à tester (avec/sans préfixe `scpi-`). */
function slugVariants(key: string): string[] {
  const lower = key.toLowerCase();
  const variants = new Set<string>([lower]);
  if (lower.startsWith('scpi-')) variants.add(lower.slice('scpi-'.length));
  return [...variants];
}

function findScpiBySlug(slug: string): Scpi | undefined {
  const variants = slugVariants(slug);
  return scpiData.find((s) => variants.includes(createSlugFromName(s.name)));
}

export interface BuiltLandingData {
  data: ScpiLandingData;
  isEditorial: boolean;
}

export function buildScpiLandingData(scpiKey: string): BuiltLandingData | null {
  const variants = slugVariants(scpiKey);
  const publicScpi = findScpiBySlug(scpiKey);

  // Une fiche éditoriale legacy ne doit jamais contourner la cohorte publique certifiée.
  // Si le slug n'existe pas dans scpiData (déjà filtré sur les 61 certifiées), la fiche
  // n'est pas publiée, même si une ancienne entrée subsiste dans landingPagesData.
  if (!publicScpi) return null;

  // 1. Fiche éditoriale par clé directe (avec/sans préfixe scpi-).
  for (const v of variants) {
    const direct = scpiLandingPages[v];
    if (direct) {
      const live = findScpiBySlug(direct.slug) || publicScpi;
      return { data: enrichEditorialWithLive(direct, live), isEditorial: true };
    }
  }

  // 2. Fiche éditoriale par slug.
  const bySlug = Object.values(scpiLandingPages).find((d) => variants.includes(d.slug));
  if (bySlug) {
    const live = findScpiBySlug(bySlug.slug) || publicScpi;
    return { data: enrichEditorialWithLive(bySlug, live), isEditorial: true };
  }

  // 3. Génération depuis les données live (slug normalisé sans préfixe scpi-).
  const scpi = findScpiBySlug(scpiKey);
  if (!scpi) return null;

  const yq = qualifyYield(scpi.yield);
  const generated: ScpiLandingData = {
    nom: scpi.name,
    slug: createSlugFromName(scpi.name),
    h1_question: `SCPI ${scpi.name} : analyse, rendement et points de vigilance`,
    societe_gestion: scpi.company || NA,
    annee_creation: scpi.creation || 0,
    label_isr: !!scpi.isr,
    capitalisation: formatCurrency(scpi.capitalization),
    prix_souscription: formatCurrency(scpi.price),
    rendement: formatPercent(scpi.yield),
    tof: formatPercent(scpi.tof),
    decote: qualifiedDiscount(scpi),
    endettement: typeof scpi.debt === 'number' ? formatPercent(scpi.debt) : NA,
    frais_souscription: typeof scpi.fees === 'number' ? formatFees(scpi.fees) : NA,
    frequence_versement: scpi.versementLoyers || undefined,
    geographie: repartitionToRecord(scpi.repartitionGeo),
    secteurs: repartitionToRecord(scpi.repartitionSector),
    avantages: buildFactualAdvantages(scpi),
    description_courte: buildLiveShortDescription(scpi),
    description_longue: '',
    pourquoi_investir: [],
    points_attention: buildFactualWarnings(scpi),
    profil_investisseur: '',
    simulator: {
      defaultInvestment: 10000,
      defaultYield: Number.isFinite(scpi.yield) ? scpi.yield : 0,
      title: `Simulez vos revenus avec ${scpi.name}`,
      subtitle: 'Simulation indicative — performances non garanties',
      theme: 'blue',
    },
    _generated: true,
  };

  return { data: generated, isEditorial: false };
}
