import React from 'react';
import type { CaseStatus, ProfileStatus } from '../types';

type StatusBadgeProps = {
  status: CaseStatus | ProfileStatus;
};

const statusStyles: Record<string, string> = {
  pending: 'bg-amber-500/10 text-amber-200 border-amber-400/30',
  active: 'bg-emerald-500/10 text-emerald-200 border-emerald-400/30',
  suspended: 'bg-red-500/10 text-red-200 border-red-400/30',
  new: 'bg-slate-500/10 text-slate-200 border-slate-400/30',
  in_progress: 'bg-blue-500/10 text-blue-200 border-blue-400/30',
  sent: 'bg-emerald-500/10 text-emerald-200 border-emerald-400/30',
  closed: 'bg-zinc-500/10 text-zinc-200 border-zinc-400/30'
};

const statusLabels: Record<string, string> = {
  pending: 'En attente',
  active: 'Actif',
  suspended: 'Suspendu',
  new: 'Nouveau',
  in_progress: 'En cours',
  sent: 'Envoyé',
  closed: 'Clos'
};

const StatusBadge: React.FC<StatusBadgeProps> = ({ status }) => {
  return (
    <span className={`inline-flex items-center rounded-full border px-2.5 py-1 text-xs font-semibold ${statusStyles[status] || ''}`}>
      {statusLabels[status] || status}
    </span>
  );
};

export default StatusBadge;
