import React, { useEffect, useState } from 'react';
import { PieChart, Calculator } from 'lucide-react';
import SEOHead from './SEOHead';
import SemanticLinks from './SemanticLinks';
import MoneyPageTools from './MoneyPageTools';
import DynamicArticlePage from './DynamicArticlePage';
import { getSemanticLinks } from '../data/semanticCocon';
import { getTemplateBySlug } from '../data/articleTemplatesConfig';
import { generateBreadcrumbSchema, generateArticleSchema } from '../utils/seoOptimizer';
import { supabase } from '../supabaseClient';
import { getArticleComponent } from '../utils/articleComponentsMap';

interface OptimizedArticlePageProps {
  slug: string;
  onArticleClick?: (slug: string) => void;
  onThematicClick?: (theme: string) => void;
}

interface ArticleData {
  id: string;
  slug: string;
  title: string;
  meta_description: string;
  keywords: string[];
  category: string;
  main_keyword: string;
  search_intent: string;
  target_audience: string;
  component_name: string;
  excerpt: string;
  word_count: number;
  read_time: number;
  featured: boolean;
  status: string;
  published_at: string;
  intro: string | null;
  content_html: string | null;
}

const SupabaseArticlePage: React.FC<{ slug: string }> = ({ slug }) => {
  const [article, setArticle] = useState<ArticleData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;

    async function loadArticle() {
      try {
        setLoading(true);
        setError(null);
        setArticle(null);

        if (!supabase) {
          if (!cancelled) setError('Article non trouvé');
          return;
        }

        const { data, error: fetchError } = await supabase
          .from('articles_seo')
          .select('*')
          .eq('slug', slug)
          .eq('status', 'published')
          .maybeSingle();

        if (fetchError) {
          console.warn('Article Supabase indisponible:', fetchError);
          if (!cancelled) setError('Article non trouvé');
          return;
        }

        if (!data) {
          if (!cancelled) setError('Article non trouvé');
          return;
        }

        if (!cancelled) setArticle(data);
      } catch (err) {
        console.warn('Chargement Supabase impossible:', err);
        if (!cancelled) setError('Article non trouvé');
      } finally {
        if (!cancelled) setLoading(false);
      }
    }

    loadArticle();
    return () => {
      cancelled = true;
    };
  }, [slug]);

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0f172a] flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-500 mx-auto mb-4"></div>
          <p className="text-slate-400">Chargement de l'article...</p>
        </div>
      </div>
    );
  }

  if (error || !article) {
    return (
      <div className="min-h-screen bg-[#0f172a] flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-white mb-4">
            {error || 'Article non trouvé'}
          </h1>
          <a href="/" className="text-emerald-400 hover:text-emerald-300 hover:underline">Retour à l'accueil</a>
        </div>
      </div>
    );
  }

  const hasContentHtml = article.content_html && article.content_html.trim().length > 0;
  const cleanedHtml = hasContentHtml ? cleanArticleHtml(article.content_html!) : '';
  const mappedComponent = getArticleComponent(article.component_name);

  const breadcrumbSchema = generateBreadcrumbSchema([
    { name: 'Accueil', url: 'https://maximusscpi.com' },
    { name: 'Articles', url: 'https://maximusscpi.com/#articles' },
    { name: article.title, url: `https://maximusscpi.com/articles/${slug}` }
  ]);

  const articleSchema = generateArticleSchema({
    headline: article.title,
    description: article.meta_description,
    author: 'Éric Bellaiche',
    datePublished: article.published_at || '2026-01-20',
    dateModified: article.published_at || '2026-01-20',
    image: 'https://maximusscpi.com/images/eric-192.webp'
  });

  return (
    <>
      <SEOHead
        title={`${article.title} | MaximusSCPI`}
        description={article.meta_description}
        keywords={article.keywords}
        canonical={`https://maximusscpi.com/articles/${slug}/`}
        schemaData={[breadcrumbSchema, articleSchema]}
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <MoneyPageTools slug={slug} />

        {hasContentHtml ? (
          <article className="max-w-none">
            <div className="article-prose" dangerouslySetInnerHTML={{ __html: cleanedHtml }} />
          </article>
        ) : mappedComponent ? (
          <article className="max-w-none">
            {React.createElement(mappedComponent)}
          </article>
        ) : (
          <div className="min-h-[40vh] flex items-center justify-center">
            <div className="text-center">
              <h1 className="text-2xl font-bold text-slate-900 dark:text-white mb-4">Article non trouvé</h1>
              <a href="/articles/" className="text-emerald-600 hover:underline">Voir les articles</a>
            </div>
          </div>
        )}

        <div className="my-16 bg-gradient-to-r from-blue-600 to-blue-800 dark:from-blue-800 dark:to-blue-900 rounded-2xl p-8 text-center text-white shadow-2xl">
          <h2 className="text-3xl font-bold mb-4">Besoin d'un conseil personnalisé ?</h2>
          <p className="text-xl mb-6 text-blue-100 max-w-2xl mx-auto">
            Nos conseillers certifiés ORIAS analysent votre situation et vous proposent une stratégie SCPI adaptée à votre profil.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="/comparateur-scpi"
              className="bg-white text-blue-700 font-bold py-4 px-8 rounded-xl hover:bg-blue-50 transition-all shadow-lg hover:scale-105 inline-flex items-center justify-center gap-2"
            >
              <PieChart className="w-5 h-5" />
              Comparer 50+ SCPI
            </a>
            <a
              href="/simulateur-enveloppes"
              className="bg-blue-500 text-white font-bold py-4 px-8 rounded-xl hover:bg-blue-600 transition-all border-2 border-white/30 hover:scale-105 inline-flex items-center justify-center gap-2"
            >
              <Calculator className="w-5 h-5" />
              Simuler mon allocation
            </a>
          </div>
        </div>

        <SemanticLinks
          currentPage={`/articles/${slug}`}
          links={getSemanticLinks(`/articles/${slug}`)}
          title="Poursuivez votre découverte des SCPI"
        />
      </div>
    </>
  );
};

const OptimizedArticlePage: React.FC<OptimizedArticlePageProps> = ({ slug }) => {
  // Les articles du catalogue local ont une source React versionnée et autoritaire.
  // Ils ne doivent jamais dépendre de Supabase pour leur rendu utilisateur ou leur pré-rendu SEO.
  if (getTemplateBySlug(slug)) {
    return <DynamicArticlePage slug={slug} />;
  }

  return <SupabaseArticlePage slug={slug} />;
};

function cleanArticleHtml(raw: string): string {
  return raw
    .replace(/```html/gi, '')
    .replace(/```/g, '')
    .replace(/^\s*#{1,6}\s+/gm, '')
    .trim();
}

export default OptimizedArticlePage;
