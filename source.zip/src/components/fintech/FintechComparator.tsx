import React, { useState, useEffect, useMemo, lazy, Suspense } from 'react';
import { Search, SlidersHorizontal, X, Grid3x3, List, ChevronLeft, ChevronRight, Calculator } from 'lucide-react';
import { scpiDataExtended, SCPIExtended } from '../../data/scpiDataExtended';
import { scpiData } from '../../data/scpiData';
import { calculateScpiDiscountPremium } from '../../utils/scpiDiscountPremium';
import { AllocationProvider } from '../../contexts/AllocationContext';
import { SubscriptionProvider } from '../../contexts/SubscriptionContext';
import SCPICardDark from './SCPICardDark';
import SCPITableRow from './SCPITableRow';
import MobileSelectionBar from './MobileSelectionBar';
import type { FilterState } from './FilterPanel';
import { sortSCPIByTaxOptimization, shouldOptimizeForTax, getTaxOptimizationScore } from '../../utils/taxOptimization';
import { matchesSectorFilter, calculateSectorRelevanceScore } from '../../utils/sectorQualification';
import { enrichScpiExtendedArray } from '../../utils/enrichScpiExtended';
import { getLatestScoresBatch } from '../../utils/scpiScoreService';
import { createSlugFromName } from '../../utils/scpiSlugMapper';
import { computeClientScores } from '../../utils/computeClientScores';
import ComparisonWarning from '../ComparisonWarning';
import Toast from '../Toast';
import { getLiveScpiDataBatch } from '../../utils/scpiLiveData';

const SelectionSidebar = lazy(() => import('./SelectionSidebar'));
const AnalysisDetailModal = lazy(() => import('./AnalysisDetailModal'));
const FilterPanel = lazy(() => import('./FilterPanel'));
const SimulationModal = lazy(() =>
  import('../simulation').then(module => ({ default: module.SimulationModal }))
);

type ViewMode = 'grid' | 'list';

interface FintechComparatorContentProps {
  onCloseAnalysis?: () => void;
  onGuidedJourneyClick?: () => void;
  hideTitle?: boolean;
  zScoreVariant?: 'full' | 'compact';
}

const FintechComparatorContent: React.FC<FintechComparatorContentProps> = ({
  onCloseAnalysis,
  onGuidedJourneyClick,
  hideTitle = false,
  zScoreVariant = 'full'
}) => {
  const [selectedScpis, setSelectedScpis] = useState<SCPIExtended[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [isSimulationOpen, setIsSimulationOpen] = useState(false);
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const [sortBy, setSortBy] = useState<'yield' | 'price'>('yield');
  const [viewMode, setViewMode] = useState<ViewMode>('grid');
  const [currentPage, setCurrentPage] = useState(1);
  const [analysisScpi, setAnalysisScpi] = useState<SCPIExtended | null>(null);
  const [toastMessage, setToastMessage] = useState<string>('');
  const [showToast, setShowToast] = useState<boolean>(false);
  const [savedScrollPosition, setSavedScrollPosition] = useState<number>(0);
  const [scoresBySlug, setScoresBySlug] = useState<Record<string, number>>({});
  const [liveScpiData, setLiveScpiData] = useState(scpiData);
  const [filters, setFilters] = useState<FilterState>({
    tmi: null,
    minYield: 0,
    priceRange: 'all',
    geographies: [],
    sectors: [],
    sectorThreshold: '25', // Par défaut : exposition significative (≥25%)
    hasISR: null,
    noEntryFees: false,
    expertMode: false,
    discountRange: [-15, 10],
    minRanDays: 0,
    maxLtv: 100,
    noWaitingShares: false
  });

  // Les données statiques assurent le rendu instantané ; Supabase les remplace
  // par les derniers indicateurs validés dès qu'ils sont disponibles.
  useEffect(() => {
    let active = true;

    void getLiveScpiDataBatch(scpiData).then((live) => {
      if (active) setLiveScpiData(live);
    });

    return () => {
      active = false;
    };
  }, []);

  const enrichedScpiData = useMemo(() => {
    const enriched = enrichScpiExtendedArray(scpiDataExtended, liveScpiData);
    const parefEvo = enriched.find(s => s.name === 'Paref Evo');
    if (!parefEvo) {
      console.warn('[FintechComparator] Paref Evo non trouvé dans enrichedScpiData');
    }
    return enriched;
  }, [liveScpiData]);

  // Note MaximusSCPI calculée côté client sur l'ensemble de la cohorte (percentile cohérent).
  // Source de vérité de la note affichée ; Supabase reste une surcouche optionnelle.
  const clientScoreResults = useMemo(
    () => computeClientScores(enrichedScpiData),
    [enrichedScpiData]
  );
  const clientScoresBySlug = clientScoreResults.bySlug;
  const clientScoresById = clientScoreResults.byId;

  const toggleSelect = (scpi: SCPIExtended) => {
    setSelectedScpis(prev => {
      const exists = prev.find(s => s.id === scpi.id);
      if (exists) {
        return prev.filter(s => s.id !== scpi.id);
      }
      if (prev.length >= 6) {
        if (typeof window !== 'undefined') {
          window.alert('Vous pouvez sélectionner jusqu’à 6 SCPI maximum dans votre portefeuille.');
        }
        return prev;
      }
      return [...prev, scpi];
    });
  };

  const applyFilters = (scpi: SCPIExtended): boolean => {
    if (scpi.yield < filters.minYield) return false;

    if (filters.priceRange !== 'all') {
      if (filters.priceRange === 'accessible' && scpi.price >= 300) return false;
      if (filters.priceRange === 'standard' && (scpi.price < 300 || scpi.price > 1000)) return false;
      if (filters.priceRange === 'premium' && scpi.price <= 1000) return false;
    }

    if (filters.geographies.length > 0) {
      const hasMatchingGeo = scpi.geography.some(geo => {
        const geoName = geo.name.toLowerCase();
        if (filters.geographies.includes('France') &&
            (geoName.includes('france') || geoName.includes('paris') || geoName.includes('région'))) {
          return true;
        }
        if (filters.geographies.includes('Europe') &&
            !geoName.includes('france') && !geoName.includes('paris') &&
            (geoName.includes('europe') || geoName.includes('allemagne') || geoName.includes('espagne') ||
             geoName.includes('italie') || geoName.includes('belgique') || geoName.includes('pays-bas') ||
             geoName.includes('irlande') || geoName.includes('portugal') || geoName.includes('pologne'))) {
          return true;
        }
        if (filters.geographies.includes('International') &&
            (geoName.includes('royaume') || geoName.includes('étranger') || geoName.includes('ocde'))) {
          return true;
        }
        return false;
      });
      if (!hasMatchingGeo) return false;
    }

    if (filters.sectors.length > 0) {
      // Utiliser la nouvelle logique de filtrage avec seuil
      if (!matchesSectorFilter(scpi, filters.sectors, filters.sectorThreshold)) {
        return false;
      }
    }

    if (filters.expertMode) {
      if (scpi.reconstitutionValue) {
        const discount = calculateScpiDiscountPremium(scpi.price, scpi.reconstitutionValue);
        if (discount == null || discount < filters.discountRange[0] || discount > filters.discountRange[1]) {
          return false;
        }
      }

      if (scpi.ranDays !== undefined && scpi.ranDays < filters.minRanDays) {
        return false;
      }

      if (scpi.ltv !== undefined && scpi.ltv > filters.maxLtv) {
        return false;
      }

      if (filters.noWaitingShares && scpi.hasWaitingShares) {
        return false;
      }
    }

    return true;
  };

  // Créer une copie profonde pour éviter les mutations sur des tableaux gelés en production
  // Utiliser les données enrichies avec les informations du fichier Excel
  let filteredData = [...enrichedScpiData].filter(scpi =>
    (scpi.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    scpi.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
    scpi.managementCompany.toLowerCase().includes(searchQuery.toLowerCase())) &&
    applyFilters(scpi)
  );

  // Tri : priorité fiscale Europe à TMI >= 30 %, puis pertinence sectorielle si active,
  // puis critère choisi par l'utilisateur.
  if (filters.sectors.length > 0) {
    const optimizeTax = shouldOptimizeForTax(filters.tmi);
    filteredData = filteredData
      .map(scpi => ({
        scpi,
        sectorScore: calculateSectorRelevanceScore(scpi, filters.sectors, filters.sectorThreshold),
        taxScore: optimizeTax ? getTaxOptimizationScore(scpi, filters.tmi) : 0
      }))
      .sort((a, b) => {
        if (a.taxScore !== b.taxScore) return b.taxScore - a.taxScore;
        if (a.sectorScore !== b.sectorScore) return b.sectorScore - a.sectorScore;
        if (sortBy === 'yield') return b.scpi.yield - a.scpi.yield;
        return a.scpi.price - b.scpi.price;
      })
      .map(item => item.scpi);
  } else {
    filteredData = sortSCPIByTaxOptimization(filteredData, filters.tmi, sortBy);
  }

  const itemsPerPage = viewMode === 'grid' ? 9 : 15;
  const totalPages = Math.ceil(filteredData.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const paginatedData = filteredData.slice(startIndex, endIndex);

  useEffect(() => {
    setCurrentPage(1);
  }, [searchQuery, sortBy, viewMode, filters]);

  const paginatedSlugsKey = useMemo(
    () => paginatedData.map(s => s.id).join(','),
    [currentPage, filteredData, itemsPerPage]
  );
  useEffect(() => {
    const slugs = paginatedData.map(s => createSlugFromName(s.name)).filter(Boolean);
    if (slugs.length === 0) return;
    getLatestScoresBatch(slugs).then(newScores => {
      if (Object.keys(newScores).length > 0) {
        setScoresBySlug(prev => ({ ...prev, ...newScores }));
      }
    });
  }, [paginatedSlugsKey]);


  const handleAnalyze = (scpi: SCPIExtended) => {
    // Sauvegarder la position de scroll avant d'ouvrir le modal
    const currentScrollY = window.scrollY || window.pageYOffset || document.documentElement.scrollTop;
    setSavedScrollPosition(currentScrollY);
    setAnalysisScpi(scpi);
  };

  const activeFiltersCount =
    (filters.tmi !== null ? 1 : 0) +
    (filters.minYield > 0 ? 1 : 0) +
    (filters.priceRange !== 'all' ? 1 : 0) +
    filters.geographies.length +
    (filters.sectors.length > 0 ? 1 : 0) + // Compter le filtre sectoriel comme 1 même si plusieurs secteurs
    (filters.sectorThreshold !== '25' ? 1 : 0) + // Compter si le seuil n'est pas le défaut
    (filters.hasISR !== null && filters.hasISR !== undefined ? 1 : 0) +
    (filters.noEntryFees ? 1 : 0) +
    (filters.expertMode ? (
      (filters.discountRange[0] !== -15 || filters.discountRange[1] !== 10 ? 1 : 0) +
      (filters.minRanDays > 0 ? 1 : 0) +
      (filters.maxLtv < 100 ? 1 : 0) +
      (filters.noWaitingShares ? 1 : 0)
    ) : 0);

  const sortCriterionLabel = sortBy === 'yield'
    ? 'taux de distribution décroissant'
    : 'prix croissant';
  const sortDescription = filters.sectors.length > 0
    ? (shouldOptimizeForTax(filters.tmi)
        ? `Priorité fiscale Europe, puis pertinence sectorielle, puis ${sortCriterionLabel}`
        : `Pertinence sectorielle, puis ${sortCriterionLabel}`)
    : (shouldOptimizeForTax(filters.tmi)
        ? `Priorité fiscale Europe, puis ${sortCriterionLabel}`
        : `Tri : ${sortCriterionLabel}`);

  return (
    <div className="min-h-screen bg-slate-900" id="comparator-container">
      <section className="max-w-[1560px] mx-auto px-4 sm:px-6 lg:px-8 pt-6">
        <div className="mt-6 rounded-xl bg-slate-800/80 border border-slate-700 p-4 space-y-4">
          <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
            <div>
              <p className="text-sm text-slate-400">
                {filteredData.length} SCPI disponibles • Page {currentPage} sur {totalPages}
              </p>
              <p className="mt-1 text-[11px] text-slate-500">
                {sortDescription} — ce tri ne constitue pas un classement de qualité.
              </p>
            </div>
            <div className="flex items-center gap-2">
              {filters.tmi !== null && (
                <div className="flex items-center gap-2 px-3 py-2 bg-emerald-600/20 border border-emerald-500/50 rounded-lg">
                  <Calculator className="w-4 h-4 text-emerald-400" />
                  <span className="text-sm font-medium text-emerald-200">TMI</span>
                  <span className="px-2 py-0.5 bg-emerald-500 text-white text-xs font-bold rounded-full">
                    {filters.tmi}%
                  </span>
                </div>
              )}
              <button
                onClick={() => setIsFilterOpen(true)}
                className="hidden md:flex relative px-4 py-2 bg-slate-700 hover:bg-slate-600 border border-slate-600 text-white rounded-lg text-sm font-medium transition-all items-center gap-2"
              >
                <SlidersHorizontal className="w-4 h-4" />
                <span>Filtres</span>
                {activeFiltersCount > 0 && (
                  <span className="absolute -top-1 -right-1 w-5 h-5 bg-emerald-500 text-white text-xs font-bold rounded-full flex items-center justify-center">
                    {activeFiltersCount}
                  </span>
                )}
              </button>
              <div className="flex items-center gap-1 bg-slate-700 rounded-lg p-1">
                <button
                  onClick={() => setViewMode('grid')}
                  className={`px-3 py-2 rounded-md transition-all flex items-center gap-2 ${
                    viewMode === 'grid'
                      ? 'bg-emerald-600 text-white'
                      : 'text-slate-400 hover:text-white hover:bg-slate-600'
                  }`}
                >
                  <Grid3x3 className="w-4 h-4" />
                  <span className="text-sm font-medium">Grille</span>
                </button>
                <button
                  onClick={() => setViewMode('list')}
                  className={`px-3 py-2 rounded-md transition-all flex items-center gap-2 ${
                    viewMode === 'list'
                      ? 'bg-emerald-600 text-white'
                      : 'text-slate-400 hover:text-white hover:bg-slate-600'
                  }`}
                >
                  <List className="w-4 h-4" />
                  <span className="text-sm font-medium">Liste</span>
                </button>
              </div>
              <button
                onClick={() => setIsFilterOpen(true)}
                className="md:hidden relative w-12 h-12 bg-slate-700 hover:bg-slate-600 border border-slate-600 rounded-full flex items-center justify-center transition-all shrink-0"
              >
                <SlidersHorizontal className="w-5 h-5 text-white" />
                {activeFiltersCount > 0 && (
                  <span className="absolute -top-1 -right-1 w-5 h-5 bg-emerald-500 text-white text-xs font-bold rounded-full flex items-center justify-center">
                    {activeFiltersCount}
                  </span>
                )}
              </button>
            </div>
          </div>
          <div className="relative w-full">
            <Search className="absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-emerald-500" />
            <input
              type="text"
              placeholder="Rechercher par nom, catégorie, gestionnaire..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-14 pr-12 py-3 bg-slate-950 border border-slate-600 text-white placeholder-slate-400 rounded-full shadow-md focus:outline-none focus:border-emerald-500 focus:shadow-lg focus:shadow-emerald-500/20 transition-all"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-5 top-1/2 -translate-y-1/2 p-1 hover:bg-slate-700 rounded-full transition-colors"
              >
                <X className="w-4 h-4 text-slate-400 hover:text-white" />
              </button>
            )}
          </div>
        </div>

        <div className="mt-8 grid grid-cols-1 xl:grid-cols-[minmax(0,1fr)_320px] gap-6 items-start">
        {/* Main Content */}
        <main className="min-w-0 pb-24 lg:pb-6">
          <div>

            {filteredData.length === 0 ? (
              <div className="text-center py-16">
                <div className="w-20 h-20 rounded-full bg-slate-800 mx-auto mb-4 flex items-center justify-center">
                  <Search className="w-10 h-10 text-slate-600" />
                </div>
                <h3 className="text-xl font-bold text-white mb-2">Aucun résultat</h3>
                <p className="text-slate-400 mb-4">
                  Essayez de modifier votre recherche
                </p>
                <button
                  onClick={() => setSearchQuery('')}
                  className="px-6 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-medium transition-colors"
                >
                  Réinitialiser
                </button>
              </div>
            ) : (
              <>
                {viewMode === 'grid' ? (
                  <div id="scpi-grid" className="mt-6 grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6">
                    {paginatedData.map(scpi => (
                      <SCPICardDark
                        key={scpi.id}
                        scpi={scpi}
                        score={scoresBySlug[createSlugFromName(scpi.name)] ?? clientScoresBySlug[createSlugFromName(scpi.name)] ?? null}
                        isSelected={selectedScpis.some(s => s.id === scpi.id)}
                        onToggleSelect={() => toggleSelect(scpi)}
                        onAnalyze={() => handleAnalyze(scpi)}
                        userTmi={filters.tmi}
                      />
                    ))}
                  </div>
                ) : (
                  <div className="hidden md:block overflow-x-auto rounded-xl border border-slate-700 bg-slate-800/70">
                    <div className="min-w-[980px]">
                      <div className="grid grid-cols-[minmax(180px,1.4fr)_130px_120px_70px_80px_100px_72px_180px] items-center border-b border-slate-700 px-4 py-3 text-xs font-semibold uppercase tracking-wide text-slate-400">
                        <div>SCPI</div>
                        <div>Catégorie</div>
                        <div>Rendement</div>
                        <div>TOF</div>
                        <div>Prix</div>
                        <div>Invest. Min.</div>
                        <div>Note</div>
                        <div className="text-right">Actions</div>
                      </div>
                      {paginatedData.map(scpi => (
                        <SCPITableRow
                          key={scpi.id}
                          scpi={scpi}
                          score={scoresBySlug[createSlugFromName(scpi.name)] ?? clientScoresBySlug[createSlugFromName(scpi.name)] ?? null}
                          isSelected={selectedScpis.some(s => s.id === scpi.id)}
                          onToggleSelect={() => toggleSelect(scpi)}
                          onAnalyze={() => handleAnalyze(scpi)}
                          userTmi={filters.tmi}
                        />
                      ))}
                    </div>
                  </div>
                )}

                {viewMode === 'list' && (
                  <div className="md:hidden mt-16 grid grid-cols-1 gap-6">
                    {paginatedData.map(scpi => (
                      <SCPICardDark
                        key={scpi.id}
                        scpi={scpi}
                        score={scoresBySlug[createSlugFromName(scpi.name)] ?? clientScoresBySlug[createSlugFromName(scpi.name)] ?? null}
                        isSelected={selectedScpis.some(s => s.id === scpi.id)}
                        onToggleSelect={() => toggleSelect(scpi)}
                        onAnalyze={() => handleAnalyze(scpi)}
                        userTmi={filters.tmi}
                      />
                    ))}
                  </div>
                )}

                {totalPages > 1 && (
                  <div className="mt-8 flex items-center justify-center gap-4">
                    <button
                      onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                      disabled={currentPage === 1}
                      className={`px-4 py-2 rounded-lg font-semibold text-sm transition-all flex items-center gap-2 ${
                        currentPage === 1
                          ? 'bg-slate-800 text-slate-600 cursor-not-allowed'
                          : 'bg-slate-700 hover:bg-slate-600 text-white'
                      }`}
                    >
                      <ChevronLeft className="w-4 h-4" />
                      <span>Précédent</span>
                    </button>

                    <div className="flex items-center gap-2">
                      <span className="text-white font-semibold">
                        Page {currentPage} sur {totalPages}
                      </span>
                    </div>

                    <button
                      onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
                      disabled={currentPage === totalPages}
                      className={`px-4 py-2 rounded-lg font-semibold text-sm transition-all flex items-center gap-2 ${
                        currentPage === totalPages
                          ? 'bg-slate-800 text-slate-600 cursor-not-allowed'
                          : 'bg-slate-700 hover:bg-slate-600 text-white'
                      }`}
                    >
                      <span>Suivant</span>
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>
                )}

                {/* Disclaimer de conformité */}
                {filteredData.length > 0 && (
                  <div className="mt-12 max-w-4xl mx-auto">
                    <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-4">
                      <p className="text-xs text-slate-400 leading-relaxed">
                        <span className="font-semibold text-slate-300">Avertissement : </span>
                        Les investissements en SCPI présentent un risque de perte en capital, une liquidité non garantie et un horizon de placement long. Les performances passées ne préjugent pas des performances futures. Les simulations et projections affichées sont indicatives et ne constituent ni un engagement contractuel ni une promesse de rendement.
                      </p>
                    </div>
                  </div>
                )}
              </>
            )}
          </div>
        </main>

        {/* Desktop Sidebar */}
        <aside id="selection-sidebar" className="block xl:sticky xl:top-24 scroll-mt-20">
          {selectedScpis.length > 0 ? (
            <Suspense fallback={
              <div className="rounded-xl border border-slate-700 bg-slate-800/70 p-5 text-sm text-slate-400">
                Chargement de l’analyse de sélection…
              </div>
            }>
              <SelectionSidebar
                selectedScpis={selectedScpis}
                onRemove={(scpi) => toggleSelect(scpi)}
                onClear={() => setSelectedScpis([])}
                onVisualize={() => setIsSimulationOpen(true)}
                zScoreVariant={zScoreVariant}
              />
            </Suspense>
          ) : (
            <div className="rounded-xl border border-slate-700 bg-slate-800/70 p-5 text-sm text-slate-400">
              Sélectionnez une ou plusieurs SCPI pour afficher l’analyse du portefeuille.
            </div>
          )}
        </aside>
      </div>
      </section>

      {/* Avertissement de comparaison si mélange France/Europe */}
      {selectedScpis.length >= 2 && (
        <div id="selection-section" className="scroll-mt-20">
          <ComparisonWarning scpiList={selectedScpis} className="mx-4 mb-4" />
        </div>
      )}

      {/* Mobile Selection Bar */}
      <MobileSelectionBar
        count={selectedScpis.length}
        onOpen={() => setIsSimulationOpen(true)}
      />

      {/* Simulation Modal — chargé uniquement à l'ouverture */}
      {isSimulationOpen && (
        <Suspense fallback={null}>
          <SimulationModal
            isOpen={isSimulationOpen}
            onClose={() => setIsSimulationOpen(false)}
            selectedScpis={selectedScpis}
          />
        </Suspense>
      )}

      {/* Analysis Detail Modal */}
      {analysisScpi && (
        <Suspense fallback={null}>
        <AnalysisDetailModal
          key={analysisScpi.id}
          isOpen={!!analysisScpi}
          onClose={() => {
            // Fermer le modal
            setAnalysisScpi(null);
            // Restaurer la position de scroll exacte après fermeture du modal
            setTimeout(() => {
              window.scrollTo({
                top: savedScrollPosition,
                behavior: 'instant' // Utiliser 'instant' pour éviter tout effet de scroll visible
              });
            }, 50);
          }}
          scpi={analysisScpi}
          score={scoresBySlug[createSlugFromName(analysisScpi.name)] ?? clientScoresBySlug[createSlugFromName(analysisScpi.name)] ?? null}
          scoreDetail={clientScoresById[String(analysisScpi.id)]?.detail ?? null}
          onAdd={() => {
            // Ajouter la SCPI à la sélection
            toggleSelect(analysisScpi);
            // Le modal se fermera automatiquement via onClose dans AnalysisDetailModal
            // et restaurera la position de scroll exacte
          }}
          isSelected={selectedScpis.some(s => s.id === analysisScpi.id)}
          onShowToast={(message) => {
            setToastMessage(message);
            setShowToast(true);
          }}
        />
        </Suspense>
      )}

      {/* Toast de confirmation */}
      <Toast
        message={toastMessage}
        isVisible={showToast}
        onClose={() => setShowToast(false)}
        duration={1000}
      />

      {/* Filter Panel — chargé uniquement à l'ouverture */}
      {isFilterOpen && (
        <Suspense fallback={null}>
          <FilterPanel
            isOpen={isFilterOpen}
            onClose={() => setIsFilterOpen(false)}
            filters={filters}
            onFiltersChange={setFilters}
            resultCount={filteredData.length}
          />
        </Suspense>
      )}
    </div>
  );
};

interface FintechComparatorProps {
  onCloseAnalysis?: () => void;
  onGuidedJourneyClick?: () => void;
  hideTitle?: boolean;
  zScoreVariant?: 'full' | 'compact';
}

const FintechComparator: React.FC<FintechComparatorProps> = ({
  onCloseAnalysis,
  onGuidedJourneyClick,
  hideTitle = false,
  zScoreVariant = 'full'
}) => {
  return (
    <AllocationProvider>
      <SubscriptionProvider>
        <FintechComparatorContent
          onCloseAnalysis={onCloseAnalysis}
          onGuidedJourneyClick={onGuidedJourneyClick}
          hideTitle={hideTitle}
          zScoreVariant={zScoreVariant}
        />
      </SubscriptionProvider>
    </AllocationProvider>
  );
};

export default FintechComparator;
