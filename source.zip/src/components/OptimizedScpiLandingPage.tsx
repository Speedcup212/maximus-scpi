import React, { useState, useEffect } from 'react';
import {
  TrendingUp, Shield, Phone, Mail, User, Euro,
  ArrowRight, Award, Building2, Globe, BarChart3, Leaf,
  Target, Calculator, MessageCircle, Clock, FileText, Lock,
  ChevronRight, ChevronLeft, Zap, CheckCircle
} from 'lucide-react';
import { ScpiLandingData } from '../data/landingPagesData';
import { buildScpiLandingData } from '../utils/buildScpiLandingData';
import { qualifyYield } from '../utils/yieldContext';
import { createSlugFromName } from '../utils/scpiSlugMapper';
import SEOHead from './SEOHead';
import MaximusLogoFooter from './MaximusLogoFooter';
import EricAvatar from './EricAvatar';
import PieChart from './PieChart';
import ThematicSimulator from './ThematicSimulator';
import Logo from './Logo';
import Header from './Header';
import { scpiData } from '../data/scpiData';
import { CookieConsent } from './CookieConsent';
import LeadMagnetEmailForm from './LeadMagnetEmailForm';
import ScpiPremiumAnalysis from './ScpiPremiumAnalysis';
import ScpiIndicatorHistory from './ScpiIndicatorHistory';
import { submitLead } from '../utils/leadSubmitter';
import { getLiveScpiData } from '../utils/scpiLiveData';

interface OptimizedScpiLandingPageProps {
  scpiKey: string;
  onNavigateHome?: () => void;
  onNavigateToFaq?: () => void;
  onNavigateToAbout?: () => void;
  onNavigateToUnderstanding?: () => void;
  onNavigateToScpi?: (slug: string) => void;
  onContactClick?: () => void;
  onArticlesClick?: () => void;
  onComparateurClick?: () => void;
  onSimulateurClick?: (simulateurId: string) => void;
  isDarkMode?: boolean;
  toggleTheme?: () => void;
}

const OptimizedScpiLandingPage: React.FC<OptimizedScpiLandingPageProps> = ({
  scpiKey,
  onNavigateHome,
  onNavigateToFaq,
  onNavigateToAbout,
  onNavigateToUnderstanding,
  onNavigateToScpi,
  onContactClick,
  onArticlesClick,
  onComparateurClick,
  onSimulateurClick,
  isDarkMode = false,
  toggleTheme = () => {}
}) => {
  const built = buildScpiLandingData(scpiKey);

  if (!built) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-red-600">SCPI non trouvée</p>
      </div>
    );
  }

  const landingData: ScpiLandingData = built.data;
  const isEditorial = built.isEditorial;

  const landingSlug = createSlugFromName(landingData.nom);
  const staticScpiData = scpiData.find(
    scpi => createSlugFromName(scpi.name) === landingSlug
  );
  const [realScpiData, setRealScpiData] = useState(staticScpiData);

  useEffect(() => {
    let active = true;
    if (!staticScpiData) return () => { active = false; };

    void getLiveScpiData(staticScpiData).then((live) => {
      if (active) setRealScpiData(live);
    });

    return () => {
      active = false;
    };
  }, [landingSlug, staticScpiData]);

  const [formData, setFormData] = useState({
    nom: '',
    prenom: '',
    email: '',
    telephone: '',
    commentaire: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<'idle' | 'success' | 'error'>('idle');

  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const utmSource = urlParams.get('utm_source');
    const utmMedium = urlParams.get('utm_medium');
    const utmCampaign = urlParams.get('utm_campaign');
    const gclid = urlParams.get('gclid');

    if (utmSource || utmMedium || utmCampaign || gclid) {
      console.log('📍 Paramètres Google Ads détectés et stockés:', { utmSource, utmMedium, utmCampaign, gclid });
      if (utmSource) sessionStorage.setItem('utm_source', utmSource);
      if (utmMedium) sessionStorage.setItem('utm_medium', utmMedium);
      if (utmCampaign) sessionStorage.setItem('utm_campaign', utmCampaign);
      if (gclid) sessionStorage.setItem('gclid', gclid);
    }
  }, []);

  const getColorScheme = (_key: string) => ({
    primary: 'from-[#0D1117] via-[#12372F] to-[#0D1117]',
    secondary: 'emerald',
    accent: 'teal',
  });

  const colors = getColorScheme(scpiKey);
  const useMaximusBrand = true;
  const isEmailLeadMagnet = scpiKey === 'iroko-zen' || scpiKey === 'novaxia-neo' || scpiKey === 'remake-live';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setSubmitStatus('idle');

    try {
      const result = await submitLead({
        channel: 'scpi_page',
        form_type: 'lead_contact',
        context_type: 'scpi',
        context_slug: scpiKey,
        identity: {
          nom: formData.nom || '',
          prenom: formData.prenom || '',
          email: formData.email,
          telephone: formData.telephone || '',
        },
        message: formData.commentaire || '',
        answers: { scpi: landingData.nom },
      });

      if (!result.ok) {
        throw new Error(`SUPABASE_ERROR: ${result.error}`);
      }

      setSubmitStatus('success');

      const senderGroupId = 'LM_SCPI_SansFrais';
      try {
        console.log('📧 Ajout du contact à Sender, groupe:', senderGroupId);
        const senderResponse = await fetch(
          `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/sender-add-contact`,
          {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              email: formData.email,
              group_id: senderGroupId,
              firstname: formData.prenom,
              lastname: formData.nom,
              fields: {
                scpi: landingData.nom,
                telephone: formData.telephone || ''
              }
            }),
          }
        );

        if (senderResponse.ok) {
          console.log('✅ Contact ajouté à Sender avec succès');
        } else {
          console.warn('⚠️ Erreur Sender (non bloquante):', await senderResponse.text());
        }
      } catch (senderError) {
        console.warn('⚠️ Erreur Sender (non bloquante):', senderError);
      }

      if (window.gtag) {
        console.log('📊 Envoi des événements de conversion Google Ads');
        window.gtag('event', 'conversion', {
          'send_to': `AW-CONVERSION_ID/${scpiKey.toUpperCase().replace(/-/g, '_')}`,
          'value': 1.0,
          'currency': 'EUR',
          'transaction_id': ''
        });

        window.gtag('event', 'generate_lead', {
          'event_category': `SCPI ${landingData.nom}`,
          'event_label': 'Formulaire Landing Page Simplifié',
          'value': 0
        });
      }

      console.log('✅ Redirection vers la page de remerciement');
      window.location.href = '/merci-landing-page.html';

      setFormData({
        nom: '',
        prenom: '',
        email: '',
        telephone: '',
        commentaire: ''
      });

    } catch (error: any) {
      console.error('❌ ERREUR CRITIQUE lors de la soumission:', error);

      if (error.message === 'CONFIGURATION_MANQUANTE') {
        console.error('🔧 Action requise: Vérifier les variables VITE_SUPABASE_URL et VITE_SUPABASE_ANON_KEY');
      } else if (error.message === 'IMPORT_SUPABASE_FAILED') {
        console.error('🔧 Action requise: Vérifier que supabaseClient.ts est accessible');
      } else if (error.message?.includes('SUPABASE_ERROR')) {
        console.error('🔧 Action requise: Vérifier la connexion à Supabase et les permissions de la table');
      } else if (error.message === 'INSERTION_FAILED') {
        console.error('🔧 Action requise: Vérifier la structure de la table et les règles RLS');
      }

      console.error('📋 Informations de diagnostic:', {
        url: window.location.href,
        userAgent: navigator.userAgent,
        timestamp: new Date().toISOString(),
        formData: { email: formData.email, hasPhone: !!formData.telephone },
        error: error.message || error
      });

      setSubmitStatus('error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleBackToHome = () => {
    if (onNavigateHome) {
      onNavigateHome();
    } else {
      window.location.href = '/';
    }
  };

  const handleContactClick = () => {
    if (onContactClick) {
      onContactClick();
    } else {
      window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' });
    }
  };

  const scrollToLeadForm = () => {
    document.getElementById('analyse-personnalisee')?.scrollIntoView({
      behavior: 'smooth',
      block: 'start'
    });
  };

  const heroYieldValue = realScpiData ? realScpiData.yield : parseFloat(String(landingData.rendement).replace(',', '.'));
  const yieldQualif = qualifyYield(heroYieldValue);

  const getBadgeText = () => {
    if (landingData.frais_souscription === "0%") {
      return "0% de frais d'entrée - Votre capital investi à 100%";
    }
    return `${landingData.rendement} de rendement - ${yieldQualif.label}`;
  };

  const formatCurrency = (amount: number): string => {
    if (amount >= 1000000000) {
      return (amount / 1000000000).toFixed(1) + ' Md€';
    } else if (amount >= 1000000) {
      return Math.round(amount / 1000000) + ' M€';
    }
    return Math.round(amount) + ' €';
  };

  const formatPercentage = (value: number): string => {
    return value.toFixed(2) + '%';
  };

  const canonicalUrl = `https://maximusscpi.com/${landingData.slug}/`;

  return (
    <div className={`min-h-screen bg-gradient-to-br from-${colors.secondary}-50 via-white to-${colors.accent}-50`}>
      <SEOHead
        title={`SCPI ${landingData.nom} : analyse, rendement et avis | MaximusSCPI`}
        description={landingData.description_courte || `Analyse complète de la SCPI ${landingData.nom} : rendement, capitalisation, frais, répartition et points de vigilance.`}
        canonical={canonicalUrl}
      />
      <Header
        isDarkMode={isDarkMode}
        toggleTheme={toggleTheme}
        onContactClick={onContactClick || (() => {})}
        onAboutClick={onNavigateToAbout || (() => {})}
        onLogoClick={onNavigateHome}
        onFaqClick={onNavigateToFaq}
        onScpiPageClick={onNavigateToScpi}
        onUnderstandingClick={onNavigateToUnderstanding}
        onAboutSectionClick={onNavigateToAbout}
        onComparateurClick={onComparateurClick}
        onSimulateurClick={onSimulateurClick}
        onArticlesClick={onArticlesClick}
        currentView="scpi-landing"
      />

      <div className={`bg-gradient-to-br ${colors.primary} text-white`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-12">
          <div className="grid lg:grid-cols-[minmax(0,1.35fr)_minmax(320px,0.65fr)] gap-8 lg:gap-10 items-start">
            <div className="space-y-8">
              <div className={`inline-flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-bold shadow-lg ${useMaximusBrand ? 'bg-[#00C896] text-[#0D1117] shadow-emerald-950/30' : 'bg-yellow-400 text-gray-900'}`}>
                <Zap className="w-5 h-5" />
                {getBadgeText()}
              </div>

              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold leading-tight">
                {landingData.h1_question || `SCPI ${landingData.nom}`}
                <span className={`block text-3xl sm:text-4xl lg:text-5xl text-${colors.secondary}-100 mt-3`}>
                  {realScpiData ? formatPercentage(realScpiData.yield) : landingData.rendement} de rendement
                </span>
                <span className="block text-2xl sm:text-3xl lg:text-4xl text-yellow-400 mt-3">
                  {landingData.frais_souscription === "0%" ? "Sans frais d'entrée" : yieldQualif.label}
                </span>
              </h1>

              <p className={`text-xl sm:text-2xl text-${colors.secondary}-50 leading-relaxed`}>
                {landingData.description_courte}
              </p>

              {realScpiData ? (
                <div className="rounded-2xl border border-white/20 bg-white/10 backdrop-blur-md p-4 sm:p-5">
                  <div className="flex items-end justify-between gap-3 mb-4">
                    <div>
                      <div className="text-sm sm:text-base font-semibold uppercase tracking-wide text-white/70">
                        Les chiffres essentiels
                      </div>
                      <div className="text-base sm:text-lg text-white/90 mt-1">
                        Une lecture simple avant d'aller dans le détail
                      </div>
                    </div>
                    <div className="hidden sm:block text-xs text-white/60">
                      Source : {realScpiData.periodeBulletinTrimestriel || 'dernières données disponibles'}
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-3">
                    {[
                      {
                        label: 'Rendement',
                        value: formatPercentage(realScpiData.yield),
                        help: 'Distribué sur l’année'
                      },
                      {
                        label: 'Capitalisation',
                        value: formatCurrency(realScpiData.capitalization),
                        help: 'Taille de la SCPI'
                      },
                      {
                        label: 'Prix de la part',
                        value: formatCurrency(realScpiData.price),
                        help: 'Prix de souscription'
                      },
                      {
                        label: realScpiData.discount <= 0 ? 'Décote' : 'Surcote',
                        value: realScpiData.discountQaStatus === 'publishable'
                          ? `${Math.abs(realScpiData.discount).toFixed(2).replace('.', ',')} %`
                          : 'À vérifier',
                        help: realScpiData.valeurReconstitution
                          ? `${formatCurrency(realScpiData.price)} vs ${formatCurrency(realScpiData.valeurReconstitution)}`
                          : 'Vs valeur du patrimoine'
                      },
                      {
                        label: 'TOF',
                        value: formatPercentage(realScpiData.tof),
                        help: 'Occupation financière'
                      },
                      {
                        label: 'Endettement',
                        value: realScpiData.debt !== undefined ? formatPercentage(realScpiData.debt) : 'ND',
                        help: 'Niveau de dette'
                      },
                      {
                        label: 'WALB / WALT',
                        value:
                          realScpiData.walb !== undefined && realScpiData.walt !== undefined
                            ? `${realScpiData.walb.toFixed(1).replace('.', ',')} / ${realScpiData.walt.toFixed(1).replace('.', ',')} ans`
                            : 'ND',
                        help: 'Sorties possibles / baux restants'
                      },
                      scpiKey === 'comete'
                        ? {
                            label: 'Revalorisation',
                            value: '+5,3 %',
                            help: '237,50 € → 250 €'
                          }
                        : {
                            label: "Frais d'entrée",
                            value: realScpiData.fees !== undefined ? formatPercentage(realScpiData.fees) : 'ND',
                            help: realScpiData.fees === 0 ? 'Sans frais de souscription' : 'Frais de souscription TTC'
                          },
                      {
                        label: 'Délai de jouissance',
                        value: realScpiData.delaiJouissance !== undefined
                          ? realScpiData.delaiJouissance === 0
                            ? 'Immédiat'
                            : `${realScpiData.delaiJouissance} mois`
                          : 'ND',
                        help: 'Avant perception des premiers revenus'
                      }
                    ].map((metric) => (
                      <div
                        key={metric.label}
                        className="rounded-xl border border-white/15 bg-slate-950/20 p-4 min-h-[132px] flex flex-col justify-between"
                      >
                        <div className="text-xs sm:text-sm font-semibold uppercase tracking-wide text-white/65">
                          {metric.label}
                        </div>

                        <div
                          className={`mt-2 font-extrabold text-yellow-300 leading-none tabular-nums ${(
                            metric.label === 'Délai de jouissance' || metric.label === 'WALB / WALT'
                          ) ? 'text-xl sm:text-2xl' : 'text-3xl sm:text-[32px]'}`}
                        >
                          {metric.value}
                        </div>

                        <div className="mt-2 text-xs sm:text-[13px] leading-snug text-white/65">
                          {metric.help}
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="mt-3 text-[11px] leading-relaxed text-white/55 sm:hidden">
                    Source : {realScpiData.periodeBulletinTrimestriel || 'dernières données disponibles'}
                  </div>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {realScpiData && (
                    <>
                      <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-xl p-6 text-center">
                        <div className="text-3xl sm:text-4xl font-bold text-yellow-400">{formatPercentage(realScpiData.yield)}</div>
                        <div className={`text-sm text-${colors.secondary}-100 mt-2`}>Taux de distribution</div>
                      </div>
                      <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-xl p-6 text-center">
                        <div className="text-3xl sm:text-4xl font-bold text-yellow-400">{formatCurrency(realScpiData.capitalization)}</div>
                        <div className={`text-sm text-${colors.secondary}-100 mt-2`}>Capitalisation</div>
                      </div>
                      <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-xl p-6 text-center">
                        <div className="text-3xl sm:text-4xl font-bold text-yellow-400">{formatCurrency(realScpiData.price)}</div>
                        <div className={`text-sm text-${colors.secondary}-100 mt-2`}>Prix de la part</div>
                      </div>
                    </>
                  )}
                </div>
              )}

              <div className="space-y-4">
                {landingData.avantages.map((avantage, index) => (
                  <div key={index} className="flex items-start gap-3">
                    <CheckCircle className="w-6 h-6 text-yellow-400 flex-shrink-0 mt-1" />
                    <span className={`text-${colors.secondary}-50 text-lg`}>{avantage}</span>
                  </div>
                ))}
              </div>
            </div>

            <aside className="lg:sticky lg:top-24">
              <div className="rounded-3xl border border-white/15 bg-white/[0.97] p-6 sm:p-7 text-slate-900 shadow-2xl shadow-black/20">
                <div className="flex items-center gap-3 mb-5">
                  <div className="rounded-full border-2 border-[#00C896] shadow-md">
                    <EricAvatar size={52} />
                  </div>
                  <div>
                    <p className="text-sm font-bold text-slate-900">Eric Bellaiche · MaximusSCPI</p>
                    <p className="text-xs font-semibold uppercase tracking-[0.14em] text-emerald-700">Analyse personnalisée</p>
                  </div>
                </div>

                <h2 className="text-2xl sm:text-[28px] font-extrabold leading-tight text-slate-950">
                  La SCPI {landingData.nom} est-elle adaptée à votre projet ?
                </h2>
                <p className="mt-3 text-sm sm:text-base leading-relaxed text-slate-600">
                  Vérification de sa cohérence avec votre allocation, votre horizon d'investissement et votre fiscalité.
                </p>

                <div className="mt-5 grid grid-cols-3 gap-2 text-center text-xs font-semibold text-slate-600">
                  <div className="rounded-xl bg-emerald-50 px-2 py-3">
                    <CheckCircle className="mx-auto mb-1.5 h-4 w-4 text-emerald-600" />
                    Gratuit
                  </div>
                  <div className="rounded-xl bg-slate-50 px-2 py-3">
                    <Shield className="mx-auto mb-1.5 h-4 w-4 text-slate-600" />
                    Sans engagement
                  </div>
                  <div className="rounded-xl bg-slate-50 px-2 py-3">
                    <Clock className="mx-auto mb-1.5 h-4 w-4 text-slate-600" />
                    Réponse 24 h
                  </div>
                </div>

                <button
                  type="button"
                  onClick={scrollToLeadForm}
                  className="mt-5 inline-flex w-full items-center justify-center gap-2 rounded-xl bg-[#00C896] px-5 py-3.5 font-bold text-[#0D1117] shadow-lg shadow-emerald-900/15 transition hover:bg-[#00B789]"
                >
                  Obtenir mon analyse personnalisée
                  <ArrowRight className="h-5 w-5" />
                </button>
                <p className="mt-3 text-center text-[11px] leading-relaxed text-slate-500">
                  Le formulaire complet est disponible plus bas, après l'analyse de la SCPI.
                </p>
              </div>
            </aside>
          </div>
        </div>
      </div>

      {useMaximusBrand && (
        <div
          aria-hidden="true"
          className="h-20 sm:h-24 bg-gradient-to-b from-[#0D1117] via-[#DFF3EC] to-[#F8FAFC]"
        />
      )}

      <ScpiIndicatorHistory
        scpiSlug={landingSlug}
        scpiName={landingData.nom}
      />

      <div className={useMaximusBrand ? 'bg-[#F8FAFC] pb-12 sm:pb-14' : 'bg-white py-10 sm:py-12'}>
        <div className={`max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 ${useMaximusBrand ? 'relative z-10 -mt-7 sm:-mt-9 pt-2' : ''}`}>
          <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-3 mb-7">
            <div>
              <p className="text-sm font-semibold uppercase tracking-wide text-slate-500">Patrimoine</p>
              <h2 className="mt-1 text-2xl sm:text-3xl font-bold text-gray-900">
                Où investit {landingData.nom} ?
              </h2>
            </div>
            <p className="text-sm text-gray-500 max-w-xl">
              Répartition géographique et sectorielle du patrimoine à partir des dernières données structurées disponibles.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-5">
            <div className={useMaximusBrand
              ? 'rounded-2xl border border-emerald-900/10 bg-white p-5 sm:p-6 shadow-[0_18px_45px_rgba(15,23,42,0.08)] ring-1 ring-white'
              : 'rounded-2xl border border-slate-200 bg-slate-50 p-5 sm:p-6'
            }>
              <div className="flex items-center gap-2 mb-4">
                <Globe className="w-5 h-5 text-slate-700" />
                <h3 className="text-lg font-bold text-gray-900">Géographie</h3>
              </div>
              {Object.keys(landingData.geographie).length === 0 ? (
                <div className="flex items-center justify-center h-[220px] text-gray-500 text-center px-4">
                  Répartition géographique non disponible.
                </div>
              ) : (
                <div className="grid sm:grid-cols-[220px_1fr] gap-4 items-center">
                  <div className="flex justify-center">
                    <PieChart
                      data={Object.entries(landingData.geographie).map(([pays, pct], index) => ({
                        name: pays,
                        value: pct,
                        color: [
                          '#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6',
                          '#06b6d4', '#84cc16', '#f97316', '#ec4899', '#6366f1'
                        ][index % 10]
                      }))}
                      width={220}
                      height={220}
                      showLabels={true}
                    />
                  </div>
                  <div className="space-y-1.5 text-sm">
                    {Object.entries(landingData.geographie).map(([pays, pct], index) => (
                      <div key={pays} className="flex items-center gap-2">
                        <div
                          className="w-2.5 h-2.5 rounded-full"
                          style={{ backgroundColor: [
                            '#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6',
                            '#06b6d4', '#84cc16', '#f97316', '#ec4899', '#6366f1'
                          ][index % 10] }}
                        />
                        <span className="text-gray-700 truncate">{pays}</span>
                        <span className="ml-auto font-semibold text-gray-900">{pct}%</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <div className={useMaximusBrand
              ? 'rounded-2xl border border-emerald-900/10 bg-white p-5 sm:p-6 shadow-[0_18px_45px_rgba(15,23,42,0.08)] ring-1 ring-white'
              : 'rounded-2xl border border-slate-200 bg-slate-50 p-5 sm:p-6'
            }>
              <div className="flex items-center gap-2 mb-4">
                <Building2 className="w-5 h-5 text-slate-700" />
                <h3 className="text-lg font-bold text-gray-900">Secteurs</h3>
              </div>
              {Object.keys(landingData.secteurs).length === 0 ? (
                <div className="flex items-center justify-center h-[220px] text-gray-500 text-center px-4">
                  Répartition sectorielle non disponible.
                </div>
              ) : (
                <div className="grid sm:grid-cols-[220px_1fr] gap-4 items-center">
                  <div className="flex justify-center">
                    <PieChart
                      data={Object.entries(landingData.secteurs).map(([secteur, pct], index) => ({
                        name: secteur,
                        value: pct,
                        color: [
                          '#1e40af', '#059669', '#d97706', '#dc2626', '#7c3aed',
                          '#0891b2', '#65a30d', '#ea580c', '#be185d', '#4f46e5'
                        ][index % 10]
                      }))}
                      width={220}
                      height={220}
                      showLabels={true}
                    />
                  </div>
                  <div className="space-y-1.5 text-sm">
                    {Object.entries(landingData.secteurs).map(([secteur, pct], index) => (
                      <div key={secteur} className="flex items-center gap-2">
                        <div
                          className="w-2.5 h-2.5 rounded-full"
                          style={{ backgroundColor: [
                            '#1e40af', '#059669', '#d97706', '#dc2626', '#7c3aed',
                            '#0891b2', '#65a30d', '#ea580c', '#be185d', '#4f46e5'
                          ][index % 10] }}
                        />
                        <span className="text-gray-700 truncate">{secteur}</span>
                        <span className="ml-auto font-semibold text-gray-900">{pct}%</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {useMaximusBrand && (
        <div
          aria-hidden="true"
          className="h-16 sm:h-20 bg-gradient-to-b from-[#F8FAFC] via-[#E2F1EC] to-slate-950"
        />
      )}

      {realScpiData && (
        <ScpiPremiumAnalysis
          scpi={realScpiData}
          landingData={landingData}
        />
      )}

      {landingData.simulator && (
        <div className="bg-slate-50 py-8">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <details className="group rounded-2xl border border-slate-200 bg-white shadow-sm">
              <summary className="cursor-pointer list-none p-5 sm:p-6 flex items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-blue-50 flex items-center justify-center">
                    <Calculator className="w-5 h-5 text-blue-600" />
                  </div>
                  <div>
                    <div className="font-bold text-gray-900">Simuler mes revenus avec {landingData.nom}</div>
                    <div className="text-sm text-gray-500">Ouvrir le simulateur uniquement si vous en avez besoin</div>
                  </div>
                </div>
                <ChevronRight className="w-5 h-5 text-gray-400 transition-transform group-open:rotate-90" />
              </summary>
              <div className="border-t border-slate-200 p-4 sm:p-6">
                <ThematicSimulator
                  defaultInvestment={landingData.simulator.defaultInvestment}
                  defaultYield={landingData.simulator.defaultYield}
                  title={landingData.simulator.title}
                  subtitle={landingData.simulator.subtitle}
                  theme={landingData.simulator.theme}
                />
              </div>
            </details>
          </div>
        </div>
      )}

      <section id="analyse-personnalisee" className="scroll-mt-24 bg-white py-12 sm:py-16">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid gap-8 lg:grid-cols-[0.85fr_1.15fr] lg:items-start">
            <div className="lg:sticky lg:top-24">
              <p className="text-sm font-bold uppercase tracking-[0.16em] text-emerald-700">Analyse personnalisée</p>
              <h2 className="mt-2 text-3xl sm:text-4xl font-extrabold leading-tight text-slate-950">
                Faut-il investir dans {landingData.nom} ?
              </h2>
              <p className="mt-4 text-base sm:text-lg leading-relaxed text-slate-600">
                La fiche vous donne les données. Ici, l'objectif est de vérifier si cette SCPI est cohérente avec votre situation, votre horizon et le reste de votre patrimoine.
              </p>

              <div className="mt-6 space-y-3 text-sm text-slate-700">
                <div className="flex items-start gap-3">
                  <CheckCircle className="mt-0.5 h-5 w-5 shrink-0 text-emerald-600" />
                  <span>Lecture de la SCPI dans votre allocation globale.</span>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle className="mt-0.5 h-5 w-5 shrink-0 text-emerald-600" />
                  <span>Prise en compte de l'horizon, de la liquidité et de la fiscalité.</span>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle className="mt-0.5 h-5 w-5 shrink-0 text-emerald-600" />
                  <span>Réponse sous 24 h, gratuite et sans engagement.</span>
                </div>
              </div>
            </div>

            <div className="rounded-3xl border border-slate-200 bg-slate-50 p-5 sm:p-7 shadow-[0_18px_50px_rgba(15,23,42,0.08)]">
              {isEmailLeadMagnet ? (
                <LeadMagnetEmailForm />
              ) : (
                <>
                  <div className="mb-6 flex items-center gap-3">
                    <div className="rounded-full border-2 border-[#00C896] shadow-md">
                      <EricAvatar size={52} />
                    </div>
                    <div>
                      <p className="font-bold text-slate-900">Eric Bellaiche · MaximusSCPI</p>
                      <p className="text-sm text-slate-500">Demande d'analyse personnalisée</p>
                    </div>
                  </div>

                  {submitStatus === 'success' ? (
                    <div className="rounded-xl border-2 border-emerald-500 bg-emerald-50 p-6 text-center">
                      <CheckCircle className="mx-auto mb-4 h-14 w-14 text-emerald-600" />
                      <h3 className="text-xl font-bold text-gray-900 mb-2">Demande envoyée avec succès !</h3>
                      <p className="text-gray-700">Eric vous contacte sous 24 h pour échanger sur votre projet.</p>
                    </div>
                  ) : (
                    <form onSubmit={handleSubmit} className="space-y-4">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div>
                          <label className="block text-sm font-semibold text-gray-800 mb-2">Prénom *</label>
                          <input
                            type="text"
                            name="prenom"
                            required
                            value={formData.prenom}
                            onChange={handleChange}
                            className="w-full rounded-xl border-2 border-gray-300 bg-white px-4 py-3 text-gray-900 focus:border-transparent focus:ring-2 focus:ring-emerald-500"
                            placeholder="Jean"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-semibold text-gray-800 mb-2">Nom *</label>
                          <input
                            type="text"
                            name="nom"
                            required
                            value={formData.nom}
                            onChange={handleChange}
                            className="w-full rounded-xl border-2 border-gray-300 bg-white px-4 py-3 text-gray-900 focus:border-transparent focus:ring-2 focus:ring-emerald-500"
                            placeholder="Dupont"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block text-sm font-semibold text-gray-800 mb-2">Adresse e-mail *</label>
                        <input
                          type="email"
                          name="email"
                          required
                          value={formData.email}
                          onChange={handleChange}
                          className="w-full rounded-xl border-2 border-gray-300 bg-white px-4 py-3 text-gray-900 focus:border-transparent focus:ring-2 focus:ring-emerald-500"
                          placeholder="vous@exemple.com"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-semibold text-gray-800 mb-2">Téléphone *</label>
                        <input
                          type="tel"
                          name="telephone"
                          required
                          value={formData.telephone}
                          onChange={handleChange}
                          className="w-full rounded-xl border-2 border-gray-300 bg-white px-4 py-3 text-gray-900 focus:border-transparent focus:ring-2 focus:ring-emerald-500"
                          placeholder="06 12 34 56 78"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-semibold text-gray-800 mb-2">Votre message (facultatif)</label>
                        <textarea
                          name="commentaire"
                          value={formData.commentaire}
                          onChange={handleChange}
                          rows={3}
                          className="w-full resize-none rounded-xl border-2 border-gray-300 bg-white px-4 py-3 text-gray-900 focus:border-transparent focus:ring-2 focus:ring-emerald-500"
                          placeholder="Vos questions ou précisions..."
                        />
                      </div>

                      {submitStatus === 'error' && (
                        <div className="rounded-xl border-2 border-red-200 bg-red-50 p-4 text-center">
                          <p className="text-sm text-red-700">Une erreur est survenue. Veuillez réessayer.</p>
                        </div>
                      )}

                      <button
                        type="submit"
                        disabled={isSubmitting}
                        className="flex w-full items-center justify-center gap-2 rounded-xl bg-[#00C896] px-6 py-4 font-bold text-[#0D1117] shadow-lg shadow-emerald-900/15 transition hover:bg-[#00B789] disabled:cursor-not-allowed disabled:opacity-50"
                      >
                        {isSubmitting ? (
                          <>
                            <div className="h-5 w-5 animate-spin rounded-full border-b-2 border-[#0D1117]" />
                            <span>Envoi en cours...</span>
                          </>
                        ) : (
                          <>
                            <Mail className="h-5 w-5" />
                            <span>Obtenir mon analyse personnalisée</span>
                          </>
                        )}
                      </button>

                      <div className="flex flex-wrap items-center justify-center gap-x-6 gap-y-2 pt-2 text-xs text-gray-600">
                        <div className="flex items-center gap-1"><CheckCircle className="h-4 w-4 text-emerald-600" /><span>Gratuit</span></div>
                        <div className="flex items-center gap-1"><Shield className="h-4 w-4 text-slate-600" /><span>Sans engagement</span></div>
                        <div className="flex items-center gap-1"><Clock className="h-4 w-4 text-slate-600" /><span>Réponse 24 h</span></div>
                      </div>
                    </form>
                  )}
                </>
              )}
            </div>
          </div>
        </div>
      </section>

      <div className="bg-gradient-to-r from-gray-800 to-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-start gap-4">
            <Shield className="w-8 h-8 text-yellow-400 flex-shrink-0 mt-1" />
            <div>
              <h3 className="text-xl font-bold mb-4">Informations importantes</h3>
              <div className="space-y-3 text-gray-300 text-sm">
                <p>
                  <strong>Risques :</strong> L'investissement en SCPI présente des risques de perte en capital et de liquidité. Les performances passées ne préjugent pas des performances futures.
                </p>
                <p>
                  <strong>Durée recommandée :</strong> 8 à 10 ans minimum. Les SCPI sont des placements de long terme.
                </p>
                <p>
                  <strong>Frais :</strong> Frais de souscription : {landingData.frais_souscription} TTC. Consultez la note d'information complète avant tout investissement.
                </p>
                <p>
                  <strong>Conseiller :</strong> Eric Bellaiche - CIF enregistré à l'ORIAS sous le numéro 13001580.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-center mb-8">
            <MaximusLogoFooter className="h-12 w-auto" />
          </div>

          <div className="text-center space-y-4">
            <div className="flex flex-wrap justify-center gap-6 text-xs text-gray-400">
              <a href="/mentions-legales" className={`hover:text-${colors.secondary}-400 transition-colors`}>
                Mentions légales
              </a>
              <a href="/politique-confidentialite" className={`hover:text-${colors.secondary}-400 transition-colors`}>
                Politique de confidentialité
              </a>
              <a href="/conditions-utilisation" className={`hover:text-${colors.secondary}-400 transition-colors`}>
                Conditions d'utilisation
              </a>
            </div>
            <p className="text-xs text-gray-500">
              © {new Date().getFullYear()} MaximusSCPI. Tous droits réservés.
            </p>
          </div>
        </div>
      </footer>

      <CookieConsent />
    </div>
  );
};

export default OptimizedScpiLandingPage;