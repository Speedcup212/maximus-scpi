import type { ScpiEducationalPageConfig } from './shared'

export const combienInvestirScpiConfig: ScpiEducationalPageConfig = {
  path: '/combien-investir-scpi',
  badge: 'Montant & calibrage',
  h1: 'Combien investir en SCPI selon son patrimoine',
  heroSubtitle:
    'Il n\'existe pas de montant universel pour investir en SCPI. Le montant dépend de la situation patrimoniale, de la liquidité disponible, de l\'horizon, du besoin de revenus, de la fiscalité et de la capacité à accepter une perte en capital ou une revente longue. Cette page donne des repères pour calibrer son investissement.',
  seoTitle: 'Combien investir en SCPI : montant, patrimoine, fiscalité, horizon',
  seoDescription:
    'Calibrage de l\'investissement en SCPI : montant minimum, part du patrimoine, liquidité de précaution, horizon, fiscalité, diversification, exemple 100 000 €, crédit, enveloppes (direct, AV, PER).',
  shortAnswerTitle: 'Quel montant investir en SCPI ?',
  shortAnswer:
    'Le montant à investir en SCPI dépend de plusieurs facteurs : la part du patrimoine financier allouée à l\'immobilier (une règle de prudence suggère de ne pas dépasser 30-50 %), la liquidité de précaution à conserver (épargne disponible à court terme), l\'horizon d\'investissement (8-10 ans minimum recommandé), le besoin de revenus complémentaires, la fiscalité personnelle (TMI) et la capacité à diversifier. Il n\'existe pas de montant unique valable pour tous. Le montant minimum d\'entrée varie de 1 000 € à 5 000 € selon les SCPI, parfois plus.',
  keyMessage:
    'Le bon montant n\'est pas celui qui maximise le rendement affiché, mais celui qui reste cohérent avec la liquidité, la fiscalité, l\'horizon et les objectifs patrimoniaux.',
  definitionParagraphs: [
    'Le montant minimum d\'entrée en SCPI varie selon les sociétés de gestion : généralement entre 1 000 € et 5 000 €, parfois plus pour certaines SCPI de prestige. En assurance-vie, le seuil peut être plus bas (quelques centaines d\'euros).',
    'La part du patrimoine financier allouée aux SCPI dépend de la situation personnelle. Une règle de prudence consiste à ne pas immobiliser toute son épargne dans des actifs non liquides. Une fourchette de 30 à 50 % de l\'épargne financière est souvent citée, mais elle doit être adaptée à chaque situation.',
    'La liquidité de précaution doit être conservée : il est déconseillé d\'investir en SCPI des sommes dont on pourrait avoir besoin à court terme (moins de 5-8 ans). Une épargne de précaution équivalant à 3 à 6 mois de dépenses courantes est recommandée.',
    'L\'investissement à crédit peut amplifier la capacité d\'investissement, mais il augmente le risque : les intérêts courent avant les premiers revenus, le délai de jouissance peut impacter le cash-flow, et la dette doit être remboursée même si les revenus baissent.',
    'La fiscalité personnelle influence le montant à investir : pour les TMI élevées, l\'enveloppe (assurance-vie, PER) est plus importante que le montant brut. Le PER permet une déduction fiscale qui peut augmenter le montant net investi.',
    'La diversification sectorielle et géographique peut nécessiter un montant plus important pour répartir l\'investissement entre plusieurs SCPI. Le nombre de SCPI doit être adapté au montant.',
  ],
  tableTitle: 'Montant indicatif / Lecture possible / Diversification envisageable / Vigilance',
  tableRows: [
    {
      level: 'Moins de 10 000 €',
      advantage: 'Accès possible via le minimum de souscription de certaines SCPI ou via une assurance-vie.',
      vigilance: 'Diversification très limitée. Privilégier une SCPI diversifiée de qualité plutôt que plusieurs SCPI de moindre qualité.',
    },
    {
      level: '10 000 € à 50 000 €',
      advantage: 'Possibilité de répartir entre 1 et 3 SCPI. Choix entre direct, AV ou mix.',
      vigilance: 'Vérifier les frais de souscription qui pèsent proportionnellement plus sur les petits montants.',
    },
    {
      level: '50 000 € à 150 000 €',
      advantage: 'Diversification possible entre 3 et 5 SCPI. Secteurs variés, géographies et enveloppes.',
      vigilance: 'Éviter la sur-diversification. Chaque SCPI doit représenter un montant significatif (> 10 000 €).',
    },
    {
      level: 'Plus de 150 000 €',
      advantage: 'Allocation patrimoniale complète : 5 à 8 SCPI, secteurs variés, enveloppes multiples (direct, AV, PER).',
      vigilance: 'Veiller à la cohérence d\'ensemble et à la lisibilité du portefeuille. Consulter un conseiller.',
    },
  ],
  tableNote:
    'Ces repères sont des simulations indicatives. Le montant réel doit être adapté à la situation personnelle, à l\'horizon et aux objectifs.',
  criteriaTitle: 'Facteurs à prendre en compte pour déterminer le montant',
  criteriaCards: [
    { title: 'Patrimoine total', text: 'Évaluer la part de l\'immobilier (direct + SCPI) dans le patrimoine global. Éviter la sur-concentration immobilière.' },
    { title: 'Liquidité disponible', text: 'Ne pas immobiliser toute son épargne. Conserver une épargne de précaution accessible à court terme (3-6 mois de dépenses).' },
    { title: 'Horizon', text: 'Plus l\'horizon est long, plus le montant peut être important. Éviter les SCPI si sortie prévue avant 8 ans.' },
    { title: 'Besoin de revenus', text: 'Le montant investi détermine le niveau de revenus complémentaires. Simuler le rendement net attendu.' },
    { title: 'Fiscalité', text: 'Adapter le montant et l\'enveloppe à la TMI. L\'impact fiscal peut modifier le rendement net de manière significative.' },
    { title: 'Crédit', text: 'L\'effet de levier peut augmenter la capacité d\'investissement mais amplifie le risque. Simuler le cash-flow.' },
    { title: 'Frais', text: 'Les frais de souscription (8-12 %) réduisent le montant net investi. En tenir compte dans le calibrage.' },
    { title: 'Délai de jouissance', text: 'Le délai retarde les premiers revenus. À intégrer dans le calcul du rendement de première année.' },
  ],
  commonErrors: [
    'Investir toute son épargne disponible en SCPI sans conserver de liquidité de précaution.',
    'Investir un montant trop faible pour permettre une diversification suffisante.',
    'Ne pas tenir compte de la liquidité de précaution (besoin à court terme).',
    'Investir avec un horizon trop court (< 8 ans).',
    'Sous-estimer l\'impact des frais de souscription sur le montant net investi.',
    'Confondre capacité d\'investissement et somme à immobiliser sans précaution.',
    'Investir sans simuler le rendement net après fiscalité et frais.',
    'Négliger le délai de jouissance pour les investissements à crédit.',
  ],
  practicalCases: [
    {
      title: 'Investir 10 000 € en SCPI : bien commencer',
      text: 'Avec 10 000 €, l\'objectif n\'est pas de construire un portefeuille complet mais de poser une première pierre de qualité. Simulation pédagogique : choisir une SCPI diversifiée (bureaux, commerces, santé) avec un bon historique de distribution et un TOF élevé. Comprendre que les frais de souscription (8-12 %) réduisent le capital net investi à environ 8 800-9 200 €. Éviter de disperser ce montant sur plusieurs SCPI : une seule SCPI de qualité est préférable à deux SCPI d\'entrée de gamme.',
    },
    {
      title: 'Investir 50 000 € en SCPI : construire une première allocation',
      text: 'Avec 50 000 €, une première diversification est envisageable. Simulation pédagogique : répartir entre 2 et 3 SCPI de secteurs complémentaires (bureaux, commerces, logistique ou santé). Par exemple : 25 000 € sur une SCPI de bureaux diversifiée, 15 000 € sur une SCPI de commerces et 10 000 € sur une SCPI santé. L\'enveloppe (direct, assurance-vie ou mix) doit être choisie selon la TMI. Simulation non contractuelle, hors frais et fiscalité réelle.',
    },
    {
      title: 'Investir 100 000 € en SCPI : fiscalité, diversification et détention',
      text: 'Avec 100 000 €, l\'enjeu dépasse le simple choix de SCPI. Simulation pédagogique : arbitrer entre enveloppes (direct, assurance-vie, PER) selon la TMI. À TMI 30-41 %, l\'assurance-vie réduit l\'IR immédiat. À TMI 11 %, les SCPI européennes en direct (PS 0 %) maximisent le rendement net. Diversifier sur 3 à 5 SCPI couvrant plusieurs secteurs et géographies (France + Europe). Envisager le démembrement ou le crédit selon les objectifs. Simulation non contractuelle, hors frais et fiscalité réelle.',
    },
    {
      title: 'Exemple pédagogique — 100 000 € d\'épargne disponible',
      text: 'Un investisseur dispose de 100 000 € d\'épargne financière. Simulation : conserver 20 000 € de liquidité de précaution. Investir 80 000 € en SCPI. Répartition possible : 2 SCPI en direct (50 000 €) et 1 SCPI en AV (30 000 €). Simulation pédagogique simplifiée, hors frais, hors fiscalité complète, hors variation du prix des parts, sans garantie de rendement et sous réserve de la situation personnelle.',
    },
    {
      title: 'Jeune investisseur — 15 000 €',
      text: 'Un jeune actif TMI 11 % souhaite investir 15 000 €. Simulation : 1 SCPI diversifiée en direct ou en AV. Montant suffisant pour une exposition de qualité, mais diversification limitée. Privilégier une SCPI de grande capitalisation avec bon TOF.',
    },
    {
      title: 'Retraité — 80 000 €, besoin de revenus',
      text: 'Un retraité TMI 11 % ou 30 % dispose de 80 000 € et cherche des revenus complémentaires. Simulation : 3 SCPI maximum, privilégier les SCPI à TOF stable et délai de jouissance court. Enveloppe : direct ou AV selon la fiscalité et l\'âge.',
    },
    {
      title: 'Investisseur fortement fiscalisé — 150 000 €',
      text: 'Un investisseur TMI 41 % avec 150 000 € cherche à optimiser sa fiscalité. Simulation : PER avec SCPI (déduction TMI jusqu\'à 10 % des revenus), SCPI européennes en direct (PS 0 %), SCPI en AV pour le report d\'imposition.',
    },
    {
      title: 'Investisseur horizon court (5 ans)',
      text: 'Un investisseur prévoit de récupérer son capital sous 5 ans. Simulation pédagogique : l\'horizon est court pour une SCPI. Si l\'investissement est envisagé, privilégier une SCPI à capital variable avec collecte positive. Rester vigilant sur le risque de liquidité.',
    },
  ],
  methodParagraphs: [
    'MaximusSCPI aide à calibrer un projet d\'investissement en SCPI à travers ses contenus pédagogiques. Le montant est abordé comme un élément de la stratégie patrimoniale, pas comme un objectif isolé.',
    'La première étape consiste à analyser la situation globale : patrimoine total, liquidité disponible, horizon, fiscalité, objectifs.',
    'La deuxième étape détermine le montant allouable aux SCPI en déduisant la liquidité de précaution et les autres projets patrimoniaux.',
    'La troisième étape répartit ce montant entre les SCPI et les enveloppes en fonction des objectifs, de la fiscalité et de la diversification souhaitée.',
    'MaximusSCPI ne constitue pas une recommandation personnalisée. Le calibrage final doit être validé avec un conseiller du Cabinet Eric Bellaiche.',
  ],
  conclusionParagraphs: [
    'Le montant à investir en SCPI dépend de multiples facteurs personnels. Il n\'existe pas de réponse universelle. La cohérence patrimoniale prime sur la recherche du rendement maximal.',
    'Sources et points à vérifier : DIC, notes d\'information, rapports annuels, bulletins trimestriels, simulation personnelle avec son conseiller.',
    'Utilisez le comparateur MaximusSCPI pour visualiser les SCPI, puis validez votre projet avec un conseiller.',
  ],
  faqItems: [
    {
      question: 'Quel est le montant minimum pour investir en SCPI ?',
      answer: 'Le minimum varie de 1 000 € à 5 000 € selon les SCPI, parfois plus pour certaines. En assurance-vie, le seuil peut être plus bas.',
    },
    {
      question: 'Peut-on investir 10 000 € en SCPI ?',
      answer: 'Oui, c\'est un montant accessible. La diversification sera limitée à 1 ou 2 SCPI. Privilégier une SCPI de qualité.',
    },
    {
      question: 'Combien de SCPI avec 50 000 € ?',
      answer: '2 à 3 SCPI maximum. Répartir entre secteurs ou enveloppes selon les objectifs patrimoniaux.',
    },
    {
      question: 'Faut-il investir toute son épargne en SCPI ?',
      answer: 'Non. Il est déconseillé d\'immobiliser toute son épargne dans des actifs non liquides. Conserver une épargne de précaution.',
    },
    {
      question: 'Quelle part du patrimoine mettre en SCPI ?',
      answer: 'Cela dépend de la situation. Une règle de prudence : ne pas dépasser 30-50 % de l\'épargne financière dans des actifs immobiliers non cotés.',
    },
    {
      question: 'Le crédit change-t-il le montant à investir ?',
      answer: 'Oui, le crédit peut augmenter la capacité d\'investissement par effet de levier. Mais il augmente aussi le risque. Simuler le cash-flow avant.',
    },
    {
      question: 'Comment intégrer la fiscalité dans le calibrage ?',
      answer: 'Simuler le rendement net après impôt selon sa TMI. Adapter le montant et l\'enveloppe en fonction de sa situation fiscale.',
    },
    {
      question: 'Investir progressivement ou tout d\'un coup ?',
      answer: 'Investir progressivement peut lisser le prix d\'entrée et le risque de calendrier. À discuter avec un conseiller.',
    },
    {
      question: 'Quel impact des frais sur le montant net investi ?',
      answer: 'Les frais de souscription (8-12 %) réduisent le montant effectivement investi. Sur 10 000 €, seuls 8 800 à 9 200 € sont réellement placés.',
    },
    {
      question: 'Comment MaximusSCPI aide à calibrer un projet ?',
      answer: 'Les contenus pédagogiques et le comparateur fournissent les repères pour analyser. MaximusSCPI ne constitue pas une recommandation personnalisée.',
    },
  ],
  comparateurCtaLabel: 'Calibrer votre montant d\'investissement SCPI',
}
