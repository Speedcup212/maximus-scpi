import type { ScpiEducationalPageConfig } from './shared'

export const scpiExpatrieFiscaliteConfig: ScpiEducationalPageConfig = {
  path: '/scpi-expatrie-fiscalite',
  badge: 'Fiscalité et modes de détention',
  h1: 'SCPI pour expatrié : opportunité ou complexité fiscale ?',
  heroSubtitle:
    'Les SCPI peuvent être pertinentes pour un investisseur expatrié, mais la fiscalité internationale ajoute une couche de complexité. Résidence fiscale, conventions fiscales, revenus de source française et étrangère, modalités de souscription, déclaration : cette page présente les points à analyser avant d\'investir en SCPI depuis l\'étranger.',
  seoTitle: 'SCPI expatrié : fiscalité, conventions, déclaration et vigilance',
  seoDescription:
    'Analyse des points de vigilance pour un investissement en SCPI depuis l\'étranger : résidence fiscale, conventions, revenus de source française, déclaration, liquidité, mode de détention et risques pour expatrié.',
  shortAnswerTitle: 'Un expatrié peut-il investir en SCPI ?',
  shortAnswer:
    'Oui, un expatrié peut investir en SCPI, mais plusieurs points méritent une attention particulière : sa résidence fiscale détermine le régime d\'imposition des revenus, les conventions fiscales internationales peuvent éviter la double imposition, les modalités de souscription diffèrent selon le pays de résidence, et la liquidité est à anticiper en cas de rapatriement. Il est recommandé d\'analyser ces points avec un conseiller compétent en fiscalité internationale.',
  keyMessage:
    'Investir en SCPI depuis l\'étranger est possible, mais la fiscalité internationale et la déclaration doivent être anticipées. Ne pas investir sans avoir vérifié les implications fiscales dans son pays de résidence.',
  definitionParagraphs: [
    'Un investisseur expatrié (résident fiscal d\'un autre pays que la France) peut souscrire des parts de SCPI, mais le traitement fiscal des revenus distribués dépend de sa résidence fiscale et des conventions fiscales entre la France et son pays de résidence.',
    'Les revenus distribués par une SCPI française à un non-résident sont soumis, en principe, à une retenue à la source en France. Le taux de cette retenue varie selon la convention fiscale applicable. Dans certains cas, la retenue peut être réduite, voire supprimée.',
    'Les parts de SCPI détenues par un non-résident sont généralement soumises à l\'IFI si le patrimoine immobilier total (direct et indirect) dépasse 1,3 M€, sous certaines conditions. Le lieu de résidence peut influencer l\'assujettissement.',
    'La souscription peut être plus complexe depuis l\'étranger : certaines sociétés de gestion exigent un correspondant fiscal en France, des justificatifs spécifiques, ou limitent la souscription aux résidents français.',
    'En cas de retour en France, le portefeuille de SCPI souscrit depuis l\'étranger continue de produire des revenus et doit être intégré dans la déclaration de revenus française. Anticiper cette transition est recommandé.',
    'La liquidité des parts depuis l\'étranger est identique à celle d\'un résident français. En revanche, la revente peut être plus complexe si la société de gestion ou le marché secondaire impose des contraintes aux non-résidents. À vérifier avant d\'investir.',
  ],
  tableTitle: 'Profil / Situation fiscale possible / Points à vérifier / Vigilance',
  tableRows: [
    {
      level: 'Expatrié dans l\'UE/EEE',
      advantage: 'Conventions fiscales souvent favorables. Retenue à la source réduite ou nulle dans certains cas.',
      vigilance: 'Vérifier la convention fiscale spécifique avec le pays de résidence. Les règles diffèrent selon les pays.',
    },
    {
      level: 'Expatrié hors UE',
      advantage: 'Possibilité d\'investir si la société de gestion l\'autorise. Certaines SCPI acceptent les non-résidents.',
      vigilance: 'Retenue à la source potentiellement plus élevée. Complexité déclarative accrue. Vérifier l\'acceptation par la société de gestion.',
    },
    {
      level: 'Résident fiscal français à l\'étranger (détachement)',
      advantage: 'Maintien possible des liens fiscaux avec la France. Régime des non-résidents parfois avantageux.',
      vigilance: 'La durée du détachement et le lieu de résidence fiscale déterminent le régime applicable. Anticiper le retour.',
    },
    {
      level: 'Investissement via assurance-vie',
      advantage: 'Fiscalité différée et potentiellement plus simple pour un non-résident.',
      vigilance: 'Les conditions de souscription et de détention pour un non-résident varient selon les assureurs.',
    },
  ],
  tableNote:
    'Ces repères sont des simulations indicatives. La fiscalité internationale est complexe et dépend de chaque situation personnelle.',
  criteriaTitle: 'Points à analyser avant d\'investir en SCPI depuis l\'étranger',
  criteriaCards: [
    { title: 'Résidence fiscale', text: 'Votre pays de résidence fiscale détermine l\'imposition des revenus SCPI. Vérifier la convention fiscale avec la France.' },
    { title: 'Retenue à la source', text: 'Les revenus de source française peuvent subir une retenue à la source. Le taux dépend de la convention fiscale.' },
    { title: 'Déclaration', text: 'Les revenus doivent être déclarés dans le pays de résidence et éventuellement en France. Anticiper la double déclaration.' },
    { title: 'Souscription', text: 'Vérifier que la société de gestion accepte les souscriptions depuis votre pays de résidence.' },
    { title: 'Liquidité', text: 'La revente depuis l\'étranger peut être plus complexe. Vérifier les conditions de retrait pour un non-résident.' },
    { title: 'Retour en France', text: 'Anticiper l\'intégration du portefeuille dans la déclaration de revenus française en cas de rapatriement.' },
    { title: 'IFI', text: 'Les parts de SCPI détenues par un non-résident peuvent être soumises à l\'IFI sous certaines conditions.' },
    { title: 'Conseil', text: 'La fiscalité internationale nécessite un conseil spécialisé. Ne pas investir sans analyse préalable.' },
  ],
  commonErrors: [
    'Investir sans vérifier la convention fiscale entre la France et le pays de résidence.',
    'Confondre résidence fiscale et nationalité.',
    'Ne pas anticiper la déclaration des revenus dans les deux pays.',
    'Sous-estimer la complexité administrative d\'une souscription depuis l\'étranger.',
    'Investir sans vérifier si la société de gestion accepte les non-résidents.',
    'Négliger l\'impact d\'un retour en France sur la fiscalité du portefeuille.',
    'Ignorer les règles de change et de transfert international de fonds.',
  ],
  practicalCases: [
    {
      title: 'Expatrié au Portugal',
      text: 'Un expatrié résident fiscal au Portugal souhaite investir 50 000 € en SCPI. Simulation pédagogique : vérifier la convention France-Portugal (taux de retenue à la source). Souscription en direct possible si la société de gestion l\'autorise. Déclaration des revenus au Portugal. Simulation non contractuelle, sans garantie de rendement.',
    },
    {
      title: 'Expatrié à Singapour',
      text: 'Un résident fiscal à Singapour souhaite investir 100 000 € en SCPI. Simulation pédagogique : Singapour n\'a pas de convention fiscale complète avec la France sur les revenus fonciers. Retenue à la source potentiellement élevée. Vérifier l\'acceptation par la société de gestion. Simulation non contractuelle.',
    },
  ],
  methodParagraphs: [
    'MaximusSCPI fournit des repères pédagogiques sur l\'investissement en SCPI. Ce contenu n\'est pas un conseil fiscal personnalisé.',
    'Avant d\'investir en SCPI depuis l\'étranger, il est recommandé de consulter un expert en fiscalité internationale.',
    'Vérifier les conditions de souscription auprès de chaque société de gestion.',
  ],
  conclusionParagraphs: [
    'Investir en SCPI depuis l\'étranger est possible, mais la complexité fiscale et administrative doit être anticipée. La convention fiscale, le mode de détention et la déclaration sont des points clés.',
    'Sources et points à vérifier : convention fiscale entre la France et le pays de résidence, DIC, note d\'information, conditions de souscription des sociétés de gestion.',
    'Utilisez le comparateur MaximusSCPI pour repérer les SCPI, puis validez votre projet avec un conseiller compétent en fiscalité internationale.',
  ],
  faqItems: [
    {
      question: 'Un expatrié peut-il souscrire des parts de SCPI ?',
      answer: 'Oui, sous réserve que la société de gestion accepte les souscriptions depuis son pays de résidence. Vérifier les conditions avant d\'investir.',
    },
    {
      question: 'Comment sont imposés les revenus de SCPI pour un non-résident ?',
      answer: 'Ils sont soumis à une retenue à la source en France, dont le taux dépend de la convention fiscale avec le pays de résidence.',
    },
    {
      question: 'Faut-il déclarer les revenus SCPI dans son pays de résidence ?',
      answer: 'Oui, sauf exonération prévue par la convention fiscale. La double imposition peut être évitée par crédit d\'impôt ou exonération.',
    },
    {
      question: 'Peut-on investir en SCPI via une assurance-vie depuis l\'étranger ?',
      answer: 'Oui, mais les conditions varient selon les assureurs. Certains contrats peuvent être plus adaptés aux non-résidents.',
    },
    {
      question: 'Les parts de SCPI sont-elles soumises à l\'IFI pour un non-résident ?',
      answer: 'Oui, si le patrimoine immobilier total (direct et indirect) dépasse 1,3 M€, sous certaines conditions.',
    },
    {
      question: 'Que se passe-t-il fiscalement en cas de retour en France ?',
      answer: 'Le portefeuille de SCPI continue de produire des revenus imposables en France. Anticiper cette transition avec un conseiller.',
    },
    {
      question: 'Existe-t-il des SCPI spécialement conçues pour les non-résidents ?',
      answer: 'Certaines SCPI acceptent les non-résidents, mais il n\'existe pas de SCPI dédiée. Vérifier les conditions société par société.',
    },
  ],
}
