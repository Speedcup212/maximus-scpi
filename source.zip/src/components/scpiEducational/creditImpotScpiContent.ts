import type { ScpiEducationalPageConfig } from './shared'

export const creditImpotScpiConfig: ScpiEducationalPageConfig = {
  path: '/scpi-credit-impot/',
  badge: 'Fiscalité SCPI',
  h1: 'Crédit d\'impôt SCPI : comprendre le mécanisme des revenus étrangers',
  heroSubtitle:
    'Le crédit d\'impôt est un mécanisme fiscal fondamental pour les SCPI investies en Europe. Il évite la double imposition des revenus immobiliers étrangers. Son application dépend du pays d\'origine, de la convention fiscale et de la situation de l\'investisseur.',
  seoTitle: 'Crédit d\'impôt SCPI : principe, pays concernés, calcul et déclaration',
  seoDescription:
    'Analyse complète du crédit d\'impôt applicable aux revenus étrangers de SCPI : principe, conventions fiscales, pays concernés, plafonnement, déclaration, rendement net. Cas pratiques TMI 11 %, 30 %, 41 %, 45 %.',
  shortAnswerTitle: 'Qu\'est-ce que le crédit d\'impôt pour revenus étrangers de SCPI ?',
  shortAnswer:
    'Le crédit d\'impôt évite qu\'un même revenu immobilier étranger soit imposé deux fois : dans le pays d\'origine (où est situé l\'immeuble) et en France. L\'impôt déjà payé à l\'étranger vient en déduction de l\'impôt français dû. Le crédit d\'impôt est plafonné à l\'impôt français correspondant : si le crédit dépasse l\'impôt dû, l\'excédent n\'est généralement pas remboursé. Ce mécanisme ne doit pas être confondu avec une réduction d\'impôt : il s\'agit d\'une neutralisation de la double imposition.',
  keyMessage:
    'Le crédit d\'impôt peut améliorer la fiscalité de certains revenus étrangers de SCPI, mais son application dépend des pays et des conventions fiscales. Il n\'est pas une réduction d\'impôt.',
  definitionParagraphs: [
    'Le crédit d\'impôt pour revenus étrangers est un mécanisme prévu par la plupart des conventions fiscales signées par la France. Il permet à un résident fiscal français de déduire de son impôt français l\'impôt déjà acquitté à l\'étranger sur des revenus immobiliers de source étrangère.',
    'Pour les SCPI, le crédit d\'impôt s\'applique aux revenus perçus par la SCPI dans les pays où elle détient des actifs immobiliers. La société de gestion communique chaque année une fiche fiscale indiquant, pour chaque pays, le montant des revenus et le montant du crédit d\'impôt correspondant.',
    'Le crédit d\'impôt est plafonné : il ne peut pas excéder le montant de l\'impôt français dû au titre des mêmes revenus. Si le crédit d\'impôt est supérieur à l\'impôt dû, l\'excédent n\'est généralement pas remboursé. Il est donc important de vérifier le taux d\'imposition effectif dans le pays d\'origine.',
    'Il ne faut pas confondre crédit d\'impôt et réduction d\'impôt. Le crédit d\'impôt correspond à un impôt déjà payé à l\'étranger : il neutralise la double imposition. La réduction d\'impôt est un avantage fiscal spécifique (ex. : investissement Malraux, Denormandie) qui réduit l\'impôt dû sans lien avec un impôt déjà acquitté.',
    'Le montant du crédit d\'impôt dépend du taux d\'imposition effectif appliqué par le pays d\'origine et des stipulations de la convention fiscale. Il n\'est pas nécessairement égal à l\'impôt réellement payé.',
    'Certains pays ne permettent pas un crédit d\'impôt mais appliquent un mécanisme de taux effectif. Dans ce cas, le revenu étranger n\'est pas imposé en France mais est pris en compte pour déterminer le taux d\'imposition global du foyer.',
    'Les conventions fiscales les plus courantes pour les SCPI concernent l\'Allemagne, les Pays-Bas, l\'Espagne, l\'Italie, la Belgique et le Luxembourg. Chaque convention prévoit des modalités spécifiques.',
  ],
  tableTitle: 'Mécanismes : crédit d\'impôt vs taux effectif',
  tableRows: [
    {
      level: 'Double imposition',
      advantage: 'Le même revenu est imposable dans le pays d\'origine et en France.',
      vigilance: 'Sans mécanisme correcteur, l\'investisseur paierait deux fois l\'impôt sur le même revenu.',
    },
    {
      level: 'Crédit d\'impôt',
      advantage: 'L\'impôt payé à l\'étranger s\'impute sur l\'IR français. Évite la double imposition.',
      vigilance: 'Plafonné à l\'impôt français correspondant. Excédent non remboursable.',
    },
    {
      level: 'Taux effectif',
      advantage: 'Le revenu étranger n\'est pas imposé en France.',
      vigilance: 'Le taux applicable aux autres revenus peut augmenter. Impact indirect.',
    },
    {
      level: 'Convention fiscale',
      advantage: 'Définit les modalités d\'imposition et le mécanisme applicable.',
      vigilance: 'Chaque pays a sa propre convention. À vérifier pays par pays.',
    },
    {
      level: 'Déclaration',
      advantage: 'La société de gestion fournit une fiche fiscale détaillée.',
      vigilance: 'Déclaration spécifique à effectuer. Les formulaires peuvent varier.',
    },
  ],
  tableNote:
    'Les modalités précises dépendent de la convention fiscale applicable. À vérifier pays par pays.',
  criteriaTitle: 'Critères à croiser avec le crédit d\'impôt',
  criteriaCards: [
    { title: 'Pays d\'investissement', text: 'Chaque pays a sa propre convention. Le crédit d\'impôt varie selon le pays et son taux d\'imposition.' },
    { title: 'Convention fiscale', text: 'La convention détermine l\'existence et le calcul du crédit d\'impôt. Certaines conventions prévoient un taux effectif plutôt qu\'un crédit d\'impôt.' },
    { title: 'Fiche fiscale', text: 'Document fourni par la société de gestion. Indique les montants par pays. À conserver pour la déclaration.' },
    { title: 'Rendement net', text: 'Le crédit d\'impôt peut améliorer le rendement net fiscal par rapport à une SCPI française de rendement équivalent.' },
    { title: 'TMI', text: 'La TMI détermine l\'impôt français de référence. Le crédit d\'impôt est plafonné à cet impôt. À TMI élevée, le crédit d\'impôt est pleinement utilisé.' },
    { title: 'Plafonnement', text: 'Si l\'impôt étranger est supérieur à l\'impôt français, l\'excédent n\'est pas remboursé. À vérifier selon le taux d\'imposition du pays.' },
  ],
  commonErrors: [
    'Confondre crédit d\'impôt et réduction d\'impôt : le crédit d\'impôt n\'est pas un avantage fiscal, c\'est une neutralisation de la double imposition.',
    'Croire que le crédit d\'impôt s\'applique à toutes les SCPI européennes : cela dépend de la convention fiscale avec chaque pays.',
    'Penser que le crédit d\'impôt rembourse l\'excédent si l\'impôt étranger est supérieur à l\'impôt français.',
    'Oublier de déclarer les revenus étrangers et le crédit d\'impôt correspondant.',
    'Négliger la fiche fiscale de la société de gestion qui est indispensable à la déclaration.',
  ],
  practicalCases: [
    {
      title: 'TMI 11 % — Crédit d\'impôt non utilisé',
      text: 'Revenus étrangers : 4 000 €. Impôt étranger : 600 €. IR français avant crédit : 440 €. Crédit d\'impôt : 440 € (plafonné). Excédent non remboursé : 160 €. IR dû : 0 €.',
    },
    {
      title: 'TMI 30 % — Crédit d\'impôt partiel',
      text: 'Mêmes revenus, TMI 30 %. IR avant crédit : 1 200 €. Crédit d\'impôt : 600 €. IR dû : 600 €. Le crédit d\'impôt est pleinement utilisé.',
    },
    {
      title: 'TMI 41 % — Crédit d\'impôt intégral',
      text: 'Mêmes revenus, TMI 41 %. IR avant crédit : 1 640 €. Crédit d\'impôt : 600 €. IR dû : 1 040 €. L\'économie d\'impôt est de 600 €.',
    },
    {
      title: 'Taux effectif (Pays-Bas) — TMI 30 %',
      text: 'Revenus étrangers : 3 000 €. Pas de crédit d\'impôt mais taux effectif. Les 3 000 € augmentent le revenu global pour le calcul du taux. L\'impôt sur les autres revenus peut être légèrement augmenté.',
    },
    {
      title: 'SCPI multi-pays — Crédits d\'impôt multiples',
      text: 'Un investisseur détient une SCPI diversifiée en Allemagne, Espagne et Italie. Chaque pays génère un crédit d\'impôt distinct. La fiche fiscale unique détaille les montants par pays.',
    },
  ],
  methodParagraphs: [
    'Vérifier les pays d\'investissement de la SCPI via le rapport annuel.',
    'Consulter la fiche fiscale de la société de gestion pour chaque pays.',
    'Identifier le mécanisme applicable : crédit d\'impôt ou taux effectif.',
    'Calculer l\'impôt français avant et après crédit d\'impôt.',
    'Estimer le rendement net après prise en compte du crédit d\'impôt.',
    'Comparer avec une SCPI française pour évaluer l\'écart fiscal.',
    'Ne pas choisir une SCPI uniquement sur le critère du crédit d\'impôt.',
  ],
  conclusionParagraphs: [
    'Le crédit d\'impôt est un mécanisme important pour les SCPI européennes. Il peut améliorer le rendement net fiscal, mais son application dépend des pays, des conventions et de la situation individuelle.',
    'Il est essentiel de vérifier la fiche fiscale de la société de gestion et de ne pas confondre crédit d\'impôt et réduction d\'impôt.',
    'L\'intérêt des SCPI européennes dépasse la seule fiscalité : diversification, accès à des marchés différents. Une analyse globale est recommandée.',
  ],
  faqItems: [
    {
      question: 'Qu\'est-ce que le crédit d\'impôt en SCPI ?',
      answer: 'C\'est un mécanisme qui permet d\'imputer l\'impôt payé à l\'étranger sur l\'impôt français dû au titre des mêmes revenus. Il évite la double imposition des revenus immobiliers étrangers.',
    },
    {
      question: 'Pourquoi existe-t-il ?',
      answer: 'Pour éviter qu\'un même revenu soit imposé deux fois : dans le pays d\'origine (où se trouve l\'immeuble) et en France (où réside l\'investisseur).',
    },
    {
      question: 'Est-ce une réduction d\'impôt ?',
      answer: 'Non. Le crédit d\'impôt correspond à un impôt déjà payé à l\'étranger. Il neutralise la double imposition alors qu\'une réduction d\'impôt est un avantage fiscal distinct.',
    },
    {
      question: 'S\'applique-t-il à toutes les SCPI européennes ?',
      answer: 'Non, cela dépend des pays et des conventions fiscales. Certaines conventions prévoient un mécanisme de taux effectif plutôt qu\'un crédit d\'impôt.',
    },
    {
      question: 'Comment le crédit d\'impôt impacte-t-il le rendement net ?',
      answer: 'En réduisant l\'impôt français dû, le crédit d\'impôt améliore le rendement net fiscal par rapport à une SCPI française de rendement équivalent.',
    },
    {
      question: 'Où trouver les informations nécessaires ?',
      answer: 'La société de gestion transmet chaque année une fiche fiscale indiquant, par pays, le montant des revenus et le crédit d\'impôt correspondant.',
    },
    {
      question: 'Faut-il privilégier les SCPI avec revenus étrangers ?',
      answer: 'Les SCPI européennes peuvent améliorer le rendement net dans certaines situations, mais ce n\'est pas automatique. L\'analyse doit intégrer la convention, le pays, les risques et les objectifs.',
    },
    {
      question: 'Que faire si le crédit d\'impôt dépasse l\'impôt français ?',
      answer: 'L\'excédent n\'est généralement pas remboursable. Il est donc important de vérifier le taux d\'imposition dans le pays d\'origine.',
    },
    {
      question: 'Le crédit d\'impôt est-il cumulable avec d\'autres dispositifs ?',
      answer: 'Le crédit d\'impôt pour revenus étrangers est un mécanisme de droit commun qui s\'applique indépendamment des autres dispositifs fiscaux éventuels.',
    },
    {
      question: 'Comment MaximusSCPI analyse ce mécanisme ?',
      answer: 'MaximusSCPI intègre le crédit d\'impôt et le taux effectif dans l\'analyse du rendement net des SCPI européennes, selon les informations disponibles et les conventions applicables. L\'approche est pédagogique.',
    },
  ],
  comparateurCtaLabel: 'Comparer les SCPI par exposition géographique',
}
