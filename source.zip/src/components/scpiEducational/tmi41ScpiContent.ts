import type { ScpiEducationalPageConfig } from './shared'

export const tmi41ScpiConfig: ScpiEducationalPageConfig = {
  path: '/scpi-tmi-41/',
  badge: 'Fiscalité SCPI',
  h1: 'SCPI avec TMI 41 % : fiscalité, rendement net et arbitrages',
  heroSubtitle:
    'À 41 % de tranche marginale d\'imposition, la fiscalité devient un facteur déterminant dans l\'analyse du rendement net d\'une SCPI. Les revenus fonciers français sont lourdement imposés. Plusieurs pistes peuvent être étudiées pour améliorer la situation, sans solution universelle.',
  seoTitle: 'SCPI TMI 41 % : fiscalité, Europe, démembrement, assurance-vie et rendement net',
  seoDescription:
    'Analyse détaillée des SCPI avec une TMI à 41 % : rendement net fiscal, impact des prélèvements sociaux, SCPI européennes, démembrement, assurance-vie, SCI à l\'IS. Cas pratiques TMI 11 %, 30 %, 41 % et 45 %.',
  shortAnswerTitle: 'Pourquoi la TMI 41 % change-t-elle radicalement l\'analyse ?',
  shortAnswer:
    'Avec une TMI à 41 %, un revenu foncier de SCPI française supporte une pression fiscale élevée : 41 % au titre de l\'IR, auxquels s\'ajoutent les prélèvements sociaux (taux en vigueur, environ 17,5 %). Le cumul peut dépasser 58 % des revenus bruts. Cela ne signifie pas qu\'il faut renoncer aux SCPI, mais que l\'analyse doit impérativement intégrer la fiscalité comme critère central et explorer les alternatives : SCPI européennes, démembrement, assurance-vie, SCI à l\'IS, crédit.',
  keyMessage:
    'À TMI 41 %, le choix d\'une SCPI doit intégrer le rendement net fiscal, pas seulement le rendement affiché. L\'écart entre brut et net peut dépasser 50 %.',
  definitionParagraphs: [
    'La tranche marginale d\'imposition (TMI) est le taux auquel est imposé le dernier euro de revenu d\'un foyer fiscal. En 2026, la TMI à 41 % concerne les revenus compris entre certains seuils pour une part de quotient familial. Ces seuils sont susceptibles d\'être revalorisés chaque année.',
    'Les revenus fonciers issus de SCPI françaises s\'ajoutent aux autres revenus du foyer (salaires, pensions, revenus professionnels) et sont imposés à la TMI correspondante. À 41 %, l\'impôt sur le revenu seul prélève 41 % des revenus fonciers perçus.',
    'Les prélèvements sociaux s\'ajoutent à l\'IR. Ils sont calculés sur le montant brut des revenus fonciers, avant déduction des éventuelles charges. Le cumul IR + PS peut représenter une part très significative des revenus distribués par une SCPI française.',
    'L\'impact fiscal varie selon l\'origine des revenus. Les SCPI françaises sont imposées au taux plein. Les SCPI européennes peuvent bénéficier d\'un crédit d\'impôt ou d\'un taux effectif selon la convention fiscale applicable, ce qui peut réduire le poids fiscal.',
    'Plusieurs pistes peuvent être étudiées pour améliorer le rendement net à TMI 41 % : SCPI européennes (crédit d\'impôt), démembrement (neutralisation temporaire des revenus), assurance-vie (capitalisation, fiscalité allégée au rachat), SCI à l\'IS (imposition société), ou investissement à crédit (déduction des intérêts d\'emprunt).',
    'Aucune de ces pistes n\'est universellement meilleure. Le choix dépend de la situation personnelle : besoin ou non de revenus, horizon d\'investissement, patrimoine existant, objectifs de transmission, tolérance au risque.',
    'Il est important de noter que la fiscalité applicable peut évoluer. Les taux, seuils et règles sont susceptibles d\'être modifiés par la loi de finances. Les simulations présentées ici sont indicatives.',
  ],
  tableTitle: 'Options potentielles avec une TMI 41 %',
  tableRows: [
    {
      level: 'SCPI françaises en direct',
      advantage: 'Simplicité de gestion. Large choix de SCPI. Frais limités.',
      vigilance: 'Rendement net fortement réduit par IR + PS. Peut perdre une grande partie de son attractivité à TMI 41 %.',
    },
    {
      level: 'SCPI européennes',
      advantage: 'Crédit d\'impôt possible selon convention. Prélèvements sociaux potentiellement réduits. Amélioration du rendement net.',
      vigilance: 'Fiscalité variable selon le pays d\'investissement. Documentation fiscale à vérifier. Risque de change ou géopolitique.',
    },
    {
      level: 'Nue-propriété',
      advantage: 'Absence de revenus imposables pendant la durée du démembrement. Fiscalité neutralisée.',
      vigilance: 'Pas de revenus disponibles. Horizon long. Décote à analyser.',
    },
    {
      level: 'Assurance-vie',
      advantage: 'Capitalisation des revenus sans imposition immédiate. Fiscalité allégée après 8 ans. Transmission avantageuse.',
      vigilance: 'Frais du contrat. Choix limité de SCPI en UC. Pas de déduction d\'intérêts d\'emprunt.',
    },
    {
      level: 'SCI à l\'IS',
      advantage: 'Imposition à l\'IS (taux potentiellement inférieur). Capitalisation possible. Amortissement comptable.',
      vigilance: 'Double imposition lors de la distribution (IS + impôt sur dividendes). Frais comptables et juridiques.',
    },
    {
      level: 'Crédit',
      advantage: 'Déduction des intérêts d\'emprunt des revenus fonciers. Effet de levier.',
      vigilance: 'Cash-flow à analyser. Endettement global. Risque de taux.',
    },
  ],
  tableNote:
    'Ces pistes sont des orientations à approfondir selon la situation. Aucune n\'est universellement recommandable. À valider selon votre situation personnelle.',
  criteriaTitle: 'Critères à croiser avec la TMI 41 %',
  criteriaCards: [
    { title: 'Rendement net fiscal', text: 'Le rendement brut doit être retraité de l\'IR (41 %) et des PS (taux en vigueur). L\'écart avec le brut peut dépasser 50 %. À quantifier avant toute décision.' },
    { title: 'Besoin de revenus', text: 'Avec besoin de revenus, le direct ou l\'assurance-vie avec rachats sont à étudier. Sans besoin, la capitalisation (AV, nue-propriété, SCI à l\'IS) peut être pertinente.' },
    { title: 'Horizon d\'investissement', text: 'Un horizon long (> 10 ans) peut justifier des solutions à fiscalité différée. Un horizon court (< 5 ans) rend la fiscalité immédiate incontournable.' },
    { title: 'Origine des revenus', text: 'Les SCPI européennes peuvent améliorer le rendement net grâce au crédit d\'impôt et à une fiscalité allégée. À étudier selon les pays et conventions.' },
    { title: 'IFI', text: 'À vérifier selon le patrimoine global. Les parts en direct sont imposables. L\'assurance-vie et la nue-propriété peuvent avoir un traitement différent.' },
    { title: 'Transmission', text: 'Si l\'objectif de transmission est prioritaire, l\'assurance-vie et la SCI à l\'IS peuvent présenter des avantages spécifiques.' },
    { title: 'Frais', text: 'Les frais d\'enveloppe (AV, SCI) réduisent le rendement brut. Ils doivent être mis en balance avec l\'avantage fiscal attendu.' },
  ],
  commonErrors: [
    'Se focaliser uniquement sur le rendement brut en ignorant l\'impact fiscal, ce qui conduit à surévaluer le rendement réel.',
    'Croire que les SCPI européennes sont toujours fiscalement meilleures : cela dépend de la convention fiscale, du pays et de la situation personnelle.',
    'Penser que l\'assurance-vie annule toute fiscalité : les plus-values sont imposées en cas de rachat, avec un abattement après 8 ans.',
    'Négliger l\'impact des frais de structure (AV, SCI) dans l\'analyse globale : des frais élevés peuvent annuler l\'avantage fiscal.',
    'Oublier l\'IFI dans l\'analyse patrimoniale globale : les SCPI en direct peuvent augmenter l\'assiette IFI.',
    'Choisir une solution complexe (SCI à l\'IS) sans que l\'objectif patrimonial ne la justifie.',
  ],
  practicalCases: [
    {
      title: 'TMI 11 % — Fiscalité légère, rendement net proche du brut',
      text: 'Rendement brut 6 %. IR = 0,66 %. PS = 1,05 %. Rendement net estimé : environ 4,3 %. L\'investisseur conserve environ 72 % du brut. Le choix SCPI peut surtout reposer sur les critères patrimoniaux et de risque.',
    },
    {
      title: 'TMI 30 % — Impact moyen, arbitrage à étudier',
      text: 'Rendement brut 6 %. IR = 1,80 %. PS = 1,05 %. Rendement net estimé : environ 3,2 %. L\'investisseur conserve environ 53 % du brut. L\'arbitrage entre direct, AV et SCPI européennes commence à être pertinent.',
    },
    {
      title: 'TMI 41 % — Pression fiscale forte, alternatives prioritaires',
      text: 'Rendement brut 6 %. IR = 2,46 %. PS = 1,05 %. Rendement net estimé : environ 2,5 %. L\'investisseur conserve environ 42 % du brut. Les alternatives (Europe, nue-propriété, AV, SCI) deviennent des pistes sérieuses.',
    },
    {
      title: 'TMI 45 % — Pression fiscale maximale',
      text: 'Rendement brut 6 %. IR = 2,70 %. PS = 1,05 %. Rendement net estimé : environ 2,3 %. L\'investisseur conserve environ 38 % du brut. L\'analyse des alternatives est déterminante.',
    },
    {
      title: 'Absence de besoin de revenus — Capitalisation en AV',
      text: 'Un investisseur TMI 41 % sans besoin de revenus place 100 000 € en SCPI via assurance-vie. Rendement brut 6 %. Les 6 000 € annuels sont capitalisés sans IR ni PS immédiats. Après 10 ans, la fiscalité ne s\'applique qu\'en cas de rachat.',
    },
  ],
  methodParagraphs: [
    'Identifier sa tranche marginale d\'imposition (TMI) et vérifier les seuils applicables.',
    'Analyser le rendement brut affiché de la SCPI (TDVM ou taux de distribution sur VR).',
    'Calculer le rendement net fiscal estimé : rendement brut − IR (TMI) − prélèvements sociaux.',
    'Déterminer l\'origine des revenus de la SCPI (France, Europe, mixte) et le cadre fiscal applicable.',
    'Étudier les pistes d\'amélioration selon le besoin de revenus et l\'horizon.',
    'Comparer les différentes enveloppes : direct, AV, nue-propriété, SCI à l\'IS, crédit.',
    'Intégrer l\'IFI si le patrimoine immobilier dépasse le seuil applicable.',
    'Ne pas conclure sur la seule base du rendement brut. Croiser avec le risque, la liquidité et la diversification.',
  ],
  conclusionParagraphs: [
    'À TMI 41 %, la fiscalité est un critère central dans l\'analyse d\'une SCPI. Le rendement brut ne suffit pas : c\'est le rendement net après IR et PS qui détermine l\'intérêt réel de l\'investissement.',
    'Plusieurs pistes existent pour améliorer le rendement net : SCPI européennes, démembrement, assurance-vie, SCI à l\'IS, crédit. Aucune n\'est universelle. Chaque solution a ses avantages, ses limites et ses conditions de pertinence.',
    'L\'analyse doit être globale : fiscalité, horizon, besoin de revenus, risque, liquidité, frais, IFI, transmission. Un accompagnement professionnel est recommandé pour une analyse personnalisée.',
  ],
  faqItems: [
    {
      question: 'Les SCPI sont-elles adaptées à une TMI 41 % ?',
      answer: 'Oui, mais l\'analyse doit impérativement intégrer le rendement net fiscal. Le rendement brut peut être réduit de plus de 50 % par l\'IR et les PS. Les SCPI européennes, le démembrement, l\'assurance-vie ou la SCI à l\'IS sont des pistes à étudier selon la situation.',
    },
    {
      question: 'Pourquoi la fiscalité pèse-t-elle fortement à TMI 41 % ?',
      answer: 'À 41 %, le cumul IR + prélèvements sociaux peut dépasser 58 % des revenus fonciers bruts. Le rendement net est donc significativement réduit par rapport au rendement affiché.',
    },
    {
      question: 'Faut-il privilégier les SCPI européennes ?',
      answer: 'Les SCPI européennes peuvent améliorer le rendement net grâce au crédit d\'impôt et à une fiscalité allégée sur les prélèvements sociaux. C\'est une piste à approfondir, mais pas une recommandation automatique.',
    },
    {
      question: 'Le démembrement est-il pertinent à TMI 41 % ?',
      answer: 'Le démembrement (nue-propriété) peut être pertinent pour un investisseur sans besoin de revenus immédiats. Il neutralise la fiscalité pendant la période. L\'horizon et la décote doivent être analysés.',
    },
    {
      question: 'L\'assurance-vie peut-elle améliorer le cadre fiscal ?',
      answer: 'Oui, l\'assurance-vie permet de capitaliser les revenus sans imposition immédiate. La fiscalité n\'intervient qu\'en cas de rachat, avec un abattement après 8 ans. C\'est une piste pour les investisseurs sans besoin de revenus immédiats.',
    },
    {
      question: 'Une SCI à l\'IS est-elle une piste à TMI 41 % ?',
      answer: 'Une SCI à l\'IS peut permettre une capitalisation des revenus à l\'IS et un amortissement comptable. Ce montage ajoute une couche fiscale, comptable et juridique qui doit être justifiée par l\'objectif patrimonial.',
    },
    {
      question: 'Quel impact sur l\'IFI ?',
      answer: 'Les parts de SCPI détenues en direct sont généralement imposables à l\'IFI selon leur valeur IFI communiquée. En assurance-vie ou en nue-propriété, le traitement peut différer. À vérifier selon la situation.',
    },
    {
      question: 'Les SCPI à crédit sont-elles intéressantes à TMI 41 % ?',
      answer: 'L\'acquisition à crédit permet de déduire les intérêts d\'emprunt des revenus fonciers. L\'effet de levier peut être renforcé à TMI 41 % car la déduction est valorisée au taux marginal. Le cash-flow doit être analysé avec soin.',
    },
    {
      question: 'Faut-il comparer le direct et l\'assurance-vie à TMI 41 % ?',
      answer: 'Oui, c\'est même essentiel. Le direct est simple mais fiscalement lourd. L\'assurance-vie est plus complexe mais peut offrir un meilleur rendement net après impôt, surtout à horizon long. La simulation indicative est recommandée.',
    },
    {
      question: 'Comment MaximusSCPI analyse une TMI 41 % ?',
      answer: 'MaximusSCPI analyse le rendement brut et estime le rendement net fiscal selon la TMI, l\'origine des revenus et le mode de détention. L\'approche est pédagogique et ne constitue pas un conseil personnalisé au sens de la réglementation MIF2.',
    },
  ],
  comparateurCtaLabel: 'Comparer les SCPI selon leur rendement net estimé',
}
