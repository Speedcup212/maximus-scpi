import type { ScpiEducationalPageConfig } from './shared'

export const tmi45ScpiConfig: ScpiEducationalPageConfig = {
  path: '/scpi-tmi-45/',
  badge: 'Fiscalité SCPI',
  h1: 'SCPI avec TMI 45 % : analyse fiscale renforcée',
  heroSubtitle:
    'À 45 % de tranche marginale d\'imposition, l\'analyse fiscale est déterminante. Les revenus fonciers français en direct sont fiscalement très lourds. L\'étude des alternatives — SCPI européennes, démembrement, assurance-vie, SCI à l\'IS — devient prioritaire, sans présenter aucune solution comme automatiquement meilleure.',
  seoTitle: 'SCPI TMI 45 % : fiscalité, rendement net, Europe, démembrement et IFI',
  seoDescription:
    'Analyse détaillée des SCPI avec une TMI à 45 % : rendement net fiscal, impact des prélèvements sociaux, SCPI européennes, démembrement, assurance-vie, SCI à l\'IS et IFI. Cas pratiques et exemples chiffrés.',
  shortAnswerTitle: 'Pourquoi la TMI 45 % nécessite-t-elle une analyse renforcée ?',
  shortAnswer:
    'À 45 %, le cumul IR + prélèvements sociaux peut réduire le rendement net des SCPI françaises en direct de plus de 60 %. Une SCPI affichant 6 % de rendement brut peut ne laisser qu\'environ 2,3 % net après impôt pour un investisseur à TMI 45 %. Cela ne signifie pas qu\'il faut renoncer aux SCPI, mais que l\'analyse doit impérativement explorer les alternatives : SCPI européennes, nue-propriété, assurance-vie en capitalisation, SCI à l\'IS, ou recours au crédit.',
  keyMessage:
    'À TMI 45 %, une SCPI doit être analysée à travers le rendement net, la fiscalité, l\'horizon et la structure de détention. Le rendement brut seul n\'a pas de sens.',
  definitionParagraphs: [
    'La tranche marginale d\'imposition à 45 % est la plus élevée du barème progressif de l\'impôt sur le revenu. Elle concerne la fraction des revenus dépassant un certain seuil, qui peut être revalorisé chaque année.',
    'Les revenus fonciers issus de SCPI françaises sont imposés à cette TMI, auxquels s\'ajoutent les prélèvements sociaux. Le coût fiscal total peut dépasser 62 % des revenus bruts perçus.',
    'La fiscalité réduit fortement l\'attractivité d\'une SCPI française en direct à TMI 45 %. Cela ne signifie pas que les SCPI sont à exclure, mais que l\'analyse doit intégrer des paramètres plus larges : rendement net, origine des revenus, mode de détention, horizon, besoin de revenus, IFI et transmission.',
    'Les SCPI européennes peuvent améliorer significativement le rendement net grâce au crédit d\'impôt et à un traitement allégé des prélèvements sociaux, selon la convention fiscale applicable.',
    'Le démembrement (nue-propriété) peut être une piste pour les investisseurs sans besoin de revenus : aucun revenu imposable pendant la durée du démembrement, donc aucune fiscalité immédiate.',
    'L\'assurance-vie en gestion libre ou pilotée peut permettre de capitaliser les revenus des SCPI sans imposition immédiate, avec une fiscalité allégée en cas de rachat après 8 ans.',
    'La SCI à l\'IS peut être une solution pour capitaliser les revenus à un taux d\'IS potentiellement plus favorable que l\'IR, mais elle ajoute une couche de complexité et de coûts.',
    'Le recours au crédit permet de déduire les intérêts d\'emprunt des revenus fonciers, ce qui réduit la base imposable et peut améliorer le rendement net, sous réserve d\'un cash-flow positif.',
  ],
  tableTitle: 'Pistes à étudier selon la situation — TMI 45 %',
  tableRows: [
    {
      level: 'Besoin de revenus immédiats',
      advantage: 'SCPI européennes en direct ou assurance-vie avec rachats programmés.',
      vigilance: 'Le direct France est fiscalement très lourd à TMI 45 %. À comparer avec les alternatives disponibles.',
    },
    {
      level: 'Absence de besoin de revenus',
      advantage: 'Nue-propriété ou assurance-vie en capitalisation. Pas de revenus imposables immédiats.',
      vigilance: 'Horizon long nécessaire. Analyser la décote et la qualité de la SCPI sous-jacente.',
    },
    {
      level: 'Objectif transmission',
      advantage: 'Assurance-vie (abattement successoral) ou SCI à l\'IS (donation de parts).',
      vigilance: 'Complexité et coûts à mettre en balance. À étudier avec un professionnel.',
    },
    {
      level: 'Détention via société',
      advantage: 'SCI à l\'IS : capitalisation à l\'IS, amortissement comptable, rémunération différée.',
      vigilance: 'Double imposition lors de la distribution. Frais comptables, juridiques, de structure.',
    },
    {
      level: 'Volonté de diversification européenne',
      advantage: 'SCPI européennes : crédit d\'impôt, PS réduits, diversification géographique.',
      vigilance: 'Fiscalité variable selon le pays. Documentation à vérifier. Risques spécifiques (change, droit local).',
    },
  ],
  tableNote:
    'Ces pistes sont des orientations à approfondir selon la situation. Aucune n\'est universellement recommandable. À valider selon votre situation personnelle.',
  criteriaTitle: 'Critères à croiser avec la TMI 45 %',
  criteriaCards: [
    { title: 'Rendement net fiscal', text: 'À TMI 45 %, le rendement net d\'une SCPI française en direct peut être inférieur à 40 % du brut. L\'écart est à quantifier impérativement.' },
    { title: 'Besoin de revenus', text: 'Avec besoin de revenus, comparer direct, AV avec rachats et SCPI européennes. Sans besoin, capitalisation ou démembrement sont des pistes.' },
    { title: 'Horizon', text: 'Les solutions à fiscalité différée (AV, nue-propriété, SCI) nécessitent un horizon long (> 10 ans) pour amortir les coûts de structure.' },
    { title: 'Origine des revenus', text: 'Les revenus étrangers peuvent bénéficier d\'un traitement fiscal plus favorable. À étudier selon les pays et conventions.' },
    { title: 'Structure de détention', text: 'Le choix de l\'enveloppe (direct, AV, SCI, nue-propriété) a un impact direct sur le rendement net. Ce choix doit être justifié par les objectifs.' },
    { title: 'IFI', text: 'Les parts de SCPI en direct sont imposables à l\'IFI. Certaines enveloppes (AV, nue-propriété) peuvent modifier le traitement.' },
    { title: 'Transmission', text: 'L\'objectif de transmission peut orienter le choix : assurance-vie (abattement 152 500 € par bénéficiaire) ou SCI à l\'IS (donation de parts).' },
  ],
  commonErrors: [
    'Éviter systématiquement les SCPI par crainte de la fiscalité sans analyser les alternatives disponibles.',
    'Choisir une SCPI européenne sans vérifier la convention fiscale applicable et sans analyser les risques spécifiques.',
    'Opter pour une structure complexe (SCI à l\'IS) sans que l\'objectif patrimonial ne le justifie réellement.',
    'Sous-estimer les frais et contraintes des solutions alternatives : frais de l\'AV, comptabilité de la SCI, absence de liquidité en nue-propriété.',
    'Oublier que le rendement n\'est qu\'un critère parmi d\'autres : risque de perte en capital, liquidité limitée, horizon, diversification.',
    'Négliger l\'impact IFI dans l\'analyse patrimoniale globale.',
  ],
  practicalCases: [
    {
      title: 'TMI 11 % — Fiscalité légère',
      text: 'Rendement brut 6 %. Après IR (11 %) et PS, rendement net estimé : environ 4,3 %. L\'investisseur conserve 72 % du brut. L\'enjeu fiscal est mineur.',
    },
    {
      title: 'TMI 30 % — Impact moyen',
      text: 'Rendement brut 6 %. Après IR (30 %) et PS, rendement net estimé : environ 3,2 %. L\'arbitrage entre direct et AV commence à être pertinent.',
    },
    {
      title: 'TMI 41 % — Fiscalité élevée',
      text: 'Rendement brut 6 %. Après IR (41 %) et PS, rendement net estimé : environ 2,5 %. Les alternatives sont à étudier sérieusement.',
    },
    {
      title: 'TMI 45 % — Pression maximale',
      text: 'Rendement brut 6 %. Après IR (45 %) et PS, rendement net estimé : environ 2,3 %. L\'investisseur conserve moins de 40 % du brut. L\'analyse des alternatives est déterminante.',
    },
    {
      title: 'SCPI européenne à TMI 45 % — Comparaison',
      text: 'Même SCPI européenne rendement brut 6,5 %. Avec crédit d\'impôt et PS réduits, rendement net estimé : entre 4,5 % et 5,5 % selon la convention applicable. L\'écart avec le direct France peut être de 2 à 3 points.',
    },
    {
      title: 'Assurance-vie en capitalisation TMI 45 %',
      text: 'Investissement 100 000 € en SCPI via AV. Rendement brut 6 %. Revenus capitalisés sans imposition immédiate. Au bout de 10 ans, valeur estimée 179 000 € (hors frais). Fiscalité uniquement en cas de rachat.',
    },
  ],
  methodParagraphs: [
    'Identifier précisément sa TMI et vérifier les seuils applicables.',
    'Analyser le rendement brut et le retraiter de la fiscalité applicable (IR + PS).',
    'Déterminer l\'origine des revenus de la SCPI et les conventions fiscales concernées.',
    'Étudier les différentes enveloppes : direct, assurance-vie, nue-propriété, SCI à l\'IS, crédit.',
    'Intégrer l\'horizon, le besoin de revenus, l\'IFI et les objectifs de transmission.',
    'Comparer les rendements nets estimés de chaque option.',
    'Ne pas choisir une solution complexe sans que l\'objectif patrimonial ne la justifie.',
    'Consulter un professionnel pour valider l\'approche avant toute décision.',
  ],
  conclusionParagraphs: [
    'À TMI 45 %, l\'analyse fiscale est incontournable. Elle ne doit pas conduire à écarter systématiquement les SCPI, mais à les analyser avec les bons outils : rendement net, origine des revenus, mode de détention, horizon et objectifs.',
    'Les solutions alternatives (Europe, démembrement, AV, SCI) peuvent améliorer significativement le rendement net, mais leur pertinence dépend de chaque situation. Un accompagnement professionnel est fortement recommandé.',
    'MaximusSCPI met à disposition son comparateur pour analyser les indicateurs bruts et ses articles spécialisés pour approfondir chaque option.',
  ],
  faqItems: [
    {
      question: 'Les SCPI sont-elles fiscalement pénalisées avec une TMI 45 % ?',
      answer: 'Les SCPI françaises en direct sont fiscalement très lourdes à TMI 45 % en raison du cumul IR + PS. Cela ne signifie pas qu\'elles sont à exclure, mais l\'analyse du rendement net et des alternatives est indispensable.',
    },
    {
      question: 'Faut-il éviter les SCPI françaises ?',
      answer: 'Pas nécessairement. Tout dépend de l\'objectif, de l\'horizon et du besoin de revenus. Les SCPI françaises peuvent être pertinentes dans le cadre d\'une stratégie globale, malgré le poids fiscal.',
    },
    {
      question: 'Les SCPI européennes sont-elles plus pertinentes ?',
      answer: 'Elles peuvent améliorer le rendement net grâce au crédit d\'impôt et à une fiscalité allégée. C\'est une piste à approfondir, sous réserve de vérifier la convention fiscale applicable avec chaque pays.',
    },
    {
      question: 'Le démembrement est-il une solution à TMI 45 % ?',
      answer: 'Le démembrement (nue-propriété) peut être pertinent pour un investisseur sans besoin de revenus immédiats. Il neutralise la fiscalité pendant la durée du démembrement, ce qui est particulièrement intéressant à TMI 45 %.',
    },
    {
      question: 'L\'assurance-vie est-elle préférable ?',
      answer: 'L\'assurance-vie peut être intéressante pour capitaliser les revenus sans imposition immédiate. Après 8 ans, l\'abattement annuel sur les plus-values (4 600 €) réduit la fiscalité en cas de rachat.',
    },
    {
      question: 'Une SCI à l\'IS peut-elle être utile ?',
      answer: 'Une SCI à l\'IS peut permettre une capitalisation à l\'IS (taux potentiellement plus favorable) et un amortissement comptable. Ce montage est complexe et doit être justifié par un objectif patrimonial spécifique.',
    },
    {
      question: 'Quel impact sur l\'IFI ?',
      answer: 'Les parts de SCPI détenues en direct sont imposables à l\'IFI selon leur valeur IFI communiquée. En assurance-vie ou en nue-propriété, le traitement peut différer selon les modalités de détention.',
    },
    {
      question: 'Les SCPI à crédit sont-elles pertinentes à TMI 45 % ?',
      answer: 'Oui, car la déduction des intérêts d\'emprunt est valorisée à 45 %, ce qui renforce l\'effet de levier fiscal. Le cash-flow après impôt doit être analysé avec soin.',
    },
    {
      question: 'Faut-il comparer plusieurs scénarios avant de choisir ?',
      answer: 'Oui, c\'est même essentiel. La comparaison de plusieurs scénarios (direct France, direct Europe, AV, nue-propriété, SCI) permet d\'identifier la piste la plus adaptée à sa situation.',
    },
    {
      question: 'Comment MaximusSCPI analyse les projets à TMI 45 % ?',
      answer: 'MaximusSCPI analyse le rendement net fiscal selon la TMI, l\'origine des revenus et le mode de détention. L\'approche est pédagogique et ne constitue pas un conseil personnalisé au sens de la réglementation MIF2.',
    },
  ],
  comparateurCtaLabel: 'Comparer les SCPI selon leur rendement brut et net estimé',
}
