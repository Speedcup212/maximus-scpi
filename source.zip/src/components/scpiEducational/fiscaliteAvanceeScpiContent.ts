import type { ScpiEducationalPageConfig } from './shared'

export const fiscaliteAvanceeScpiConfig: ScpiEducationalPageConfig = {
  path: '/scpi-fiscalite/',
  badge: 'Guide pilier — Fiscalité',
  h1: 'Fiscalité SCPI : comprendre l\'imposition avant d\'investir',
  heroSubtitle:
    'La fiscalité des SCPI est un sujet central dans toute analyse patrimoniale : elle détermine le rendement réellement conservé par l\'investisseur après impôt et prélèvements sociaux. Ce guide pilier pose les bases et renvoie vers les articles spécialisés de chaque sous-thème.',
  seoTitle: 'Fiscalité SCPI : revenus fonciers, Europe, IFI et rendement net — Guide complet',
  seoDescription:
    'Guide complet de la fiscalité des SCPI : revenus fonciers, prélèvements sociaux, TMI, SCPI européennes, crédit d\'impôt, taux effectif, IFI, assurance-vie, démembrement, SCI à l\'IS. Exemples chiffrés et cas pratiques.',
  shortAnswerTitle: 'La fiscalité : clé de lecture du rendement réel d\'une SCPI',
  shortAnswer:
    'Le rendement affiché d\'une SCPI (TDVM ou taux de distribution sur valeur de reconstitution) est un rendement brut avant impôt personnel. Le rendement réellement conservé par l\'investisseur dépend de plusieurs facteurs : sa tranche marginale d\'imposition (TMI), les prélèvements sociaux, l\'origine française ou étrangère des revenus, le mode de détention (direct, assurance-vie, nue-propriété, SCI à l\'IS), et l\'impact éventuel de l\'IFI. Ignorer la fiscalité peut conduire à surévaluer de 30 % à 50 % le rendement attendu, selon la situation. Cette page détaille chaque mécanisme et oriente vers les articles spécialisés du cocon MaximusSCPI.',
  keyMessage:
    'Le taux de distribution affiché ne suffit jamais. La fiscalité peut transformer profondément la lecture du rendement d\'une SCPI. Chaque investisseur doit analyser sa situation avant de conclure.',
  definitionParagraphs: [
    'Les revenus distribués par une SCPI française sont généralement qualifiés de revenus fonciers. Ils sont soumis au barème progressif de l\'impôt sur le revenu (IR) selon la tranche marginale d\'imposition (TMI) de l\'investisseur, ainsi qu\'aux prélèvements sociaux au taux en vigueur. Le cumul des deux peut représenter une part significative des revenus bruts perçus.',
    'Les SCPI investies dans d\'autres pays européens génèrent des revenus immobiliers de source étrangère. Selon les conventions fiscales applicables, ces revenus peuvent bénéficier d\'un crédit d\'impôt ou d\'un mécanisme de taux effectif, ce qui modifie leur traitement fiscal par rapport aux revenus français. La société de gestion transmet chaque année une fiche fiscale détaillant la répartition par pays.',
    'Le mode de détention des parts influence également la fiscalité. En direct, les revenus sont imposés annuellement. En assurance-vie, ils peuvent être capitalisés sans imposition immédiate. En nue-propriété, l\'investisseur ne perçoit pas de revenus pendant la durée du démembrement. Via une SCI à l\'IS, les revenus sont imposés au niveau de la société. Chaque enveloppe a ses propres règles.',
    'Les SCPI peuvent également entrer dans l\'assiette de l\'Impôt sur la Fortune Immobilière (IFI). En principe, les parts détenues en direct sont imposables à l\'IFI à hauteur de leur valeur IFI communiquée par la société de gestion. En assurance-vie, le traitement est généralement différent.',
    'Certains dispositifs fiscaux spécifiques peuvent s\'appliquer : crédit d\'impôt pour revenus étrangers, taux effectif, déficit foncier en cas d\'acquisition à crédit, report à nouveau. Leur application dépend de la situation individuelle et de la réglementation en vigueur, qui peut évoluer.',
    'En pratique, la fiscalité d\'une SCPI ne se limite pas à l\'imposition des revenus courants. Elle inclut également la fiscalité de la revente (plus-value), la fiscalité de la transmission (succession, donation), et l\'impact sur les autres impôts du foyer (IFI, prélèvements sociaux).',
    'Les sociétés de gestion publient chaque année un Document d\'Information Clé (DIC) et un rapport annuel qui précisent la nature fiscale des revenus distribués. Ces documents sont essentiels pour comprendre la répartition géographique des actifs et les implications fiscales.',
    'Il est important de noter que la fiscalité applicable aux SCPI peut évoluer en fonction des lois de finances et des conventions fiscales internationales. Les informations présentées ici sont valables en l\'état actuel de la réglementation et ne constituent pas un conseil fiscal personnalisé.',
  ],
  tableTitle: 'Synthèse : mode de détention et fiscalité associée',
  tableRows: [
    {
      level: 'SCPI en direct (France)',
      advantage: 'Revenus fonciers imposables au barème IR + prélèvements sociaux. Déduction possible des intérêts d\'emprunt.',
      vigilance: 'Rendement net fortement impacté selon TMI. Déclaration fiscale annuelle obligatoire. Impact IFI.',
    },
    {
      level: 'SCPI européennes',
      advantage: 'Crédit d\'impôt ou taux effectif possible selon la convention fiscale. Prélèvements sociaux potentiellement réduits.',
      vigilance: 'Fiscalité variable selon le pays d\'investissement. Documentation fiscale à vérifier. Déclaration spécifique requise.',
    },
    {
      level: 'SCPI en assurance-vie',
      advantage: 'Capitalisation possible des revenus. Fiscalité allégée en cas de rachat après 8 ans. Transmission avantageuse.',
      vigilance: 'Frais du contrat d\'assurance-vie. Choix limité de SCPI en UC. Pas de déduction des intérêts d\'emprunt.',
    },
    {
      level: 'SCPI en nue-propriété',
      advantage: 'Absence de revenus imposables pendant la durée du démembrement. Fiscalité neutralisée temporairement.',
      vigilance: 'Pas de revenus disponibles. Horizon long nécessaire. Décote à analyser. L\'usufruitier déclare les revenus.',
    },
    {
      level: 'SCPI via SCI à l\'IS',
      advantage: 'Imposition à l\'IS. Possibilité de capitaliser les revenus. Amortissement comptable possible.',
      vigilance: 'Double imposition lors de la distribution (IS + impôt sur les dividendes). Frais comptables et juridiques. Complexité.',
    },
    {
      level: 'SCPI à crédit',
      advantage: 'Déduction des intérêts d\'emprunt des revenus fonciers. Effet de levier fiscal potentiel.',
      vigilance: 'Cash-flow à vérifier. Risque de taux. Endettement global à surveiller.',
    },
  ],
  tableNote:
    'Ce tableau présente les grands principes à titre pédagogique. La situation réelle dépend de la réglementation applicable et de la situation individuelle de chaque investisseur. À vérifier selon les textes en vigueur.',
  criteriaTitle: 'Critères à croiser avec la fiscalité',
  criteriaCards: [
    { title: 'TMI', text: 'La tranche marginale d\'imposition détermine le poids de l\'IR sur les revenus fonciers. Plus elle est élevée, plus le rendement net après impôt est réduit. Une TMI à 11 %, 30 %, 41 % ou 45 % change radicalement la lecture.' },
    { title: 'Origine des revenus', text: 'Revenus français ou étrangers : la fiscalité diffère selon les conventions fiscales et l\'origine géographique des actifs de la SCPI.' },
    { title: 'Mode de détention', text: 'Direct, assurance-vie, démembrement, SCI à l\'IS : chaque enveloppe a ses propres règles fiscales. Le choix du mode de détention est un levier important.' },
    { title: 'Prélèvements sociaux', text: 'Ils s\'ajoutent à l\'IR et peuvent représenter un coût supplémentaire significatif. Leur taux et leur application varient selon la nature des revenus (français ou étrangers).' },
    { title: 'Horizon d\'investissement', text: 'Un horizon long (> 10 ans) peut justifier des solutions à fiscalité différée : assurance-vie, nue-propriété, SCI à l\'IS. Un horizon court impose d\'intégrer pleinement la fiscalité immédiate.' },
    { title: 'Besoin de revenus', text: 'Avec besoin de revenus, le direct ou l\'assurance-vie avec rachats sont à étudier. Sans besoin, la capitalisation ou la nue-propriété sont des pistes.' },
    { title: 'IFI', text: 'Les parts de SCPI détenues en direct sont généralement intégrées à l\'assiette IFI. À vérifier selon le patrimoine global et le mode de détention.' },
    { title: 'Frais', text: 'Frais de souscription, de gestion, d\'enveloppe (AV, SCI) : ils réduisent le rendement brut et doivent être intégrés dans l\'analyse fiscale globale.' },
  ],
  commonErrors: [
    'Confondre rendement brut et rendement net fiscal : le rendement affiché inclut les frais de gestion mais pas la fiscalité personnelle de l\'investisseur.',
    'Oublier les prélèvements sociaux dans le calcul du rendement net : ils représentent un coût supplémentaire qui peut atteindre 17,5 % des revenus bruts.',
    'Croire que toutes les SCPI européennes sont fiscalement identiques : chaque pays a sa propre convention fiscale, son propre traitement du crédit d\'impôt et des prélèvements sociaux.',
    'Penser que l\'assurance-vie supprime toute fiscalité : les revenus capitalisés sont imposés en cas de rachat (sur la part de plus-value), avec un abattement après 8 ans.',
    'Ignorer l\'impact IFI : les parts de SCPI détenues en direct sont généralement imposables à l\'IFI, ce qui peut surprendre les investisseurs non avertis.',
    'Négliger l\'impact des frais de structure (SCI, assurance-vie) dans l\'analyse fiscale globale : des frais élevés peuvent annuler l\'avantage fiscal recherché.',
    'Confondre crédit d\'impôt et réduction d\'impôt : le crédit d\'impôt correspond à un impôt déjà payé à l\'étranger, il n\'est pas un avantage fiscal supplémentaire.',
    'Oublier que la fiscalité peut évoluer chaque année : les taux, seuils et règles sont susceptibles d\'être modifiés par la loi de finances.',
  ],
  practicalCases: [
    {
      title: 'TMI 11 % — Rendement net encore proche du brut',
      text: 'Un investisseur à TMI 11 % perçoit 5 000 € de revenus fonciers SCPI françaises. IR = 550 €. Prélèvements sociaux = 875 €. Total prélevé = 1 425 €. Rendement net conservé = 71,5 % du brut. La fiscalité reste modérée à cette TMI.',
    },
    {
      title: 'TMI 30 % — Impact fiscal moyen',
      text: 'Même situation avec TMI 30 %. IR = 1 500 €. PS = 875 €. Total = 2 375 €. Rendement net conservé = 52,5 % du brut. L\'écart avec le brut commence à être significatif.',
    },
    {
      title: 'TMI 41 % — Fiscalité élevée, alternatives à étudier',
      text: 'TMI 41 %, 5 000 € de revenus. IR = 2 050 €. PS = 875 €. Total = 2 925 €. Rendement net conservé = 41,5 % du brut. À ce niveau, les SCPI européennes, le démembrement ou l\'assurance-vie sont des pistes à approfondir.',
    },
    {
      title: 'TMI 45 % — Pression fiscale maximale',
      text: 'TMI 45 %, 5 000 € de revenus. IR = 2 250 €. PS = 875 €. Total = 3 125 €. Rendement net conservé = 37,5 % du brut. L\'analyse des alternatives (Europe, nue-propriété, AV, SCI à l\'IS) devient déterminante.',
    },
    {
      title: 'Absence de besoin de revenus — Capitalisation',
      text: 'Un investisseur sans besoin de revenus place 100 000 € en SCPI via une assurance-vie. Rendement brut 6 %. Les 6 000 € annuels sont capitalisés sans imposition immédiate. Au bout de 10 ans, la fiscalité ne s\'applique qu\'en cas de rachat.',
    },
    {
      title: 'Besoin de revenus complémentaires — Comparaison direct vs AV',
      text: 'Un investisseur à TMI 30 % a besoin de 500 €/mois de revenus complémentaires. En direct, le rendement net après IR + PS sera réduit. En assurance-vie, des rachats programmés permettent d\'optimiser le prélèvement fiscal.',
    },
  ],
  methodParagraphs: [
    'Analyser le rendement brut affiché (TDVM ou taux de distribution sur valeur de reconstitution).',
    'Identifier le mode de détention et son cadre fiscal spécifique.',
    'Déterminer sa tranche marginale d\'imposition (TMI) et l\'impact des prélèvements sociaux.',
    'Vérifier l\'origine des revenus de la SCPI : France, Europe, ou mixte.',
    'Calculer le rendement net fiscal estimé : rendement brut × (1 − TMI − taux PS).',
    'Intégrer l\'horizon d\'investissement et le besoin (ou non) de revenus.',
    'Vérifier l\'impact IFI en fonction du mode de détention et du patrimoine global.',
    'Comparer les différentes enveloppes possibles : direct, AV, nue-propriété, SCI à l\'IS.',
    'Ne pas conclure sur la seule base du rendement brut : croiser avec les critères de risque, liquidité, frais et diversification.',
    'Consulter un professionnel pour une analyse personnalisée avant toute décision d\'investissement.',
  ],
  conclusionParagraphs: [
    'La fiscalité est un élément clé de l\'analyse SCPI. Elle ne doit pas être ignorée, mais elle ne doit pas non plus être le seul critère de décision. Le rendement net, l\'horizon, le risque, la liquidité et les objectifs patrimoniaux doivent être analysés conjointement.',
    'Chaque situation est unique. Un investisseur à TMI 11 % n\'aura pas les mêmes préoccupations fiscales qu\'un investisseur à TMI 45 %. Un investisseur sans besoin de revenus n\'aura pas les mêmes priorités qu\'un investisseur recherchant un complément de revenus immédiat.',
    'MaximusSCPI met à disposition son comparateur interactif pour analyser les indicateurs bruts des SCPI, et ses articles spécialisés pour approfondir chaque volet fiscal : TMI, SCPI européennes, démembrement, assurance-vie, IFI, crédit d\'impôt, prélèvements sociaux, SCI à l\'IS.',
    'Il est recommandé d\'approfondir chaque sujet avec les pages dédiées de ce guide et, pour une analyse personnalisée, de consulter un conseiller en gestion de patrimoine.',
  ],
  faqItems: [
    {
      question: 'Comment sont fiscalisés les revenus de SCPI ?',
      answer: 'Les revenus distribués par une SCPI française sont généralement imposés comme des revenus fonciers : au barème progressif de l\'IR (selon la TMI) + prélèvements sociaux. Les revenus de SCPI étrangères peuvent bénéficier d\'un crédit d\'impôt ou d\'un taux effectif selon les conventions fiscales applicables.',
    },
    {
      question: 'Quelle différence entre SCPI françaises et européennes ?',
      answer: 'Les SCPI françaises génèrent des revenus fonciers français imposés au barème IR + PS. Les SCPI européennes génèrent des revenus immobiliers étrangers pouvant bénéficier d\'un crédit d\'impôt et, dans certains cas, de prélèvements sociaux réduits ou supprimés selon la convention fiscale.',
    },
    {
      question: 'Les SCPI sont-elles soumises aux prélèvements sociaux ?',
      answer: 'En règle générale, les revenus fonciers de SCPI françaises sont soumis aux prélèvements sociaux au taux en vigueur (CSG, CRDS, etc.). Pour les revenus étrangers, le traitement peut différer selon la convention fiscale applicable avec le pays d\'origine.',
    },
    {
      question: 'Les SCPI entrent-elles dans l\'IFI ?',
      answer: 'Oui, en principe. Les parts de SCPI détenues en direct sont généralement considérées comme des actifs immobiliers imposables à l\'IFI. La valeur à déclarer est celle communiquée par la société de gestion. En assurance-vie, le traitement est généralement différent.',
    },
    {
      question: 'L\'assurance-vie change-t-elle la fiscalité ?',
      answer: 'Oui. En assurance-vie, les revenus des SCPI sont capitalisés au sein du contrat. Ils ne sont imposés qu\'en cas de rachat, selon la part de plus-value et l\'ancienneté du contrat (abattement après 8 ans). Ce cadre peut être intéressant pour les investisseurs sans besoin de revenus immédiats.',
    },
    {
      question: 'Le démembrement permet-il de neutraliser les revenus ?',
      answer: 'En nue-propriété, l\'investisseur ne perçoit pas de revenus pendant la durée du démembrement. Il n\'a donc pas de revenus fonciers à déclarer. L\'usufruitier perçoit les revenus et supporte la fiscalité correspondante.',
    },
    {
      question: 'Une SCI à l\'IS peut-elle détenir des SCPI ?',
      answer: 'Oui, une SCI soumise à l\'IS peut détenir des parts de SCPI. Les revenus sont alors imposés à l\'IS, avec possibilité de capitalisation. La distribution aux associés est ensuite imposée dans leur catégorie de revenus. Ce montage ajoute une couche fiscale, comptable et juridique.',
    },
    {
      question: 'Qu\'est-ce que le crédit d\'impôt pour revenus étrangers de SCPI ?',
      answer: 'Le crédit d\'impôt permet d\'imputer l\'impôt payé à l\'étranger sur l\'impôt français dû au titre des mêmes revenus. Il évite la double imposition. Son montant et ses conditions d\'application dépendent de la convention fiscale avec chaque pays.',
    },
    {
      question: 'Qu\'est-ce que le taux effectif ?',
      answer: 'Le taux effectif est un mécanisme prévu par certaines conventions fiscales : le revenu étranger n\'est pas imposé en France mais est pris en compte pour calculer le taux d\'imposition applicable aux autres revenus du foyer.',
    },
    {
      question: 'Les SCPI à crédit sont-elles fiscalement avantageuses ?',
      answer: 'L\'acquisition de SCPI à crédit permet de déduire les intérêts d\'emprunt des revenus fonciers, sous réserve des conditions applicables. L\'effet de levier fiscal dépend du taux d\'emprunt, de la TMI et du montant des intérêts.',
    },
    {
      question: 'La fiscalité SCPI peut-elle évoluer ?',
      answer: 'Oui, la fiscalité applicable aux SCPI peut évoluer chaque année en fonction des lois de finances et des conventions fiscales internationales. Les taux, seuils et règles sont susceptibles d\'être modifiés.',
    },
    {
      question: 'Comment MaximusSCPI analyse la fiscalité SCPI ?',
      answer: 'MaximusSCPI analyse la fiscalité SCPI à travers plusieurs indicateurs : rendement brut et net estimé, origine des revenus, mode de détention, TMI, prélèvements sociaux, crédit d\'impôt, IFI et conventions fiscales. L\'objectif est pédagogique et ne constitue pas un conseil fiscal personnalisé au sens de la réglementation MIF2.',
    },
  ],
  comparateurCtaLabel: 'Comparer les SCPI selon leur fiscalité et leur rendement',
}
