import type { ScpiEducationalPageConfig } from './shared'

export const reportANouveauScpiConfig: ScpiEducationalPageConfig = {
  path: '/report-a-nouveau-scpi',
  badge: 'Réserve & distribution',
  h1: 'Report à nouveau SCPI : réserve utile ou faux confort ?',
  heroSubtitle:
    'Le report à nouveau (RAN) est une réserve comptable constituée par les bénéfices non distribués des exercices précédents. Il peut être utilisé pour lisser les distributions en période moins favorable, mais il ne remplace pas la qualité locative du patrimoine. Son analyse permet de distinguer une distribution soutenable d\'une distribution artificiellement maintenue.',
  seoTitle: 'Report à nouveau SCPI : définition, utilité, limites et analyse',
  seoDescription:
    'Analyse complète du report à nouveau (RAN) des SCPI : définition, réserve de distribution, lissage, lien avec le TOF et les revenus locatifs, RAN élevé ou faible, tendance, cas pratiques. Sources et indicateurs à surveiller.',
  shortAnswerTitle: 'Pourquoi le report à nouveau est-il important ?',
  shortAnswer:
    'Le report à nouveau (RAN) représente les bénéfices cumulés non distribués les années précédentes. Il constitue une réserve que la SCPI peut utiliser pour maintenir ou lisser ses distributions lorsque les revenus locatifs sont temporairement insuffisants. Un RAN élevé peut être rassurant sur la capacité de la SCPI à gérer les à-coups, mais il ne doit pas masquer une baisse durable du TOF ou de la qualité du patrimoine. Un RAN en baisse persistante, combiné à un TOF qui se dégrade, est un signal de vigilance. Un RAN faible n\'est pas inquiétant si les revenus locatifs sont stables et le TOF élevé.',
  keyMessage:
    'Le report à nouveau peut sécuriser temporairement une distribution, mais il ne remplace pas la qualité locative du patrimoine.',
  definitionParagraphs: [
    'Le report à nouveau (RAN) est un poste comptable qui figure au passif du bilan d\'une SCPI. Il correspond aux résultats des exercices précédents qui n\'ont pas été distribués aux associés ni affectés à d\'autres réserves.',
    'Une SCPI peut utiliser le RAN pour compléter les distributions d\'un exercice si les revenus locatifs sont insuffisants. Cela permet de lisser les versements et d\'éviter des variations brusques pour les associés.',
    'Le RAN est parfois exprimé en montant absolu ou en nombre de mois de distribution (exemple : RAN équivalent à 6 mois de distribution). Cette présentation permet de visualiser la capacité de la SCPI à maintenir son niveau de distribution en cas de baisse temporaire des loyers.',
    'Un RAN élevé n\'est pas toujours un signal positif. Il peut refléter une politique de distribution prudente, mais aussi une difficulté à distribuer faute de revenus locatifs suffisants, ou une capitalisation excessive qui aurait pu être reversée aux associés.',
    'Un RAN en baisse persistante est un signal de vigilance : les réserves sont utilisées pour maintenir les distributions, ce qui n\'est pas soutenable indéfiniment si les revenus locatifs ne se redressent pas. La tendance est plus importante que le niveau absolu.',
    'Le RAN doit être analysé avec le TOF, les revenus locatifs réels, le rendement, l\'endettement, les frais et la stratégie de distribution de la société de gestion. Une distribution maintenue artificiellement par le RAN ne reflète pas la santé réelle du patrimoine immobilier.',
    'Une SCPI récente (moins de 3 ans) peut avoir un RAN limité par construction. Cela n\'est pas nécessairement inquiétant si la stratégie de distribution est cohérente avec la montée en puissance du patrimoine.',
  ],
  tableTitle: 'Situation du RAN / Lecture possible / Vigilance / Indicateurs à croiser',
  tableRows: [
    {
      level: 'RAN élevé (> 6 mois de distribution)',
      advantage: 'Capacité de lisser les distributions. Politique prudente possible. Réserve confortable en cas de baisse temporaire.',
      vigilance: 'Vérifier la tendance : le RAN se constitue-t-il ou se consume-t-il ? Un RAN élevé peut aussi signaler une sous-distribution chronique.',
    },
    {
      level: 'RAN modéré (3 à 6 mois)',
      advantage: 'Réserve suffisante pour gérer des à-coups modérés. Politique de distribution équilibrée.',
      vigilance: 'Surveiller l\'évolution sur plusieurs exercices. Croiser avec la stabilité du TOF et des revenus locatifs.',
    },
    {
      level: 'RAN faible (< 3 mois)',
      advantage: 'Politique de distribution dynamique. Les revenus sont reversés aux associés.',
      vigilance: 'Moins de capacité à lisser les chocs. En cas de baisse du TOF, les distributions pourraient baisser rapidement.',
    },
    {
      level: 'RAN en baisse persistante',
      advantage: 'Peut refléter une volonté de maintenir les distributions malgré une baisse des loyers.',
      vigilance: 'Signal de vigilance si la baisse dure plus de 2-3 exercices. La distribution n\'est pas soutenable sans redressement des revenus locatifs.',
    },
    {
      level: 'RAN stable et TOF stable',
      advantage: 'Cohérence entre revenus locatifs et distribution. Lecture rassurante sur la solidité du modèle.',
      vigilance: 'Continuer à surveiller le TOF et les revenus locatifs. Un RAN stable n\'est pas une garantie de performance future.',
    },
    {
      level: 'SCPI récente (< 3 ans)',
      advantage: 'RAN limité par construction. Pas d\'historique de lissage significatif.',
      vigilance: 'Analyser la solidité locative et la stratégie de distribution dès les premières années. Le RAN se constituera avec le temps.',
    },
  ],
  tableNote:
    'Ces repères sont indicatifs. Le RAN doit toujours être analysé en contexte, avec les revenus locatifs réels, le TOF et les perspectives de la SCPI.',
  criteriaTitle: 'Critères à croiser avec le report à nouveau',
  criteriaCards: [
    { title: 'TOF', text: 'Un TOF élevé et stable génère des revenus locatifs suffisants, réduisant le besoin de puiser dans le RAN.' },
    { title: 'Rendement (TDVM)', text: 'Un rendement maintenu malgré un RAN en baisse peut signaler une politique de distribution non soutenable.' },
    { title: 'Revenus locatifs', text: 'Analyser l\'évolution des loyers perçus. Si les revenus baissent mais que les distributions restent stables, le RAN compense.' },
    { title: 'Endettement', text: 'Une SCPI endettée a moins de flexibilité pour reconstituer son RAN si les revenus baissent et que la dette doit être servie.' },
    { title: 'Collecte nette', text: 'Une collecte positive peut aider à reconstituer les réserves. Une collecte négative peut au contraire peser sur le RAN.' },
    { title: 'Capitalisation', text: 'La taille de la SCPI influence sa capacité à générer des réserves et à lisser les distributions dans le temps.' },
    { title: 'Stratégie de distribution', text: 'Certaines sociétés de gestion privilégient la régularité des distributions (RAN important), d\'autres reversent l\'intégralité des revenus (RAN faible).' },
    { title: 'Historique', text: 'L\'analyse sur 3 à 5 exercices est plus parlante qu\'une photographie ponctuelle du RAN.' },
  ],
  commonErrors: [
    'Considérer qu\'un RAN élevé est toujours un signe de bonne santé de la SCPI.',
    'Ignorer la tendance du RAN : un RAN qui se dégrade est plus inquiétant qu\'un RAN bas stable.',
    'Croire que le RAN garantit les distributions futures (il ne fait que les lisser temporairement).',
    'Ne pas croiser le RAN avec le TOF et les revenus locatifs réels.',
    'Confondre RAN et trésorerie disponible (le RAN est un poste comptable, pas un compte en banque).',
    'Oublier que le RAN peut masquer temporairement une baisse structurelle des revenus locatifs.',
    'Comparer des RAN entre SCPI sans tenir compte de leur taille et de leur politique de distribution.',
  ],
  practicalCases: [
    {
      title: 'SCPI A — RAN élevé mais TOF en baisse',
      text: 'Une SCPI affiche un RAN équivalent à 8 mois de distribution. Cependant, le TOF est passé de 96 % à 85 % en deux ans. Les distributions sont maintenues grâce au RAN, mais la tendance locative est préoccupante. Simulation pédagogique : le RAN retarde l\'impact d\'une baisse durable du TOF, il ne le supprime pas.',
    },
    {
      title: 'SCPI B — RAN faible mais patrimoine solide',
      text: 'Une SCPI a un RAN équivalent à 2 mois de distribution et un TOF stable à 97 %. Les distributions sont régulières et soutenues par les revenus locatifs réels. Le faible RAN n\'est pas inquiétant si la qualité locative est maintenue.',
    },
    {
      title: 'SCPI C — RAN en baisse après acquisition',
      text: 'Une SCPI a utilisé une partie de son RAN pour financer une acquisition stratégique. La baisse du RAN est ponctuelle et documentée dans le rapport annuel. Le TOF reste élevé. Simulation pédagogique : le RAN peut baisser pour des raisons positives, à condition d\'être expliqué.',
    },
    {
      title: 'Rendement maintenu malgré baisse des loyers',
      text: 'Une SCPI voit ses revenus locatifs baisser de 10 % sur un an en raison de vacances locatives. Les distributions restent stables grâce au RAN. La troisième année, si le TOF ne se redresse pas, les distributions devront être réduites. Simulation pédagogique : le RAN n\'est pas une solution magique, c\'est un amortisseur temporaire.',
    },
    {
      title: 'SCPI récente — RAN encore limité',
      text: 'Une SCPI lancée depuis 2 ans a un RAN limité car les bénéfices des premières années ont été en priorité distribués pour attirer les investisseurs. Le RAN se constituera progressivement si la politique de distribution le permet. Simulation pédagogique : un RAN faible n\'est pas un défaut rédhibitoire pour une SCPI en phase de croissance.',
    },
  ],
  methodParagraphs: [
    'MaximusSCPI intègre le report à nouveau comme un indicateur de lecture de la solidité des distributions, sans le présenter comme une garantie.',
    'La première étape consiste à identifier le RAN dans le rapport annuel ou le bulletin trimestriel. Il est souvent exprimé en montant ou en mois de distribution.',
    'La deuxième étape analyse la tendance : le RAN augmente-t-il, diminue-t-il ou reste-t-il stable sur plusieurs exercices ? La tendance est plus importante que le niveau absolu.',
    'La troisième étape croise le RAN avec le TOF et les revenus locatifs pour vérifier si la politique de distribution est soutenable.',
    'La quatrième étape vérifie la stratégie de distribution de la société de gestion : certains gestionnaires préfèrent lisser (RAN plus élevé), d\'autres reverser l\'intégralité des revenus (RAN plus faible).',
    'MaximusSCPI ne constitue pas une recommandation personnalisée. Un échange avec le Cabinet Eric Bellaiche permet d\'affiner l\'analyse de la solidité des distributions.',
  ],
  conclusionParagraphs: [
    'Le report à nouveau est un indicateur utile pour évaluer la capacité d\'une SCPI à gérer les à-coups de distribution. Il ne remplace pas l\'analyse du TOF, des revenus locatifs et de la stratégie de gestion. Un RAN élevé avec un TOF en baisse mérite vigilance ; un RAN faible avec un bon TOF n\'est pas inquiétant.',
    'Sources et points à vérifier : rapport annuel, bulletin trimestriel, fiche ASPIM de la SCPI, communication de la société de gestion.',
    'Utilisez le comparateur MaximusSCPI pour visualiser les indicateurs, puis validez votre analyse avec un conseiller pour une approche personnalisée.',
  ],
  faqItems: [
    {
      question: 'Qu\'est-ce que le report à nouveau d\'une SCPI ?',
      answer: 'C\'est le cumul des bénéfices non distribués des exercices précédents. Il constitue une réserve comptable que la SCPI peut utiliser pour lisser ses distributions.',
    },
    {
      question: 'À quoi sert le RAN ?',
      answer: 'Il permet de maintenir ou de compléter les distributions lorsque les revenus locatifs sont temporairement insuffisants. C\'est un outil de lissage temporaire, pas une garantie.',
    },
    {
      question: 'Un RAN élevé est-il toujours positif ?',
      answer: 'Pas nécessairement. Il peut refléter une politique prudente, mais aussi une difficulté à distribuer ou une capitalisation excessive. La tendance et le contexte comptent.',
    },
    {
      question: 'Un RAN faible est-il inquiétant ?',
      answer: 'Pas si le TOF est élevé et les revenus locatifs stables. En revanche, un RAN faible avec un TOF en baisse est un signal de vigilance.',
    },
    {
      question: 'Le RAN garantit-il les distributions futures ?',
      answer: 'Non. Il peut temporairement lisser les distributions, mais il ne remplace pas une dégradation durable du TOF ou des revenus locatifs.',
    },
    {
      question: 'Où trouver le niveau de RAN d\'une SCPI ?',
      answer: 'Dans le rapport annuel, le bulletin trimestriel et parfois la fiche ASPIM. Le RAN est mentionné dans les états financiers.',
    },
    {
      question: 'Comment comparer le RAN entre SCPI ?',
      answer: 'Le RAN exprimé en mois de distribution est plus parlant que le montant absolu, car il est rapporté au niveau de distribution de chaque SCPI.',
    },
    {
      question: 'Qu\'est-ce qu\'un bon niveau de RAN ?',
      answer: 'Il n\'existe pas de niveau idéal universel. L\'essentiel est que la tendance soit stable ou en légère progression, et que le TOF soit solide.',
    },
    {
      question: 'Un RAN en baisse signifie-t-il que la SCPI est en difficulté ?',
      answer: 'Pas forcément, s\'il est compensé par des revenus locatifs stables ou en hausse. En revanche, s\'il baisse ET que le TOF se dégrade, c\'est un signal de difficulté potentielle.',
    },
    {
      question: 'Les SCPI récentes ont-elles un RAN ?',
      answer: 'Leur RAN peut être limité par construction. Ce n\'est pas inquiétant si la stratégie de distribution est cohérente et que le TOF progresse.',
    },
    {
      question: 'Comment MaximusSCPI utilise le RAN ?',
      answer: 'Le RAN est intégré comme un indicateur de lecture dans les contenus pédagogiques. Son analyse croisée avec le TOF et les revenus locatifs est encouragée.',
    },
  ],
  comparateurCtaLabel: 'Comparer le report à nouveau avec le TOF et le rendement',
}
