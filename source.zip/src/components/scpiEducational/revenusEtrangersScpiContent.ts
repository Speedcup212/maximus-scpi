import type { ScpiEducationalPageConfig } from './shared'

export const revenusEtrangersScpiConfig: ScpiEducationalPageConfig = {
  path: '/scpi-revenus-etrangers/',
  badge: 'Fiscalité SCPI',
  h1: 'Revenus étrangers de SCPI : comprendre la fiscalité européenne',
  heroSubtitle:
    'Les SCPI investies en Europe génèrent des revenus immobiliers de source étrangère. Leur traitement fiscal diffère des revenus français : crédit d\'impôt, taux effectif, prélèvements sociaux réduits. L\'analyse dépend du pays, de la convention fiscale et de la situation de l\'investisseur.',
  seoTitle: 'Revenus étrangers SCPI : fiscalité, crédit d\'impôt, taux effectif et conventions',
  seoDescription:
    'Analyse complète de la fiscalité des revenus étrangers de SCPI : crédit d\'impôt, taux effectif, conventions fiscales par pays, prélèvements sociaux, rendement net, déclaration et cas pratiques.',
  shortAnswerTitle: 'Pourquoi les revenus étrangers changent-ils l\'analyse fiscale ?',
  shortAnswer:
    'Les SCPI investies dans des pays européens (Allemagne, Pays-Bas, Espagne, Italie, etc.) perçoivent des loyers de source étrangère. Selon les conventions fiscales applicables, ces revenus peuvent bénéficier d\'un crédit d\'impôt (l\'impôt payé à l\'étranger est déduit de l\'IR français) ou d\'un mécanisme de taux effectif (le revenu n\'est pas imposé en France mais augmente le taux d\'imposition global). Dans certains cas, les prélèvements sociaux peuvent être réduits ou supprimés. La fiscalité dépend donc du pays d\'investissement, de la convention fiscale concernée et de la situation individuelle de l\'investisseur. La société de gestion transmet chaque année une fiche fiscale détaillée.',
  keyMessage:
    'Les revenus étrangers de SCPI peuvent améliorer la lecture fiscale, mais leur traitement dépend du pays, de la convention fiscale et de la situation de l\'investisseur. Aucune généralisation n\'est possible.',
  definitionParagraphs: [
    'Un revenu immobilier de source étrangère est un revenu provenant d\'un bien situé hors de France. Les SCPI européennes génèrent ce type de revenus lorsqu\'elles investissent dans des actifs immobiliers situés dans d\'autres pays de l\'Union européenne.',
    'Pour éviter la double imposition, la France a signé des conventions fiscales avec la plupart des pays européens. Ces conventions prévoient le traitement fiscal applicable aux revenus immobiliers étrangers : généralement un crédit d\'impôt égal à l\'impôt payé à l\'étranger, ou un taux effectif.',
    'Le crédit d\'impôt permet d\'imputer l\'impôt acquitté dans le pays d\'origine sur l\'impôt français dû au titre des mêmes revenus. Il est plafonné à l\'impôt français correspondant. Si le crédit dépasse l\'impôt dû, l\'excédent n\'est généralement pas remboursé.',
    'Le taux effectif est un mécanisme différent : le revenu étranger n\'est pas imposé en France, mais il est pris en compte pour déterminer le taux d\'imposition moyen applicable aux autres revenus du foyer. Cela peut augmenter l\'impôt sur les revenus français.',
    'Dans certains cas, les revenus étrangers de SCPI peuvent échapper partiellement ou totalement aux prélèvements sociaux français, selon la convention fiscale applicable. Ce point est à vérifier pays par pays.',
    'La société de gestion transmet une fiche fiscale annuelle indiquant la répartition par pays des revenus, le montant des crédits d\'impôt et le mécanisme applicable (crédit d\'impôt ou taux effectif). Ce document est essentiel pour la déclaration.',
    'La diversification européenne présente un intérêt patrimonial qui dépasse la seule fiscalité : répartition du risque immobilier sur plusieurs pays, accès à des marchés locatifs différents, mutualisation des cycles économiques.',
  ],
  tableTitle: 'Mécanismes fiscaux des revenus étrangers de SCPI',
  tableRows: [
    {
      level: 'Crédit d\'impôt',
      advantage: 'Évite la double imposition. L\'impôt payé à l\'étranger s\'impute sur l\'IR français.',
      vigilance: 'Plafonné à l\'impôt français correspondant. Non remboursable si excédent. Déclaration spécifique.',
    },
    {
      level: 'Taux effectif',
      advantage: 'Le revenu étranger n\'est pas imposé en France. Peut être favorable selon les cas.',
      vigilance: 'Augmente le taux d\'imposition applicable aux autres revenus. Impact indirect à ne pas négliger.',
    },
    {
      level: 'Prélèvements sociaux',
      advantage: 'Dans certains cas, exonération de PS ou taux réduit sur les revenus étrangers.',
      vigilance: 'À vérifier selon la convention fiscale. Pas d\'exonération automatique.',
    },
    {
      level: 'Déclaration fiscale',
      advantage: 'La société de gestion fournit une fiche fiscale détaillée par pays.',
      vigilance: 'Déclaration spécifique à effectuer. Une erreur de case peut avoir des conséquences.',
    },
    {
      level: 'Rendement net',
      advantage: 'Le crédit d\'impôt peut améliorer le rendement net fiscal par rapport à une SCPI française.',
      vigilance: 'L\'écart dépend de la convention, du pays et de la TMI. À analyser au cas par cas.',
    },
    {
      level: 'Diversification patrimoniale',
      advantage: 'Répartition du risque immobilier sur plusieurs pays. Accès à des cycles économiques différents.',
      vigilance: 'Risque pays, risque de change, différences de droit immobilier et fiscal selon les juridictions.',
    },
  ],
  tableNote:
    'Les mécanismes présentés dépendent des conventions fiscales en vigueur, qui peuvent évoluer. À vérifier selon la réglementation applicable.',
  criteriaTitle: 'Critères à croiser avec les revenus étrangers',
  criteriaCards: [
    { title: 'Pays d\'investissement', text: 'Chaque pays a sa propre convention fiscale. Le crédit d\'impôt et le traitement des PS varient. Les principaux pays d\'investissement des SCPI européennes sont l\'Allemagne, les Pays-Bas, l\'Espagne, l\'Italie, la Belgique et le Luxembourg.' },
    { title: 'Crédit d\'impôt', text: 'Montant, plafonnement, conditions d\'application. À vérifier sur la fiche fiscale de la société de gestion.' },
    { title: 'Taux effectif', text: 'Mécanisme applicable selon la convention. Peut impacter l\'imposition des autres revenus du foyer.' },
    { title: 'Prélèvements sociaux', text: 'Exonération possible selon les pays et conventions. À vérifier au cas par cas.' },
    { title: 'Documentation fiscale', text: 'La fiche fiscale annuelle est le document de référence. À conserver impérativement pour la déclaration.' },
    { title: 'Rendement net', text: 'Comparer le rendement net après fiscalité entre SCPI françaises et étrangères selon sa propre TMI.' },
    { title: 'Risque de change', text: 'Certaines SCPI européennes investissent dans des pays hors zone euro. Le risque de change doit être intégré dans l\'analyse.' },
  ],
  commonErrors: [
    'Croire que toutes les SCPI européennes ont la même fiscalité : chaque pays est différent, chaque convention est spécifique.',
    'Confondre crédit d\'impôt et réduction d\'impôt : le crédit d\'impôt correspond à un impôt déjà payé à l\'étranger, ce n\'est pas un avantage fiscal supplémentaire.',
    'Oublier la déclaration spécifique des revenus étrangers, ce qui peut entraîner des redressements.',
    'Penser que les prélèvements sociaux sont toujours supprimés sur les revenus étrangers : cela dépend de la convention.',
    'Choisir une SCPI européenne uniquement pour la fiscalité, sans analyser les risques (change, droit local, liquidité).',
    'Négliger la fiche fiscale de la société de gestion, qui est pourtant le document clé pour la déclaration.',
  ],
  practicalCases: [
    {
      title: 'TMI 11 % — Crédit d\'impôt Allemagne',
      text: 'Un investisseur TMI 11 % perçoit 4 000 € de revenus d\'une SCPI allemande. L\'Allemagne prélève 600 €. Crédit d\'impôt : 600 €. IR français avant crédit : 440 €. Après crédit d\'impôt : 0 €. L\'excédent de 160 € n\'est pas remboursé.',
    },
    {
      title: 'TMI 30 % — Crédit d\'impôt partiel',
      text: 'Même SCPI, TMI 30 %. IR avant crédit : 1 200 €. Crédit d\'impôt : 600 €. IR dû : 600 €. La fiscalité allégée améliore le rendement net.',
    },
    {
      title: 'TMI 41 % — Taux effectif Pays-Bas',
      text: 'Un investisseur TMI 41 % perçoit 3 000 € de revenus d\'une SCPI néerlandaise. La convention prévoit un taux effectif : les 3 000 € ne sont pas imposés mais augmentent le taux d\'imposition global. Impact à calculer selon les autres revenus.',
    },
    {
      title: 'TMI 45 % — Comparaison France / Europe',
      text: 'SCPI française : rendement brut 6 %, rendement net après IR+PS estimé à 2,3 %. SCPI européenne : rendement brut 6,5 %, rendement net après crédit d\'impôt et PS réduits estimé entre 4,5 % et 5,5 %. L\'écart potentiel est significatif.',
    },
    {
      title: 'Absence de besoin de revenus — Diversification européenne',
      text: 'Un investisseur sans besoin de revenus choisit une SCPI diversifiée Europe pour la diversification patrimoniale et le potentiel fiscal à long terme. Les revenus sont capitalisés ou réinvestis.',
    },
  ],
  methodParagraphs: [
    'Identifier les pays d\'investissement de la SCPI via la fiche fiscale et le rapport annuel.',
    'Vérifier les conventions fiscales applicables avec chaque pays.',
    'Déterminer le mécanisme applicable : crédit d\'impôt ou taux effectif.',
    'Analyser l\'impact des prélèvements sociaux selon la convention.',
    'Calculer le rendement net fiscal après prise en compte du crédit d\'impôt ou du taux effectif.',
    'Comparer avec une SCPI française de rendement équivalent.',
    'Intégrer les risques spécifiques : change, droit local, liquidité.',
    'Ne pas choisir une SCPI européenne uniquement sur un critère fiscal.',
  ],
  conclusionParagraphs: [
    'Les revenus étrangers de SCPI peuvent offrir un traitement fiscal plus favorable, mais leur analyse est plus complexe que celle des SCPI françaises. Chaque pays a ses propres règles et conventions.',
    'L\'intérêt des SCPI européennes dépasse la seule fiscalité : diversification géographique, accès à des marchés immobiliers différents, mutualisation des risques. L\'analyse doit être globale.',
    'La fiche fiscale de la société de gestion est le document de référence. Les modalités exactes de déclaration doivent être confirmées au moment de la déclaration selon la réglementation en vigueur.',
  ],
  faqItems: [
    {
      question: 'Qu\'est-ce qu\'un revenu étranger de SCPI ?',
      answer: 'Ce sont les loyers perçus par une SCPI sur des actifs immobiliers situés hors de France. Ces revenus sont généralement imposables dans le pays d\'origine ET en France, avec un mécanisme conventionnel pour éviter la double imposition.',
    },
    {
      question: 'Comment sont imposés les revenus étrangers ?',
      answer: 'Selon la convention fiscale applicable : crédit d\'impôt (l\'impôt étranger est imputé sur l\'IR français) ou taux effectif (le revenu n\'est pas imposé en France mais augmente le taux d\'imposition global).',
    },
    {
      question: 'Qu\'est-ce que le crédit d\'impôt ?',
      answer: 'Le crédit d\'impôt permet d\'imputer l\'impôt payé à l\'étranger sur l\'impôt français dû au titre des mêmes revenus. Il évite la double imposition mais ne rembourse pas l\'excédent éventuel.',
    },
    {
      question: 'Qu\'est-ce que le taux effectif ?',
      answer: 'Le taux effectif est un mécanisme où le revenu étranger n\'est pas imposé en France mais est pris en compte pour déterminer le taux d\'imposition applicable aux autres revenus. Cela peut augmenter l\'impôt sur les autres revenus.',
    },
    {
      question: 'Les prélèvements sociaux s\'appliquent-ils toujours ?',
      answer: 'Pas nécessairement. Selon les conventions fiscales, certains revenus étrangers peuvent être exonérés de prélèvements sociaux ou soumis à un taux réduit. À vérifier au cas par cas.',
    },
    {
      question: 'Les SCPI européennes sont-elles fiscalement meilleures ?',
      answer: 'Elles peuvent améliorer le rendement net fiscal dans certaines situations, mais ce n\'est pas automatique. Tout dépend de la convention fiscale, du pays, de la TMI et des autres revenus du foyer.',
    },
    {
      question: 'Comment déclarer les revenus étrangers ?',
      answer: 'Les revenus étrangers font l\'objet d\'une déclaration spécifique. La société de gestion transmet une fiche fiscale annuelle détaillée par pays. Les modalités exactes doivent être confirmées au moment de la déclaration.',
    },
    {
      question: 'Quels sont les risques des SCPI européennes ?',
      answer: 'Outre la fiscalité, les principaux risques sont : le risque de change (hors zone euro), le risque pays, les différences de droit immobilier et fiscal, et une liquidité parfois plus limitée.',
    },
    {
      question: 'Faut-il privilégier les SCPI avec revenus étrangers ?',
      answer: 'Cela dépend de la situation. Les SCPI européennes peuvent être une piste intéressante pour la diversification et la fiscalité, mais elles ne doivent pas être choisies uniquement sur ces critères.',
    },
    {
      question: 'Comment MaximusSCPI analyse les revenus étrangers ?',
      answer: 'MaximusSCPI analyse les revenus étrangers à travers leur origine géographique, les conventions fiscales, le crédit d\'impôt, le taux effectif et l\'impact sur le rendement net. L\'approche est pédagogique et ne constitue pas un conseil fiscal personnalisé.',
    },
  ],
  comparateurCtaLabel: 'Comparer les SCPI selon leur exposition géographique',
}
