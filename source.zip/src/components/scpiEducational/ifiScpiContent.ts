import type { ScpiEducationalPageConfig } from './shared'

export const ifiScpiConfig: ScpiEducationalPageConfig = {
  path: '/scpi-ifi/',
  badge: 'Fiscalité SCPI',
  h1: 'SCPI et IFI : faut-il déclarer ses parts ?',
  heroSubtitle:
    'Les parts de SCPI peuvent entrer dans l\'assiette de l\'Impôt sur la Fortune Immobilière (IFI) selon leur mode de détention et la fraction immobilière du patrimoine. Leur traitement varie selon que les parts sont détenues en direct, en assurance-vie, en nue-propriété ou via une SCI. Cette page explique les grands principes sans se substituer à un conseil fiscal personnalisé.',
  seoTitle: 'SCPI IFI : déclaration, valorisation, mode de détention et dette',
  seoDescription:
    'Guide complet sur le traitement des SCPI à l\'IFI : parts imposables, valeur IFI, détention en direct, assurance-vie, nue-propriété, usufruit, SCI, dette déductible. Cas pratiques et points de vigilance.',
  shortAnswerTitle: 'Les SCPI sont-elles imposables à l\'IFI ?',
  shortAnswer:
    'En principe, les parts de SCPI détenues en direct sont considérées comme des actifs immobiliers imposables à l\'IFI, à hauteur de leur valeur IFI communiquée par la société de gestion. En assurance-vie, les parts de SCPI détenues en unités de compte ne sont généralement pas imposables à l\'IFI. En démembrement, le traitement diffère entre le nu-propriétaire et l\'usufruitier. Les dettes d\'acquisition peuvent être déductibles sous conditions. La valeur IFI est communiquée chaque année par la société de gestion et peut différer du prix de souscription.',
  keyMessage:
    'Les SCPI peuvent avoir un impact IFI. La valeur à retenir dépend du mode de détention, des informations transmises par la société de gestion et de la situation patrimoniale de l\'investisseur.',
  definitionParagraphs: [
    'L\'Impôt sur la Fortune Immobilière (IFI) est un impôt annuel qui frappe le patrimoine immobilier net des personnes physiques dont la valeur dépasse un certain seuil. En 2026, le seuil net imposable est à vérifier selon la réglementation en vigueur.',
    'Les parts de SCPI sont généralement considérées comme des actifs immobiliers pour l\'IFI, car elles représentent une fraction d\'un patrimoine composé majoritairement d\'immeubles. La valeur à déclarer est la valeur IFI communiquée par la société de gestion.',
    'La société de gestion transmet chaque année une valeur IFI par part, qui peut différer du prix de souscription ou de la valeur de reconstitution. Cette valeur tient compte de la quote-part immobilière du patrimoine de la SCPI.',
    'En assurance-vie, les parts de SCPI détenues en unités de compte (UC) ne sont généralement pas imposables à l\'IFI, car elles sont considérées comme des actifs financiers au sein du contrat. Ce principe mérite d\'être vérifié selon les textes applicables au moment de la déclaration.',
    'En démembrement, le traitement IFI diffère : en principe, l\'usufruitier déclare la valeur des parts à l\'IFI, tandis que le nu-propriétaire ne déclare pas. En cas de démembrement temporaire, les règles peuvent varier selon la durée.',
    'Les dettes contractées pour l\'acquisition de parts de SCPI peuvent, sous conditions, être déductibles du patrimoine IFI. Les modalités de déduction dépendent de la nature de la dette, de son affectation et des règles applicables.',
    'En cas de détention via une SCI, les parts de SCPI détenues par la société sont imposables à l\'IFI au niveau des associés, selon leur quote-part et dans le cadre des règles de transparence.',
  ],
  tableTitle: 'Traitement IFI selon le mode de détention',
  tableRows: [
    {
      level: 'Détention en direct',
      advantage: 'Valeur IFI communiquée par la société de gestion. Simplicité de déclaration.',
      vigilance: 'Généralement imposable à l\'IFI. Valeur à déclarer chaque année. Peut augmenter l\'assiette IFI.',
    },
    {
      level: 'Assurance-vie (UC)',
      advantage: 'Généralement non imposable à l\'IFI (actif financier du contrat).',
      vigilance: 'Principe à vérifier selon la réglementation applicable au moment de la déclaration.',
    },
    {
      level: 'Nue-propriété',
      advantage: 'Le nu-propriétaire ne déclare pas à l\'IFI (principe général).',
      vigilance: 'L\'usufruitier déclare en principe la valeur. Règles à vérifier selon le type de démembrement.',
    },
    {
      level: 'Usufruit',
      advantage: 'L\'usufruitier déclare la valeur en principe.',
      vigilance: 'Valorisation à vérifier. Règles spécifiques selon la durée.',
    },
    {
      level: 'SCI',
      advantage: 'Les parts de SCPI sont imposables au niveau des associés selon leur quote-part.',
      vigilance: 'Valeur IFI à répartir. Déclaration en transparence. À vérifier selon les règles applicables.',
    },
    {
      level: 'Crédit',
      advantage: 'La dette d\'acquisition peut être déductible sous conditions.',
      vigilance: 'Conditions de déductibilité à vérifier. Affectation de la dette à justifier.',
    },
  ],
  tableNote:
    'Les règles IFI peuvent évoluer. À vérifier selon la réglementation en vigueur au moment de la déclaration.',
  criteriaTitle: 'Critères à croiser avec l\'IFI',
  criteriaCards: [
    { title: 'Seuil IFI', text: 'L\'IFI s\'applique au-delà d\'un seuil de patrimoine immobilier net. À vérifier selon la réglementation en vigueur.' },
    { title: 'Valeur IFI', text: 'Communiquée chaque année par la société de gestion. À utiliser impérativement pour la déclaration IFI.' },
    { title: 'Mode de détention', text: 'Direct, assurance-vie, nue-propriété, SCI : le traitement IFI varie selon le mode de détention.' },
    { title: 'Dette déductible', text: 'Les dettes d\'acquisition de parts de SCPI peuvent être déductibles sous conditions. Affectation à justifier.' },
    { title: 'Patrimoine global', text: 'L\'IFI s\'apprécie au niveau du patrimoine immobilier net total, pas SCPI par SCPI.' },
    { title: 'Documentation', text: 'Conserver la valeur IFI communiquée par chaque société de gestion. Déclaration à effectuer avec prudence.' },
  ],
  commonErrors: [
    'Oublier de déclarer les parts de SCPI à l\'IFI alors qu\'elles sont imposables.',
    'Confondre prix de souscription et valeur IFI : la valeur IFI est spécifique et communiquée par la société de gestion.',
    'Croire que l\'assurance-vie exonère automatiquement de l\'IFI : c\'est généralement le cas, mais à vérifier selon la réglementation.',
    'Négliger la déductibilité des dettes d\'acquisition de parts de SCPI.',
    'Ne pas répartir correctement la valeur IFI en cas de détention via une SCI.',
    'Déclarer une valeur différente de celle communiquée par la société de gestion sans justification.',
  ],
  practicalCases: [
    {
      title: 'Détention directe — Valeur IFI',
      text: '100 parts de SCPI. Valeur IFI unitaire : 200 €. Valeur IFI totale : 20 000 €. Cette valeur s\'ajoute aux autres actifs immobiliers. Si le patrimoine net total dépasse le seuil, l\'IFI est dû sur l\'ensemble.',
    },
    {
      title: 'Assurance-vie — Non-imposition',
      text: 'Un investisseur détient 50 000 € de SCPI via son contrat d\'assurance-vie. Ces parts sont considérées comme des actifs financiers du contrat. Elles ne sont généralement pas imposables à l\'IFI.',
    },
    {
      title: 'Démembrement — Nu-propriétaire',
      text: 'Un investisseur acquiert des parts en nue-propriété pour 10 ans. En principe, il ne déclare pas la valeur à l\'IFI. L\'usufruitier déclare. À l\'issue du démembrement, l\'investisseur devient plein propriétaire et déclare à l\'IFI.',
    },
    {
      title: 'Dette déductible',
      text: 'Un investisseur a souscrit un emprunt de 50 000 € pour acquérir des parts de SCPI. Sous réserve des conditions applicables, cette dette peut être déduite du patrimoine IFI, réduisant l\'assiette imposable.',
    },
    {
      title: 'Détention via SCI',
      text: 'Une SCI à l\'IS détient des parts de SCPI pour 100 000 € de valeur IFI. Les associés déclarent leur quote-part dans leur patrimoine IFI. La valeur doit être répartie selon les règles de transparence.',
    },
  ],
  methodParagraphs: [
    'Vérifier si le patrimoine immobilier net du foyer dépasse le seuil IFI.',
    'Identifier toutes les parts de SCPI détenues et leur mode de détention.',
    'Récupérer la valeur IFI communiquée par chaque société de gestion.',
    'Vérifier le traitement IFI selon le mode de détention (direct, AV, nue-propriété, SCI).',
    'Déduire les dettes éligibles sous conditions.',
    'Déclarer le patrimoine immobilier net selon les modalités en vigueur.',
    'Conserver les justificatifs (valeurs IFI, dettes, contrats) en cas de contrôle.',
  ],
  conclusionParagraphs: [
    'Les SCPI peuvent avoir un impact sur l\'IFI. Leur traitement dépend du mode de détention et de la valeur IFI communiquée par la société de gestion.',
    'Il est recommandé de vérifier chaque année la valeur IFI transmise et de s\'assurer de la correcte déclaration selon sa situation.',
    'En cas de doute sur le traitement IFI de ses parts de SCPI, il est conseillé de consulter un professionnel.',
  ],
  faqItems: [
    {
      question: 'Les SCPI entrent-elles dans l\'IFI ?',
      answer: 'En principe, les parts de SCPI détenues en direct sont considérées comme des actifs immobiliers imposables à l\'IFI. Leur valeur IFI est communiquée par la société de gestion.',
    },
    {
      question: 'Quelle valeur déclarer ?',
      answer: 'La valeur IFI communiquée par la société de gestion, qui peut différer du prix de souscription ou de la valeur de reconstitution.',
    },
    {
      question: 'Qui fournit la valeur IFI ?',
      answer: 'La société de gestion transmet chaque année la valeur IFI par part dans le bulletin trimestriel ou le relevé annuel.',
    },
    {
      question: 'Les SCPI en assurance-vie sont-elles concernées ?',
      answer: 'En règle générale, les SCPI détenues en unités de compte dans un contrat d\'assurance-vie ne sont pas imposables à l\'IFI. Ce principe est à vérifier selon la réglementation applicable.',
    },
    {
      question: 'Que se passe-t-il en démembrement ?',
      answer: 'En principe, l\'usufruitier déclare la valeur des parts à l\'IFI, tandis que le nu-propriétaire ne déclare pas. Les règles peuvent varier selon la nature du démembrement.',
    },
    {
      question: 'Peut-on déduire une dette ?',
      answer: 'Les dettes contractées pour l\'acquisition de parts de SCPI peuvent être déductibles sous conditions. L\'affectation de la dette doit être justifiée.',
    },
    {
      question: 'Les SCPI européennes sont-elles concernées par l\'IFI ?',
      answer: 'Les SCPI investies en Europe sont généralement soumises aux mêmes règles IFI que les SCPI françaises, sous réserve des conventions applicables.',
    },
    {
      question: 'Faut-il déclarer chaque année ?',
      answer: 'Oui, si le patrimoine immobilier net dépasse le seuil IFI, la déclaration doit être effectuée chaque année, avec les valeurs IFI actualisées.',
    },
    {
      question: 'Que faire en cas de doute sur la valeur IFI ?',
      answer: 'Contacter la société de gestion pour obtenir la valeur IFI officielle. Ne pas utiliser une valeur estimée personnelle.',
    },
    {
      question: 'Comment MaximusSCPI intègre l\'IFI ?',
      answer: 'MaximusSCPI intègre l\'IFI dans l\'analyse selon le mode de détention et les informations communiquées par les sociétés de gestion. L\'approche est pédagogique.',
    },
  ],
  comparateurCtaLabel: 'Comparer les SCPI et leur impact IFI potentiel',
}
