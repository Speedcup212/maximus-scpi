import type { ScpiEducationalPageConfig } from './shared'

export const amfScpiConfig: ScpiEducationalPageConfig = {
  path: '/amf-scpi',
  badge: 'Réglementation',
  h1: 'AMF et SCPI : rôle, contrôle et documents à vérifier',
  heroSubtitle:
    "L'Autorité des Marchés Financiers (AMF) encadre les SCPI via l'agrément des sociétés de gestion, le contrôle de l'information diffusée et la supervision des documents réglementaires. Comprendre ce cadre permet à l'investisseur de savoir ce qui est contrôlé et ce qui ne l'est pas.",
  seoTitle: 'AMF et SCPI : ce que le régulateur contrôle vraiment | MaximusSCPI',
  seoDescription:
    "SCPI et AMF : découvrez ce que le régulateur contrôle, les documents à vérifier et ce que l'agrément ne garantit ni sur le rendement ni sur le capital.",
  shortAnswerTitle: "Quel est le rôle de l'AMF pour les SCPI ?",
  shortAnswer:
    "L'Autorité des Marchés Financiers (AMF) agrée les sociétés de gestion de SCPI et contrôle l'information qu'elles diffusent auprès des investisseurs. Elle s'assure que les documents réglementaires (note d'information, DIC, rapport annuel, bulletin trimestriel) sont conformes et accessibles. Cependant, le contrôle AMF ne garantit pas le rendement d'une SCPI, ni sa liquidité, ni la préservation du capital. L'investisseur doit lire les documents et analyser les indicateurs clés.",
  keyMessage:
    "Le cadre AMF renforce l'information et l'encadrement du marché, mais il ne garantit ni le rendement, ni la liquidité, ni le capital.",
  definitionParagraphs: [
    "L'Autorité des Marchés Financiers (AMF) est le régulateur des marchés financiers français. Elle est chargée de veiller à la protection de l'épargne investie, à l'information des investisseurs et au bon fonctionnement des marchés. Dans l'univers des SCPI, l'AMF intervient principalement via l'agrément et le contrôle des sociétés de gestion.",
    "Avant qu'une société de gestion puisse lancer ou gérer une SCPI, elle doit obtenir un agrément de l'AMF. Cet agrément atteste que la société dispose des moyens humains, techniques et financiers pour exercer son activité, et que ses dirigeants possèdent l'expérience et l'honorabilité nécessaires. L'agrément est un préalable obligatoire qui constitue un premier filtre de qualité.",
    "L'AMF ne se limite pas à l'agrément initial. Elle exerce un contrôle continu sur les sociétés de gestion : examen des documents réglementaires, vérification des communications commerciales, inspections sur place, suivi des déclarations périodiques. Ce contrôle vise à s'assurer que les sociétés respectent en permanence leurs obligations réglementaires.",
    "Les sociétés de gestion doivent soumettre à l'AMF leurs documents réglementaires (note d'information, DIC, rapport annuel, bulletin trimestriel) et leurs communications à caractère promotionnel. L'AMF vérifie la conformité de ces documents sans pour autant valider leur contenu commercial ou stratégique. Elle peut demander des modifications, des retraits ou publier des mises en garde.",
    "Un point fondamental à comprendre est que le contrôle de l'AMF ne constitue pas une garantie de performance ou de sécurité de l'investissement. L'AMF ne se prononce pas sur l'opportunité d'investir dans une SCPI donnée, ni sur la qualité de sa gestion, ni sur ses perspectives de rendement. Elle vérifie que l'information fournie est conforme, complète et loyale, mais n'atteste pas de la pertinence de l'investissement pour un épargnant particulier.",
    "La différence entre un produit réglementé et un produit garanti est essentielle à saisir. Une SCPI agréée par l'AMF est un produit réglementé, ce qui signifie que son fonctionnement et son information sont encadrés. Elle n'est en aucun cas un produit garanti : le capital investi n'est pas protégé, les revenus ne sont pas assurés, et la revente des parts peut prendre du temps. Cette distinction est au cœur de la compréhension du risque SCPI.",
  ],
  tableTitle: "Élément contrôlé ou encadré / Utilité pour l'investisseur / Limite",
  tableRows: [
    {
      level: 'Agrément AMF de la société de gestion',
      advantage: "Garantit que la société dispose des moyens et de l'honorabilité requis pour gérer des SCPI.",
      vigilance: "L'agrément ne garantit pas la performance future ni la qualité de la gestion au quotidien.",
    },
    {
      level: 'Note d\'information visée par l\'AMF',
      advantage: 'Document complet qui détaille le fonctionnement, les frais, les risques et la stratégie.',
      vigilance: "Le visa AMF atteste de la conformité, pas de la qualité de l'investissement ni de sa pertinence pour l'investisseur.",
    },
    {
      level: 'Document d\'Informations Clés (DIC)',
      advantage: 'Synthèse standardisée pour comparer rapidement le risque, les frais et la durée recommandée.',
      vigilance: 'Les scénarios de performance sont indicatifs, pas des prévisions. Le DIC ne remplace pas la lecture de la note d\'information.',
    },
    {
      level: 'Rapport annuel et bulletin trimestriel',
      advantage: 'Permettent de suivre l\'évolution du patrimoine, du taux d\'occupation, de la collecte et des résultats.',
      vigilance: 'Ces documents sont des données historiques : elles renseignent sur le passé mais n\'assurent pas la performance future.',
    },
    {
      level: 'Contrôle des communications commerciales',
      advantage: "L'AMF vérifie que les messages promotionnels sont exacts, non trompeurs et accompagnés des mentions obligatoires.",
      vigilance: "Certaines communications échappent au contrôle préalable. L'investisseur doit rester attentif aux promesses implicites de rendement.",
    },
  ],
  tableNote:
    'Le contrôle AMF est un gage de sérieux et de conformité, mais il ne se substitue pas à l\'analyse personnelle de l\'investisseur ni au conseil personnalisé d\'un professionnel.',
  criteriaTitle: 'Points clés sur le cadre AMF',
  criteriaCards: [
    {
      title: 'Agrément de la société de gestion',
      text: "Avant toute commercialisation, la société de gestion doit obtenir l'agrément de l'AMF. Cet agrément est une condition nécessaire mais non suffisante pour évaluer la qualité de la SCPI.",
    },
    {
      title: 'Documents réglementaires',
      text: "L'AMF examine les documents réglementaires (note d'information, DIC, rapports) et peut demander des corrections ou des compléments. Le visa AMF sur la note d'information est un repère important.",
    },
    {
      title: 'Mises en garde et sanctions',
      text: "L'AMF peut publier des mises en garde contre des sociétés ou pratiques non conformes, et prononcer des sanctions allant du blâme au retrait d'agrément. Le site AMF répertorie ces informations.",
    },
    {
      title: 'Contrôle vs garantie',
      text: "La régulation AMF améliore la qualité et la transparence de l'information, mais elle ne garantit ni le rendement, ni la liquidité, ni la préservation du capital investi.",
    },
    {
      title: 'Actualité réglementaire',
      text: "Le cadre réglementaire évolue (MIF2, SFDR, réglementation européenne). La veille réglementaire est indispensable pour suivre les changements qui impactent les SCPI et l'information due aux investisseurs.",
    },
  ],
  commonErrors: [
    "Confondre agrément AMF et garantie de rendement : le visa AMF atteste de la conformité du document, pas de la performance de la SCPI.",
    "Croire que l'AMF valide la qualité d'un investissement : elle contrôle l'information, pas l'opportunité d'investir.",
    "Ne pas lire les documents réglementaires en se fiant uniquement au visa AMF : le visa ne dispense pas de l'analyse personnelle.",
    "Ignorer les mises en garde et sanctions publiées par l'AMF : ces informations sont publiques et consultables sur le site AMF.",
    "Confondre une SCPI réglementée (agréée AMF) et un produit d'épargne réglementé (assurance-vie, livret) : les protections ne sont pas les mêmes.",
    "Penser que l'AMF couvre tous les aspects : la fiscalité, la liquidité et les conditions de revente dépendent de chaque SCPI et ne sont pas garanties par le régulateur.",
  ],
  practicalCases: [
    {
      title: 'Investisseur vérifiant l\'agrément AMF d\'une société de gestion',
      text: 'Un investisseur consulte le site AMF pour vérifier si la société de gestion qui lui propose une SCPI est bien agréée. Il trouve le numéro d\'agrément et vérifie qu\'aucune sanction n\'est en cours. Simulation pédagogique simplifiée, hors frais, hors fiscalité complète, hors variation du prix des parts, sans garantie de rendement et sous réserve de la situation personnelle.',
    },
    {
      title: 'Investisseur lisant une mise en garde AMF',
      text: 'Un investisseur découvre une mise en garde de l\'AMF concernant des pratiques commerciales trompeuses sur une SCPI. Il décide de suspendre son projet et de consulter un CGP-CIF pour analyser les risques. Simulation pédagogique simplifiée, hors frais, hors fiscalité complète, hors variation du prix des parts, sans garantie de rendement et sous réserve de la situation personnelle.',
    },
    {
      title: 'Investisseur confondant contrôle réglementaire et performance garantie',
      text: 'Un investisseur pense que l\'agrément AMF garantit le rendement de la SCPI. Après une baisse du prix de part, il apprend que le contrôle AMF ne couvre pas la performance. Cette situation illustre l\'importance de comprendre les limites du cadre réglementaire. Simulation pédagogique simplifiée, hors frais, hors fiscalité complète, hors variation du prix des parts, sans garantie de rendement et sous réserve de la situation personnelle.',
    },
  ],
  methodParagraphs: [
    "La méthode MaximusSCPI s'appuie sur les documents réglementaires validés par l'AMF comme source principale d'analyse. Avant toute pré-orientation pédagogique, nous vérifions l'agrément de la société de gestion et les éventuelles mises en garde publiées.",
    "Nous recommandons à tout investisseur de consulter les documents réglementaires (note d'information, DIC, rapport annuel) avant toute décision. Le visa AMF est un indicateur de conformité, pas un label de qualité de l'investissement.",
    "MaximusSCPI, via le Cabinet Eric Bellaiche, CGP-CIF inscrit ORIAS n°13001580, intègre le cadre réglementaire dans son analyse et rappelle systématiquement les limites du contrôle AMF.",
  ],
  conclusionParagraphs: [
    "L'AMF joue un rôle essentiel dans l'encadrement des SCPI : agrément des sociétés de gestion, contrôle des documents, supervision des communications. Ce cadre améliore la transparence et la qualité de l'information mise à disposition des investisseurs.",
    "Sources : site AMF (amf-france.org), code monétaire et financier, documents réglementaires des SCPI (note d'information, DIC, rapport annuel), registre ORIAS.",
    "Le cadre AMF est un repère important, mais il ne remplace ni l'analyse personnelle ni l'accompagnement par un professionnel habilité. Consultez un CGP-CIF pour valider votre analyse SCPI.",
  ],
  faqItems: [
    {
      question: "Qu'est-ce que l'AMF ?",
      answer: "L'Autorité des Marchés Financiers est le régulateur des marchés financiers français. Elle agrée et contrôle les sociétés de gestion de SCPI.",
    },
    {
      question: "Les SCPI sont-elles toutes contrôlées par l'AMF ?",
      answer: "Les SCPI françaises sont gérées par des sociétés agréées par l'AMF. Les SCPI étrangères distribuées en France peuvent être soumises à d'autres régulateurs européens (passeport) ou à des règles différentes.",
    },
    {
      question: "L'agrément AMF garantit-il la qualité de la SCPI ?",
      answer: "Non. L'agrément garantit que la société de gestion respecte les conditions réglementaires, mais ne garantit ni le rendement, ni la liquidité, ni la sécurité du capital.",
    },
    {
      question: "Que vérifier sur le site de l'AMF ?",
      answer: "L'agrément de la société de gestion, les mises en garde publiées, les sanctions éventuelles et les communications de l'AMF sur les SCPI.",
    },
    {
      question: "L'AMF peut-elle interdire une SCPI ?",
      answer: "L'AMF peut interdire la commercialisation d'une SCPI si la société de gestion ne respecte pas ses obligations réglementaires. Elle peut aussi retirer l'agrément de la société de gestion.",
    },
    {
      question: "Qu'est-ce que le visa AMF sur la note d'information ?",
      answer: "Le visa AMF atteste que la note d'information est conforme à la réglementation. Il ne valide pas la pertinence de l'investissement ni ses perspectives de rendement.",
    },
    {
      question: "L'AMF protège-t-elle l'investisseur en SCPI ?",
      answer: "L'AMF protège l'investisseur en s'assurant que l'information fournie est complète et loyale, mais elle ne protège pas contre les risques d'investissement (perte en capital, liquidité).",
    },
    {
      question: "Où trouver les mises en garde de l'AMF sur les SCPI ?",
      answer: "Sur le site amf-france.org, dans la rubrique « Mises en garde » ou « Epargnants ». Ces informations sont publiques et accessibles sans inscription.",
    },
    {
      question: "Quelle est la différence entre une SCPI agréée AMF et une SCPI non agréée ?",
      answer: "Une SCPI agréée AMF est gérée par une société soumise au contrôle du régulateur. Une SCPI non agréée n'offre pas les mêmes garanties réglementaires en termes d'information et de transparence.",
    },
    {
      question: "MaximusSCPI est-il contrôlé par l'AMF ?",
      answer: "MaximusSCPI est un outil d'information et de comparaison. Le Cabinet Eric Bellaiche, CGP-CIF inscrit ORIAS n°13001580, respecte la réglementation applicable aux conseillers en investissements financiers, sous le contrôle de l'AMF.",
    },
  ],
  comparateurCtaLabel: "Vérifier les documents réglementaires avant d'investir en SCPI",
}
