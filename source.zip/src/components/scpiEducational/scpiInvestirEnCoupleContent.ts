import type { ScpiEducationalPageConfig } from './shared'

export const scpiInvestirEnCoupleContent: ScpiEducationalPageConfig = {
  path: '/scpi-investir-en-couple',
  badge: 'Stratégies patrimoniales SCPI',
  h1: 'SCPI en couple : faut-il investir seul, à deux ou via société ?',
  heroSubtitle:
    'Le choix du mode de détention des parts de SCPI dans le cadre d\'un couple dépend du régime matrimonial, des objectifs patrimoniaux, de la fiscalité, de la transmission et de la traçabilité des fonds. Indivision, communauté, séparation de biens, société civile : cette page présente les logiques à connaître sans donner de conseil juridique personnalisé.',
  seoTitle: 'SCPI en couple : investir seul, à deux ou via société ?',
  seoDescription:
    'Comparaison des modes de détention de SCPI en couple : indivision, communauté, séparation de biens, société. Fiscalité, transmission, traçabilité des fonds, points de vigilance.',
  shortAnswerTitle: 'Peut-on investir en SCPI à deux ?',
  shortAnswer:
    'Oui, il est possible d\'investir en SCPI à deux via différents modes : achat en indivision (chacun détient un pourcentage des parts), acquisition via une société civile (SCI, SCPI), ou détention séparée (chacun achète ses propres parts). Le choix dépend du régime matrimonial, de la situation fiscale de chacun, des objectifs de transmission et de la répartition des revenus. Il n\'existe pas de solution universelle.',
  keyMessage:
    'Investir en SCPI à deux peut optimiser la fiscalité et faciliter la transmission, mais le choix du mode de détention doit être adapté au régime matrimonial, aux objectifs et à la situation de chaque couple.',
  definitionParagraphs: [
    'La détention en nom propre séparé (chacun achète ses propres parts) est la solution la plus simple. Chaque conjoint déclare ses revenus, paie l\'impôt selon sa TMI, et transmet ses parts selon les règles de succession.',
    'L\'indivision permet d\'acheter des parts en commun avec une quote-part définie (50/50 ou autre répartition). Les revenus sont déclarés proportionnellement à la quote-part de chacun.',
    'En communauté légale (mariage sans contrat), les parts acquises pendant le mariage sont présumées communes, sauf preuve contraire. La déclaration des revenus suit les règles de l\'imposition commune.',
    'En séparation de biens, chaque conjoint détient ses parts personnellement. Les revenus sont déclarés individuellement selon la TMI de chacun.',
    'La détention via une société civile (SCI, SCPI) peut faciliter la gestion et la transmission, mais elle ajoute des contraintes administratives et fiscales (déclaration société, imposition éventuelle à l\'IS, tenue de comptabilité).',
    'Le choix du mode de détention a des conséquences sur la fiscalité, la transmission, la liquidité et la traçabilité des fonds. Il est recommandé d\'analyser ces points avant d\'investir.',
  ],
  tableTitle: 'Mode de détention / Fonctionnement / Fiscalité / Vigilance',
  tableRows: [
    {
      level: 'Nom propre séparé',
      advantage: 'Simplicité. Chacun déclare ses revenus selon sa TMI. Transmission individuelle.',
      vigilance: 'Nécessite des fonds personnels traçables. Pas de mutualisation fiscale.',
    },
    {
      level: 'Indivision',
      advantage: 'Permet une répartition personnalisée des quotes-parts. Flexibilité.',
      vigilance: 'Déclaration proportionnelle. Gestion en commun. Sortie potentiellement complexe.',
    },
    {
      level: 'Communauté légale',
      advantage: 'Parts communes. Déclaration conjointe. Simplicité pour les couples mariés.',
      vigilance: 'Les parts sont présumées communes. Vérifier l\'impact en cas de séparation ou succession.',
    },
    {
      level: 'Société civile (SCI)',
      advantage: 'Mutualisation. Transmission facilitée des parts de société. Gestion collective.',
      vigilance: 'Administration plus lourde. Comptabilité. Coût de création et de gestion. Fiscalité spécifique.',
    },
  ],
  tableNote:
    'Ces repères sont des simulations indicatives. Le choix du mode de détention dépend de chaque situation personnelle.',
  criteriaTitle: 'Critères à prendre en compte pour choisir le mode de détention',
  criteriaCards: [
    { title: 'Régime matrimonial', text: 'Le régime détermine la propriété des parts et les règles de déclaration.' },
    { title: 'TMI de chaque conjoint', text: 'Si les TMI diffèrent, la détention séparée peut optimiser la fiscalité globale.' },
    { title: 'Objectifs de transmission', text: 'La transmission des parts varie selon le mode de détention et le régime matrimonial.' },
    { title: 'Traçabilité des fonds', text: 'En cas de séparation, la traçabilité des apports peut être déterminante.' },
    { title: 'Complexité souhaitée', text: 'La détention via société est plus complexe et coûteuse qu\'un achat en nom propre.' },
    { title: 'Liquidité des parts', text: 'La revente peut être plus complexe en indivision ou via société.' },
    { title: 'Projet patrimonial', text: 'L\'objectif (revenus, transmission, fiscalité) oriente le mode de détention.' },
    { title: 'Conseil juridique', text: 'Ce choix a des implications juridiques et fiscales. Consulter un professionnel.' },
  ],
  commonErrors: [
    'Investir en couple sans se poser la question du régime matrimonial applicable.',
    'Confondre communauté légale et indivision.',
    'Investir via société sans en mesurer les contraintes administratives et fiscales.',
    'Ne pas tracer l\'origine des fonds en cas de séparation de biens.',
    'Oublier que la détention en communauté peut compliquer la transmission aux enfants.',
    'Investir sans simuler l\'impact fiscal selon la TMI de chaque conjoint.',
  ],
  practicalCases: [
    {
      title: 'Couple marié sous communauté — TMI 30 % et 11 %',
      text: 'Un couple marié sous communauté avec des TMI différentes (30 % et 11 %). Simulation pédagogique : investir en SCPI séparément permet à chaque conjoint de déclarer ses revenus selon sa propre TMI. Le conjoint à 11 % paie moins d\'impôt sur ses revenus SCPI. Simulation non contractuelle.',
    },
    {
      title: 'Couple pacsé en indivision',
      text: 'Un couple pacsé investit 100 000 € en SCPI en indivision 50/50. Simulation pédagogique : chaque partenaire déclare 50 % des revenus selon sa TMI. En cas de séparation, la quote-part de chacun est claire. Simulation non contractuelle.',
    },
  ],
  methodParagraphs: [
    'MaximusSCPI fournit des repères pédagogiques sur l\'investissement en SCPI. Ce contenu n\'est pas un conseil juridique ou fiscal personnalisé.',
    'Le choix du mode de détention doit être adapté à la situation personnelle de chaque couple.',
    'Consulter un notaire ou un conseiller en gestion de patrimoine pour valider le choix.',
  ],
  conclusionParagraphs: [
    'Investir en SCPI à deux offre des opportunités d\'optimisation fiscale et de transmission, mais le choix du mode de détention doit être adapté au régime matrimonial, à la situation fiscale et aux objectifs patrimoniaux.',
    'Sources et points à vérifier : contrat de mariage, régime matrimonial, situation fiscale de chaque conjoint, objectifs de transmission.',
    'Utilisez le comparateur MaximusSCPI pour visualiser les SCPI, puis validez votre projet avec un conseiller.',
  ],
  faqItems: [
    {
      question: 'Peut-on acheter des parts de SCPI à deux ?',
      answer: 'Oui, via l\'indivision (quote-part définie) ou via une société civile. Chaque mode a des implications fiscales et juridiques.',
    },
    {
      question: 'Comment déclarer les revenus SCPI en couple marié ?',
      answer: 'Cela dépend du régime matrimonial. En communauté, les revenus sont déclarés conjointement. En séparation, chaque conjoint déclare ses parts.',
    },
    {
      question: 'Est-il plus intéressant fiscalement d\'investir chacun de son côté ?',
      answer: 'Si les TMI diffèrent, la détention séparée peut être plus avantageuse : le conjoint avec la TMI la plus basse paie moins d\'impôt.',
    },
    {
      question: 'Faut-il créer une SCI pour investir en SCPI à deux ?',
      answer: 'Pas nécessairement. La SCI apporte des avantages (transmission, gestion) mais aussi des contraintes. À évaluer selon le projet.',
    },
    {
      question: 'Qu\'advient-il des parts de SCPI en cas de séparation ?',
      answer: 'Cela dépend du mode de détention et du régime matrimonial. En indivision, la quote-part de chacun est claire. En communauté, les parts sont présumées communes.',
    },
  ],
}
