import type { ScpiEducationalPageConfig } from './shared'

export const scpiLogistiqueConfig: ScpiEducationalPageConfig = {
  path: '/scpi-logistique',
  badge: 'Secteur logistique',
  h1: 'SCPI logistique : entrepôts, e-commerce et risques à connaître',
  heroSubtitle:
    'La logistique a bénéficié de tendances structurelles (e-commerce, supply chain). Mais le secteur dépend fortement de la localisation, de la qualité des actifs, des locataires, des coûts de financement et de la valorisation. Une SCPI logistique ne doit pas être achetée seulement parce que le secteur paraît porteur.',
  seoTitle: 'SCPI logistique : rendement, entrepôts, e-commerce et vigilance',
  seoDescription:
    'Analyse complète des SCPI logistique : entrepôts, locaux d\'activité, e-commerce, localisation, obsolescence technique, normes environnementales, dépendance aux locataires, TOF, endettement, valorisation, cas pratiques.',
  shortAnswerTitle: 'Que sont les SCPI logistique et comment les analyser ?',
  shortAnswer:
    'Les SCPI logistique investissent dans des entrepôts, locaux d\'activité et plateformes logistiques. Le secteur a été porté par l\'essor du e-commerce et les besoins de supply chain. Cependant, la localisation (axes routiers, bassins de consommation), la qualité des actifs (normes BBC/RE2020), l\'obsolescence potentielle, la dépendance à certains locataires et la valorisation (surcote éventuelle) sont des critères déterminants. Le secteur logistique n\'est pas homogène : la qualité de chaque actif compte autant que la tendance sectorielle.',
  keyMessage:
    'Une SCPI logistique ne doit pas être achetée seulement parce que le secteur paraît porteur. La localisation, les baux, les locataires, le prix payé et l\'endettement restent déterminants.',
  definitionParagraphs: [
    'Une SCPI logistique est spécialisée dans l\'immobilier logistique : entrepôts de distribution, locaux d\'activité, plateformes logistiques, centres de tri, espaces de stockage.',
    'Le secteur logistique a connu une croissance soutenue portée par le développement du e-commerce et la réorganisation des supply chains post-COVID. Cette tendance structurelle a attiré de nombreux investisseurs, ce qui a fait monter les prix.',
    'La localisation est un critère clé : les entrepôts situés à proximité des grands axes de transport et des bassins de consommation (Ile-de-France, Lyon, Lille, Marseille) sont plus recherchés et mieux valorisés.',
    'Le risque d\'obsolescence est réel : les normes environnementales (RE2020, BBC) et les exigences des locataires en matière de performance énergétique peuvent rendre certains actifs obsolètes, nécessitant des rénovations coûteuses.',
    'La dépendance à certains locataires (transporteurs, e-commerçants) doit être analysée. Un locataire unique ou un secteur trop concentré (un seul type de fret) augmente le risque locatif.',
    'La valorisation des actifs logistiques a fortement progressé. Une surcote par rapport à la valeur de reconstitution peut signaler un risque de correction, surtout si les taux d\'intérêt continuent d\'évoluer.',
  ],
  tableTitle: 'Critère logistique / Lecture favorable / Vigilance / Indicateurs à croiser',
  tableRows: [
    {
      level: 'Localisation',
      advantage: 'Entrepôts proches des axes routiers et des bassins de consommation. Meilleure résilience locative.',
      vigilance: 'Un entrepôt mal situé peut devenir difficile à louer. Vérifier la zone de chalandise et l\'accessibilité.',
    },
    {
      level: 'Qualité des actifs',
      advantage: 'Actifs récents, normes BBC/RE2020, bonne fonctionnalité, hauteur sous plafond adaptée.',
      vigilance: 'Obsolescence possible des entrepôts anciens. Anticiper les coûts de mise aux normes énergétiques.',
    },
    {
      level: 'Locataires',
      advantage: 'Locataires solides, baux longs (6-9 ans), secteur diversifié (transport, e-commerce, industrie).',
      vigilance: 'Dépendance à un locataire unique ou à un secteur (transport, e-commerce pur). Vérifier la répartition.',
    },
    {
      level: 'TOF',
      advantage: 'Un TOF élevé (> 95 %) indique une bonne occupation et des loyers réguliers.',
      vigilance: 'Un TOF en baisse peut signaler une vacance difficile à résorber ou une obsolescence des actifs.',
    },
    {
      level: 'Valorisation',
      advantage: 'Une décote sur VR peut offrir un point d\'entrée intéressant.',
      vigilance: 'Une surcote élevée expose au risque de baisse de prix de part. Comparer à la VR sur plusieurs trimestres.',
    },
    {
      level: 'Endettement',
      advantage: 'Un endettement modéré (15-25 %) et maîtrisé.',
      vigilance: 'Un endettement élevé amplifie le risque en cas de baisse des valeurs ou de hausse des taux.',
    },
  ],
  tableNote:
    'Ces repères sont indicatifs. Chaque SCPI logistique doit être analysée dans son contexte.',
  criteriaTitle: 'Points d\'attention sur les SCPI logistique',
  criteriaCards: [
    { title: 'Emplacement', text: 'Vérifier la localisation des entrepôts : axes routiers, proximité des centres de consommation, accessibilité multimodale.' },
    { title: 'Normes environnementales', text: 'Les actifs récents respectent les normes BBC/RE2020. Les actifs anciens peuvent nécessiter des rénovations coûteuses.' },
    { title: 'Baux et locataires', text: 'Durée des baux, solidité financière des locataires, diversification sectorielle (transport, e-commerce, industrie).' },
    { title: 'TOF', text: 'Un TOF élevé et stable est un indicateur de bonne santé locative. Analyser l\'évolution sur 3-5 ans.' },
    { title: 'Valorisation', text: 'Comparer le prix de souscription à la VR pour évaluer la surcote ou la décote.' },
    { title: 'Capitalisation', text: 'Une taille suffisante (> 200 M€) pour mutualiser les risques entre plusieurs actifs et zones géographiques.' },
    { title: 'Marché transfrontalier', text: 'Les SCPI logistiques européennes peuvent offrir une diversification intéressante mais avec des risques spécifiques.' },
  ],
  commonErrors: [
    'Investir dans une SCPI logistique uniquement parce que le secteur est porteur.',
    'Ignorer la localisation précise des entrepôts.',
    'Sous-estimer le risque d\'obsolescence des actifs (normes, fonctionnalité).',
    'Ne pas vérifier la dépendance à certains locataires ou secteurs.',
    'Surpayer une surcote excessive sans vérifier la VR.',
    'Croire que tous les entrepôts se valent.',
  ],
  practicalCases: [
    {
      title: 'SCPI logistique — actifs bien localisés',
      text: 'Une SCPI logistique de 600 M€ avec des entrepôts récents situés sur les grands axes logistiques (Ile-de-France, Lyon). TOF stable à 98 %. Locataires diversifiés. Simulation pédagogique simplifiée, hors frais, hors fiscalité complète, hors variation du prix des parts, sans garantie de rendement et sous réserve de la situation personnelle.',
    },
    {
      title: 'SCPI logistique trop concentrée — un seul locataire',
      text: 'Une SCPI logistique dont 60 % des loyers proviennent d\'un seul e-commerçant. Si ce locataire réduit sa surface ou change de prestataire logistique, la SCPI est exposée à une vacance importante. Simulation pédagogique : analyser la concentration locative.',
    },
    {
      title: 'Entrepôts récents mais valorisation élevée',
      text: 'Une SCPI logistique récente a acquis des entrepôts à des prix élevés. La VR est inférieure au prix de souscription (surcote de 15 %). Simulation pédagogique : la surcote peut signaler un risque de correction du prix de part.',
    },
    {
      title: 'Locaux d\'activité diversifiés',
      text: 'Une SCPI investit dans des locaux d\'activité (mixtes bureaux/entrepôt léger) avec des locataires variés (artisans, PME, services). La diversification locative est bonne, mais les baux sont souvent plus courts. Simulation pédagogique : la diversification compense des baux plus courts.',
    },
  ],
  methodParagraphs: [
    'MaximusSCPI analyse les SCPI logistique comme tout secteur : TOF, capitalisation, endettement, frais, rendement, valorisation.',
    'La méthode MaximusSCPI accorde une importance particulière à la localisation, à la qualité des actifs et à la diversification locative.',
    'La comparaison avec les autres secteurs (santé, bureaux, diversifiées) permet de vérifier la cohérence de l\'allocation.',
    'MaximusSCPI ne constitue pas une recommandation personnalisée. Un conseiller peut approfondir l\'analyse.',
  ],
  conclusionParagraphs: [
    'Les SCPI logistique offrent une exposition à un secteur structurellement porteur, mais la localisation, la qualité des actifs, la diversification locative et la valorisation sont déterminantes.',
    'Sources et points à vérifier : DIC, note d\'information, rapport annuel, localisation des actifs, ventilation des locataires, normes environnementales.',
    'Utilisez le comparateur MaximusSCPI pour analyser les SCPI logistique, puis validez avec un conseiller.',
  ],
  faqItems: [
    {
      question: 'Qu\'est-ce qu\'une SCPI logistique ?',
      answer: 'Une SCPI spécialisée dans l\'immobilier logistique : entrepôts, locaux d\'activité, plateformes logistiques, centres de distribution.',
    },
    {
      question: 'Pourquoi la logistique attire les investisseurs ?',
      answer: 'Croissance du e-commerce, besoins de supply chain, baux longs, rendements historiquement attractifs, demande structurelle.',
    },
    {
      question: 'Quels sont les risques spécifiques ?',
      answer: 'Obsolescence des actifs, dépendance aux locataires (transporteurs, e-commerçants), localisation, surcote, endettement.',
    },
    {
      question: 'Les entrepôts sont-ils toujours rentables ?',
      answer: 'Non. La rentabilité dépend de la localisation, de la qualité de l\'actif, de la solidité du locataire et du prix d\'acquisition.',
    },
    {
      question: 'Quel rôle joue l\'emplacement des entrepôts ?',
      answer: 'Un emplacement stratégique (axes routiers, bassins de consommation) est un facteur clé de réussite locative.',
    },
    {
      question: 'Quelle différence entre entrepôts et locaux d\'activité ?',
      answer: 'Les locaux d\'activité sont plus petits et mélangent bureaux et entrepôt léger. La logistique pure concerne des surfaces plus grandes.',
    },
    {
      question: 'Faut-il diversifier avec une SCPI logistique ?',
      answer: 'Oui, la logistique peut être un complément pertinent à des SCPI bureaux, santé ou diversifiées dans une allocation multi-secteurs.',
    },
    {
      question: 'Les SCPI logistiques européennes sont-elles intéressantes ?',
      answer: 'Oui, elles offrent une diversification géographique et une exposition à des marchés logistiques dynamiques, avec une fiscalité différente.',
    },
    {
      question: 'Comment évaluer le risque d\'obsolescence ?',
      answer: 'Vérifier l\'âge des entrepôts, les normes énergétiques, la hauteur sous plafond, l\'accessibilité et les investissements réalisés.',
    },
    {
      question: 'Comment MaximusSCPI analyse ce secteur ?',
      answer: 'Le comparateur affiche les indicateurs clés. Les contenus pédagogiques aident à comprendre les spécificités logistiques.',
    },
  ],
  comparateurCtaLabel: 'Analyser les SCPI logistique au-delà du rendement affiché',
}
