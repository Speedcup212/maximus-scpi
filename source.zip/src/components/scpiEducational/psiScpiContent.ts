import type { ScpiEducationalPageConfig } from './shared'

export const psiScpiConfig: ScpiEducationalPageConfig = {
  path: '/psi-scpi',
  badge: 'Réglementation',
  h1: 'PSI et SCPI : comprendre le rôle des prestataires de services d\'investissement',
  heroSubtitle:
    'Le statut de l\'intervenant compte autant que le produit présenté. Avant d\'investir, il faut comprendre qui conseille, qui commercialise et sous quel cadre réglementaire. Les PSI (Prestataires de Services d\'Investissement) sont des acteurs clés de la distribution de parts de SCPI.',
  seoTitle: 'PSI SCPI : rôle, statut, distribution et cadre réglementaire',
  seoDescription:
    'Comprenez le rôle des PSI dans l\'univers des SCPI : services d\'investissement, distribution de parts, conseil, différence avec CIF, vérification ORIAS et points de vigilance.',
  shortAnswerTitle: 'Qu\'est-ce qu\'un PSI et quel est son rôle dans les SCPI ?',
  shortAnswer:
    'Un PSI (Prestataire de Services d\'Investissement) est un intermédiaire financier habilité à fournir des services d\'investissement, dont la réception et transmission d\'ordres, le conseil en investissement et la gestion de portefeuille. Dans le cadre des SCPI, un PSI peut distribuer des parts, recevoir des ordres de souscription et fournir un conseil personnalisé s\'il est également agréé à ce titre. La différence avec un CIF (Conseiller en Investissement Financier) est que le PSI a un agrément plus large (services bancaires et d\'investissement), tandis que le CIF est spécialisé dans le conseil. Tout intervenant doit être inscrit au registre ORIAS.',
  keyMessage:
    'Le statut de l\'intervenant compte autant que le produit présenté. Avant d\'investir, il faut comprendre qui conseille, qui commercialise et sous quel cadre réglementaire.',
  definitionParagraphs: [
    'Un PSI (Prestataire de Services d\'Investissement) est une entité agréée par l\'ACPR ou l\'AMF pour fournir des services d\'investissement : réception et transmission d\'ordres, conseil en investissement, gestion de portefeuille, exécution d\'ordres.',
    'Dans le cadre des SCPI, les PSI peuvent distribuer des parts, recevoir des ordres de souscription de la part des investisseurs et les transmettre à la société de gestion.',
    'Un PSI peut également fournir un conseil en investissement personnalisé s\'il est agréé pour ce service. Dans ce cas, il est soumis aux mêmes obligations de recueil d\'informations et de déclaration d\'adéquation qu\'un CIF.',
    'La différence entre un PSI et un CIF réside dans le périmètre d\'activité : le PSI a un agrément plus large incluant potentiellement la banque et l\'investissement, tandis que le CIF est un conseil spécialisé.',
    'L\'inscription au registre ORIAS est obligatoire pour les PSI comme pour les CIF. Le registre permet de vérifier l\'agrément, les activités autorisées et l\'absence de sanction.',
    'Pour l\'investisseur, ce qui compte est de comprendre le rôle exact de son interlocuteur : s\'il s\'agit d\'une simple information, d\'une distribution ou d\'un conseil personnalisé.',
  ],
  tableTitle: 'Statut / Rôle possible / Vigilance / Ce que l\'investisseur doit vérifier',
  tableRows: [
    {
      level: 'PSI — Réception-transmission d\'ordres',
      advantage: 'Permet de souscrire des parts de SCPI via un intermédiaire habilité.',
      vigilance: 'Ce service n\'inclut pas de conseil personnalisé. L\'investisseur prend sa décision seul.',
    },
    {
      level: 'PSI — Conseil en investissement',
      advantage: 'Analyse personnalisée avec recueil d\'informations et déclaration d\'adéquation.',
      vigilance: 'Vérifier que le PSI est bien agréé pour le conseil et pas seulement pour la réception d\'ordres.',
    },
    {
      level: 'CIF (Conseiller en Investissement Financier)',
      advantage: 'Spécialiste du conseil, soumis à des obligations de transparence et de bonne conduite.',
      vigilance: 'Vérifier l\'inscription ORIAS et comprendre la rémunération (honoraires, rétrocessions).',
    },
    {
      level: 'Distributeur sans agrément conseil',
      advantage: 'Présente des produits sans analyse personnalisée.',
      vigilance: 'L\'information fournie ne constitue pas un conseil. L\'investisseur ne doit pas confondre information et recommandation.',
    },
  ],
  tableNote:
    'Ces repères sont des simplifications pédagogiques. Les activités exactes sont définies par les agréments de chaque intervenant.',
  criteriaTitle: 'Points à vérifier sur le statut de l\'intervenant',
  criteriaCards: [
    { title: 'Inscription ORIAS', text: 'Vérifier que l\'intervenant est inscrit au registre ORIAS avec les activités autorisées.' },
    { title: 'Nature du service', text: 'Réception d\'ordres, conseil, ou simple information ? Chaque service a des obligations différentes.' },
    { title: 'Transparence des rémunérations', text: 'L\'intervenant doit indiquer comment il est rémunéré (commissions, rétrocessions, honoraires).' },
    { title: 'Conflits d\'intérêts', text: 'Demander si l\'intervenant est lié à des sociétés de gestion ou perçoit des commissions variables.' },
    { title: 'Déclaration d\'adéquation', text: 'Si un conseil est fourni, une déclaration d\'adéquation doit être remise.' },
  ],
  commonErrors: [
    'Confondre information commerciale et conseil personnalisé.',
    'Ne pas vérifier l\'inscription ORIAS de l\'intervenant.',
    'Croire qu\'un distributeur de parts est aussi un conseiller.',
    'Ignorer que la réception d\'ordres et le conseil sont des services distincts.',
    'Ne pas demander comment l\'intervenant est rémunéré.',
  ],
  practicalCases: [
    {
      title: 'Investisseur qui reçoit une information simple',
      text: 'Un investisseur reçoit une documentation sur une SCPI de la part d\'un intermédiaire. L\'intermédiaire est habilité uniquement à la réception-transmission d\'ordres. Simulation pédagogique simplifiée, hors frais, hors fiscalité complète, hors variation du prix des parts, sans garantie de rendement et sous réserve de la situation personnelle.',
    },
    {
      title: 'Investisseur qui bénéficie d\'un conseil personnalisé',
      text: 'Un investisseur consulte un PSI agréé pour le conseil en investissement. Celui-ci recueille sa situation, analyse sa fiscalité et ses objectifs, et remet une déclaration d\'adéquation. Simulation pédagogique : le conseil personnalisé est encadré réglementairement.',
    },
    {
      title: 'Vérification ORIAS avant souscription',
      text: 'Un investisseur vérifie sur orias.fr l\'inscription de son interlocuteur avant de souscrire. Il découvre que l\'intervenant n\'est pas inscrit en tant que CIF ou PSI conseil. Simulation pédagogique : cette vérification est un réflexe essentiel.',
    },
  ],
  methodParagraphs: [
    'MaximusSCPI encourage la vérification du statut de tout intervenant avant une souscription.',
    'La méthode MaximusSCPI distingue clairement information, distribution et conseil personnalisé.',
    'MaximusSCPI ne constitue pas une recommandation personnalisée. Le conseil personnalisé est assuré par le Cabinet Eric Bellaiche.',
  ],
  conclusionParagraphs: [
    'Le statut de l\'intervenant (PSI, CIF, distributeur) détermine le cadre de la relation avec l\'investisseur. Comprendre ce cadre est essentiel avant toute souscription.',
    'Sources et points à vérifier : registre ORIAS, site AMF, documents d\'entrée en relation, informations sur les services fournis.',
    'Vérifiez le cadre de conseil avant une souscription SCPI.',
  ],
  faqItems: [
    {
      question: 'Qu\'est-ce qu\'un PSI ?',
      answer: 'Un Prestataire de Services d\'Investissement, agréé par l\'ACPR ou l\'AMF, pouvant fournir des services d\'investissement (réception d\'ordres, conseil, gestion).',
    },
    {
      question: 'Quelle est la différence entre un PSI et un CIF ?',
      answer: 'Le PSI a un agrément plus large (services bancaires et d\'investissement). Le CIF est spécialisé dans le conseil en investissement.',
    },
    {
      question: 'Un PSI peut-il conseiller des SCPI ?',
      answer: 'Oui, s\'il est agréé pour le service de conseil en investissement. Sinon, il ne peut que transmettre des ordres.',
    },
    {
      question: 'Comment vérifier le statut d\'un intervenant ?',
      answer: 'Consulter le registre ORIAS (orias.fr) avec son nom ou son numéro d\'inscription.',
    },
    {
      question: 'Qu\'est-ce que la réception-transmission d\'ordres ?',
      answer: 'Un service qui permet de transmettre un ordre de souscription à la société de gestion, sans conseil personnalisé.',
    },
    {
      question: 'Un distributeur de parts est-il un conseiller ?',
      answer: 'Pas nécessairement. La distribution est un service distinct du conseil. Vérifier l\'agrément.',
    },
    {
      question: 'Doit-on recevoir une déclaration d\'adéquation ?',
      answer: 'Oui, si un conseil personnalisé est fourni. En l\'absence de conseil, la déclaration n\'est pas requise.',
    },
    {
      question: 'Que vérifier sur ORIAS ?',
      answer: 'L\'identité, les activités autorisées, les catégories d\'inscription et l\'absence de sanction.',
    },
    {
      question: 'Pourquoi le statut est-il important ?',
      answer: 'Il détermine le niveau de protection de l\'investisseur et les obligations de l\'intervenant.',
    },
    {
      question: 'Comment MaximusSCPI aborde les statuts réglementaires ?',
      answer: 'Les contenus pédagogiques expliquent les différents statuts. L\'approche est transparente et pédagogique.',
    },
  ],
  comparateurCtaLabel: 'Vérifier le cadre de conseil avant une souscription SCPI',
}
