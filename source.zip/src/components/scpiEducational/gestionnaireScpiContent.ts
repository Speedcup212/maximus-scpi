import type { ScpiEducationalPageConfig } from './shared'

export const gestionnaireScpiConfig: ScpiEducationalPageConfig = {
  path: '/gestionnaire-scpi',
  badge: 'Acteurs SCPI',
  h1: 'Gestionnaire de SCPI : qui gère vraiment votre investissement ?',
  heroSubtitle:
    'Le mot gestionnaire peut désigner plusieurs intervenants : société de gestion, asset manager, property manager, distributeur, conseiller. Avant d\'investir, il faut comprendre qui gère les actifs, qui commercialise les parts et qui conseille l\'investisseur.',
  seoTitle: 'Gestionnaire SCPI : société de gestion, asset manager, property manager',
  seoDescription:
    'Comprenez qui intervient dans la gestion d\'une SCPI : société de gestion (agrément AMF), asset manager, property manager, distributeur, CGP-CIF et rôle de chacun dans la chaîne de valeur.',
  shortAnswerTitle: 'Qui sont les différents gestionnaires d\'une SCPI ?',
  shortAnswer:
    'Le terme "gestionnaire" recouvre plusieurs intervenants aux rôles distincts. La société de gestion est l\'entité agréée par l\'AMF qui gère la SCPI au global : stratégie, acquisitions, arbitrages, politique de distribution. L\'asset manager suit la performance des actifs et les expertises. Le property manager gère la relation locative au quotidien (baux, travaux, quittances). Le distributeur commercialise les parts sans gérer les actifs. Le CGP-CIF conseille l\'investisseur sur le choix de la SCPI en fonction de sa situation. L\'assureur intervient si la SCPI est détenue en assurance-vie.',
  keyMessage:
    'Le mot gestionnaire peut désigner plusieurs intervenants. Avant d\'investir, il faut comprendre qui gère les actifs, qui commercialise les parts et qui conseille l\'investisseur.',
  definitionParagraphs: [
    'La société de gestion est l\'entité centrale : elle est agréée par l\'AMF, définit la stratégie d\'investissement, sélectionne les actifs, fixe le prix de part et la politique de distribution.',
    'L\'asset manager est un professionnel (interne ou externe) qui suit la performance des actifs immobiliers, prépare les expertises, propose des arbitrages et optimise la valorisation du patrimoine.',
    'Le property manager (gestionnaire locatif) gère la relation avec les locataires : encaissement des loyers, suivi des baux, gestion des travaux, relocation. Il peut être interne à la société de gestion ou externalisé.',
    'Le distributeur est un intermédiaire qui commercialise les parts de SCPI auprès des investisseurs. Il ne gère pas les actifs. Sa rémunération provient des commissions de souscription.',
    'Le CGP-CIF (Conseiller en Gestion de Patrimoine – Conseil en Investissement Financier) analyse la situation patrimoniale de l\'investisseur et propose une pré-orientation pédagogique vers des SCPI adaptées.',
    'Le PSI (Prestataire de Services d\'Investissement) peut recevoir et transmettre des ordres de souscription. Son rôle est distinct de celui du conseiller.',
    'L\'assureur intervient si les parts de SCPI sont souscrites en unités de compte dans un contrat d\'assurance-vie.',
  ],
  tableTitle: 'Intervenant / Rôle / Ce qu\'il ne fait pas / Vigilance',
  tableRows: [
    {
      level: 'Société de gestion',
      advantage: 'Gère la SCPI : stratégie, actifs, distribution, communication réglementaire.',
      vigilance: 'Ne conseille pas l\'investisseur personnellement. Son rôle est de gérer le patrimoine de la SCPI.',
    },
    {
      level: 'Asset manager',
      advantage: 'Optimise la performance et la valorisation des actifs immobiliers.',
      vigilance: 'N\'intervient pas dans la relation commerciale avec l\'investisseur.',
    },
    {
      level: 'Property manager',
      advantage: 'Gère la relation locative au quotidien : baux, loyers, travaux.',
      vigilance: 'Ne définit pas la stratégie de la SCPI. Peut être externalisé.',
    },
    {
      level: 'Distributeur / commercialisateur',
      advantage: 'Facilite la souscription des parts par les investisseurs.',
      vigilance: 'Ne gère pas les actifs. Sa rémunération dépend des commissions. Vérifier son statut.',
    },
    {
      level: 'CGP-CIF',
      advantage: 'Conseille l\'investisseur selon sa situation patrimoniale et fiscale.',
      vigilance: 'Ne gère pas la SCPI. Son rôle est le conseil personnalisé, pas la gestion d\'actifs.',
    },
    {
      level: 'Assureur (contrat AV)',
      advantage: 'Permet la détention de parts en unités de compte.',
      vigilance: 'La sélection des SCPI proposées dépend de l\'assureur. Pas de gestion directe des actifs.',
    },
  ],
  tableNote:
    'Chaque intervenant a un rôle distinct. Comprendre la chaîne des acteurs permet de mieux évaluer la qualité de son investissement.',
  criteriaTitle: 'Points de vigilance sur les intervenants',
  criteriaCards: [
    { title: 'Distinguer gestion et distribution', text: 'La société de gestion gère les actifs. Le distributeur commercialise les parts. Ne pas confondre les rôles.' },
    { title: 'Vérifier les statuts', text: 'CIF, PSI, assureur, société de gestion : chaque statut a des obligations réglementaires différentes. Vérifier ORIAS.' },
    { title: 'Identifier les conflits d\'intérêts', text: 'Un conseiller rémunéré par rétrocession peut être incité à recommander certaines SCPI. La transparence est essentielle.' },
    { title: 'Externalisation de la gestion', text: 'Si le property manager est externalisé, vérifier la qualité du prestataire et la coordination avec la société de gestion.' },
    { title: 'Qualité du reporting', text: 'La régularité et la qualité de l\'information fournie aux associés dépendent de la société de gestion.' },
  ],
  commonErrors: [
    'Confondre société de gestion et distributeur de parts.',
    'Penser que le conseiller qui recommande une SCPI est le même que celui qui gère les actifs.',
    'Ignorer que l\'assureur sélectionne les SCPI proposées en assurance-vie.',
    'Ne pas vérifier qui gère réellement les actifs au quotidien.',
    'Croire que distributeur et conseiller sont interchangeables.',
  ],
  practicalCases: [
    {
      title: 'Investisseur qui confond distributeur et gestionnaire',
      text: 'Un investisseur pense que le conseiller qui lui a recommandé une SCPI gère également les actifs. En réalité, le conseiller est un CGP-CIF et la société de gestion est une entité distincte. Simulation pédagogique simplifiée, hors frais, hors fiscalité complète, hors variation du prix des parts, sans garantie de rendement et sous réserve de la situation personnelle.',
    },
    {
      title: 'SCPI en assurance-vie — rôles imbriqués',
      text: 'Un investisseur détient des SCPI en assurance-vie. L\'assureur sélectionne les SCPI proposées, la société de gestion gère les actifs, et le conseiller analyse la situation personnelle. Simulation pédagogique : chaque intervenant a un rôle spécifique.',
    },
    {
      title: 'Externalisation du property manager',
      text: 'Une société de gestion externalise la gestion locative à un property manager. Si le prestataire est de qualité, la SCPI fonctionne bien. Sinon, le TOF peut se dégrader. Simulation pédagogique : vérifier qui gère les locataires au quotidien.',
    },
  ],
  methodParagraphs: [
    'MaximusSCPI distingue clairement les rôles des différents intervenants dans ses contenus pédagogiques.',
    'La méthode MaximusSCPI encourage l\'investisseur à vérifier qui est son interlocuteur et quel est son statut réglementaire.',
    'MaximusSCPI ne constitue pas une recommandation personnalisée. Un conseiller peut clarifier son rôle et son statut.',
  ],
  conclusionParagraphs: [
    'Le mot "gestionnaire" peut désigner plusieurs intervenants aux rôles très différents. Comprendre qui fait quoi est essentiel avant d\'investir.',
    'Sources et points à vérifier : site AMF, registre ORIAS, documents d\'entrée en relation, conditions générales des contrats.',
    'Utilisez le comparateur MaximusSCPI pour analyser les SCPI, puis validez avec un conseiller.',
  ],
  faqItems: [
    {
      question: 'Qui gère vraiment une SCPI ?',
      answer: 'La société de gestion agréée par l\'AMF. Elle peut déléguer certaines tâches (property manager, asset manager) mais reste responsable.',
    },
    {
      question: 'Quelle différence entre société de gestion et gestionnaire locatif ?',
      answer: 'La société de gestion définit la stratégie. Le gestionnaire locatif (property manager) gère les baux et les locataires au quotidien.',
    },
    {
      question: 'Le conseiller qui me recommande une SCPI gère-t-il les actifs ?',
      answer: 'Non. Le conseiller analyse votre situation et propose une pré-orientation. La gestion des actifs est assurée par la société de gestion.',
    },
    {
      question: 'Qu\'est-ce qu\'un asset manager ?',
      answer: 'Un professionnel qui suit la performance des actifs, prépare les expertises, propose des arbitrages pour optimiser la valorisation.',
    },
    {
      question: 'Quel est le rôle du distributeur ?',
      answer: 'Commercialiser les parts de SCPI auprès des investisseurs. Il ne gère pas les actifs.',
    },
    {
      question: 'Qui sélectionne les SCPI en assurance-vie ?',
      answer: 'L\'assureur choisit les SCPI proposées dans son contrat. L\'investisseur peut choisir parmi cette sélection.',
    },
    {
      question: 'Comment vérifier le statut d\'un intervenant ?',
      answer: 'Consulter le registre ORIAS pour les CIF et PSI, le site AMF pour les sociétés de gestion.',
    },
    {
      question: 'Un même groupe peut-il être société de gestion et distributeur ?',
      answer: 'Oui, certains groupes intègrent plusieurs entités. Vérifier la séparation des rôles et les éventuels conflits d\'intérêts.',
    },
    {
      question: 'La qualité du property manager est-elle importante ?',
      answer: 'Oui, car elle impacte directement le TOF, la régularité des loyers et la satisfaction des locataires.',
    },
    {
      question: 'Comment MaximusSCPI aide à comprendre les rôles ?',
      answer: 'Les contenus pédagogiques expliquent la chaîne des acteurs. L\'approche est transparente et pédagogique.',
    },
  ],
  comparateurCtaLabel: 'Comprendre les rôles avant de souscrire une SCPI',
}
