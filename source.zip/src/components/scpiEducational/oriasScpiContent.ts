import type { ScpiEducationalPageConfig } from './shared'

export const oriasScpiConfig: ScpiEducationalPageConfig = {
  path: '/orias-scpi',
  badge: 'Réglementation',
  h1: 'ORIAS et SCPI : pourquoi vérifier le statut de l\'intervenant ?',
  heroSubtitle:
    "L'ORIAS tient le registre unique des intermédiaires en assurance, banque et finance. Vérifier l'inscription d'un conseiller ou distributeur permet de savoir sous quel statut professionnel il intervient et quelles sont ses obligations réglementaires.",
  seoTitle: "ORIAS SCPI : vérifier le statut d'un conseiller ou distributeur",
  seoDescription:
    "Comprenez le rôle de l'ORIAS dans l'univers des SCPI : vérification des statuts professionnels, CGP-CIF, intermédiaires, distribution et points de vigilance.",
  shortAnswerTitle: "Quel est le rôle de l'ORIAS dans un investissement SCPI ?",
  shortAnswer:
    "L'ORIAS (Organisme pour le Registre des Intermédiaires en Assurance, Banque et Finance) tient le registre des professionnels habilités à intervenir dans la distribution de produits financiers, dont les SCPI. Avant de souscrire, l'investisseur peut vérifier si son interlocuteur est bien inscrit en tant que CIF (Conseiller en Investissement Financier), courtier, IAS (Intermédiaire en Assurance) ou IOBSP (Intermédiaire en Opérations de Banque). L'inscription ne garantit pas la qualité du conseil, mais elle atteste d'un cadre réglementaire et d'une obligation de compétence et de transparence.",
  keyMessage: "Avant d'analyser une SCPI, il faut aussi vérifier qui présente l'investissement et sous quel cadre professionnel.",
  definitionParagraphs: [
    "L'ORIAS est l'organisme qui tient le registre unique des intermédiaires en assurance, banque et finance en France. Tout professionnel qui exerce une activité d'intermédiation ou de conseil dans ces domaines doit y être inscrit, sous peine d'exercice illégal. Le registre ORIAS est public et consultable gratuitement sur orias.fr.",
    "Plusieurs statuts professionnels peuvent intervenir dans la distribution de SCPI : le Conseiller en Investissement Financier (CIF), le courtier en SCPI (intermédiaire en biens divers — IOBSP ou autre), l'Intermédiaire en Assurance (IAS) pour les SCPI en assurance-vie, et l'Intermédiaire en Opérations de Banque (IOBSP) pour les financements. Chaque statut correspond à un cadre réglementaire et à des obligations spécifiques.",
    "Pour vérifier un professionnel, il suffit de se rendre sur le site de l'ORIAS et de saisir son numéro d'inscription ou son nom. Le registre indique le ou les statuts sous lesquels la personne est inscrite, la date d'inscription, et les éventuelles sanctions ou radiations. Cette vérification prend quelques minutes et peut éviter des situations à risque.",
    "L'inscription à l'ORIAS impose des obligations : compétence professionnelle (formation continue), assurance responsabilité civile professionnelle, respect des règles de bonne conduite, transparence sur la rémunération et les liens d'intérêts. Le non-respect de ces obligations peut entraîner une radiation du registre et des sanctions.",
    "Il est essentiel de comprendre que l'inscription à l'ORIAS ne constitue pas un label de qualité du conseil. Un professionnel inscrit peut être compétent et sérieux, mais il peut aussi orienter vers des produits en fonction de sa rémunération. L'inscription atteste d'un cadre réglementaire, pas d'une absence de conflit d'intérêts. La vigilance de l'investisseur reste nécessaire.",
    "La vérification ORIAS est donc une étape préalable à tout investissement en SCPI. Elle permet de savoir à qui l'on a affaire et sous quel cadre le conseil ou la distribution est réalisé. Cette démarche s'inscrit dans une approche globale de due diligence qui inclut également la lecture des documents réglementaires et l'analyse des indicateurs de la SCPI.",
  ],
  tableTitle: 'Statut ou registre / Pourquoi le vérifier / Vigilance',
  tableRows: [
    {
      level: 'CIF (Conseiller en Investissement Financier)',
      advantage: 'Le professionnel est soumis à une obligation de conseil, de transparence et de déclaration d\'adéquation.',
      vigilance: 'Vérifier que le conseiller est bien à jour de son inscription et qu\'aucune sanction n\'est en cours.',
    },
    {
      level: 'Courtier en SCPI (intermédiaire)',
      advantage: 'Permet d\'accéder à un large choix de SCPI, parfois sans frais de souscription.',
      vigilance: 'Le courtier n\'est pas tenu à une obligation de conseil personnalisé. Vérifier son statut exact sur ORIAS.',
    },
    {
      level: 'IAS (Intermédiaire en Assurance)',
      advantage: 'Peut proposer des SCPI en assurance-vie, avec les avantages fiscaux de ce support.',
      vigilance: 'L\'IAS est soumis à la réglementation de la distribution d\'assurances (DDA). Vérifier les mentions obligatoires.',
    },
    {
      level: 'IOBSP (Intermédiaire en Opérations de Banque)',
      advantage: 'Intervient sur les financements (crédit immobilier) qui peuvent accompagner un investissement SCPI.',
      vigilance: 'Son rôle est limité au financement, pas au conseil en investissement. Vérifier les limites de son intervention.',
    },
    {
      level: 'Double statut (CIF + IAS / CIF + courtier)',
      advantage: 'Un professionnel avec plusieurs inscriptions peut offrir un accompagnement plus complet.',
      vigilance: 'Vérifier sous quel statut il agit dans votre dossier. Les obligations diffèrent selon le statut mobilisé.',
    },
  ],
  tableNote:
    'L\'inscription ORIAS est un préalable, pas une garantie. La vérification du registre doit être complétée par un échange avec le professionnel sur son cadre d\'intervention, sa rémunération et ses compétences.',
  criteriaTitle: 'Points de vigilance sur l\'intermédiaire',
  criteriaCards: [
    {
      title: 'Vérifier le numéro ORIAS',
      text: 'Demandez systématiquement le numéro d\'inscription ORIAS et vérifiez-le sur orias.fr. Un professionnel qui refuse de communiquer son numéro est un signal d\'alerte.',
    },
    {
      title: 'Comprendre le statut',
      text: 'CIF, courtier, IAS, IOBSP : chaque statut a des obligations différentes. Comprendre sous quel statut votre interlocuteur agit est essentiel.',
    },
    {
      title: 'Distinguer information et conseil',
      text: 'Un professionnel non-CIF peut vous informer sur les SCPI mais pas vous fournir un conseil personnalisé adapté à votre situation.',
    },
    {
      title: 'Vérifier les mentions obligatoires',
      text: 'Tout professionnel doit mentionner son numéro ORIAS, son statut, les modalités de rémunération et les liens d\'intérêts dans ses documents contractuels.',
    },
    {
      title: 'Poser des questions sur la rémunération',
      text: 'Honoraires, commissions, rétrocessions : comprenez comment votre interlocuteur est rémunéré. La transparence sur ce point est obligatoire.',
    },
  ],
  commonErrors: [
    'Investir sans vérifier le statut de son interlocuteur sur le registre ORIAS.',
    'Confondre inscription ORIAS et qualité du conseil : l\'inscription atteste d\'un cadre réglementaire, pas de la compétence ou de l\'impartialité.',
    'Croire qu\'un courtier est soumis aux mêmes obligations qu\'un CIF : les obligations de conseil et d\'adéquation diffèrent selon le statut.',
    'Ne pas vérifier si le professionnel est à jour de son inscription et s\'il a fait l\'objet de sanctions.',
    'Accepter un conseil sans recueil d\'informations préalable, même d\'un professionnel inscrit.',
    'Penser que l\'ORIAS garantit le remboursement en cas de problème : l\'ORIAS est un registre, pas un fonds de garantie.',
  ],
  practicalCases: [
    {
      title: 'Investisseur vérifiant l\'inscription ORIAS d\'un conseiller',
      text: 'Un investisseur consulte le site orias.fr avant de prendre rendez-vous avec un conseiller. Il vérifie le numéro ORIAS fourni, confirme le statut CIF et l\'absence de sanction. Simulation pédagogique simplifiée, hors frais, hors fiscalité complète, hors variation du prix des parts, sans garantie de rendement et sous réserve de la situation personnelle.',
    },
    {
      title: 'Investisseur confronté à un courtier sans conseil',
      text: 'Un investisseur reçoit une proposition de SCPI via un courtier en ligne. Il vérifie le statut du courtier sur ORIAS et découvre qu\'il n\'est pas CIF. Il comprend que la proposition n\'est pas un conseil personnalisé mais une simple information commerciale. Simulation pédagogique simplifiée, hors frais, hors fiscalité complète, hors variation du prix des parts, sans garantie de rendement et sous réserve de la situation personnelle.',
    },
    {
      title: 'Investisseur vérifiant le suivi des obligations ORIAS',
      text: 'Un investisseur interroge son conseiller sur sa formation continue et son assurance responsabilité civile professionnelle, deux obligations liées à l\'inscription ORIAS. Les réponses du conseiller permettent à l\'investisseur d\'évaluer son sérieux. Simulation pédagogique simplifiée, hors frais, hors fiscalité complète, hors variation du prix des parts, sans garantie de rendement et sous réserve de la situation personnelle.',
    },
  ],
  methodParagraphs: [
    "La méthode MaximusSCPI intègre la vérification du statut de l'intervenant comme une étape préalable à toute analyse SCPI. Nous recommandons de consulter le registre ORIAS avant d'engager une relation avec un professionnel.",
    "Le Cabinet Eric Bellaiche, CGP-CIF inscrit ORIAS n°13001580, est régulièrement inscrit et à jour de ses obligations de formation et d'assurance. Notre numéro ORIAS est communicable sur demande et vérifiable sur orias.fr.",
    "MaximusSCPI vous invite à vérifier vous-même l'inscription ORIAS de tout professionnel que vous consultez. Cette démarche simple et gratuite participe à la sécurisation de votre parcours d'investisseur.",
  ],
  conclusionParagraphs: [
    "L'ORIAS est un outil essentiel pour vérifier le cadre professionnel de l'intervenant qui vous propose ou vous conseille une SCPI. CIF, courtier, IAS, IOBSP : chaque statut a ses obligations et ses limites.",
    "Sources : registre ORIAS (orias.fr), site AMF (amf-france.org), code monétaire et financier, code des assurances, réglementation MIF2.",
    "Avant toute souscription de SCPI, prenez le temps de vérifier qui vous conseille et sous quel statut il intervient. Un professionnel transparent sur son cadre d'intervention est un premier gage de sérieux.",
  ],
  faqItems: [
    {
      question: "Qu'est-ce que l'ORIAS ?",
      answer: "L'Organisme pour le Registre des Intermédiaires en Assurance, Banque et Finance tient le registre unique des professionnels habilités à intervenir dans ces domaines.",
    },
    {
      question: "Faut-il vérifier l'inscription ORIAS avant d'investir en SCPI ?",
      answer: "Oui. C'est une vérification simple et gratuite qui permet de savoir sous quel statut votre interlocuteur intervient et s'il est à jour de ses obligations.",
    },
    {
      question: "Quelle est la différence entre un CIF et un courtier en SCPI ?",
      answer: "Le CIF est soumis à une obligation de conseil personnalisé et de déclaration d'adéquation. Le courtier peut se limiter à une information commerciale sans recueil préalable de votre situation.",
    },
    {
      question: "Comment vérifier un professionnel sur ORIAS ?",
      answer: "Rendez-vous sur orias.fr, saisissez le numéro d'inscription ou le nom du professionnel. Le registre indique les statuts, la date d'inscription et les éventuelles sanctions.",
    },
    {
      question: "L'inscription ORIAS garantit-elle la qualité du conseil ?",
      answer: "Non. Elle atteste d'un cadre réglementaire et d'obligations professionnelles, mais ne garantit pas la compétence, l'impartialité ou la qualité du conseil fourni.",
    },
    {
      question: "Quels sont les statuts ORIAS qui peuvent intervenir sur les SCPI ?",
      answer: "CIF (Conseiller en Investissement Financier), courtier, IAS (Intermédiaire en Assurance), IOBSP (Intermédiaire en Opérations de Banque), et parfois plusieurs statuts combinés.",
    },
    {
      question: "Que faire si un professionnel refuse de communiquer son numéro ORIAS ?",
      answer: "C'est un signal d'alerte. Tout professionnel est tenu de communiquer son numéro d'inscription ORIAS. En cas de refus, il est préférable de ne pas donner suite.",
    },
    {
      question: "L'ORIAS peut-il radier un professionnel ?",
      answer: "Oui, en cas de non-respect des obligations réglementaires (absence de formation continue, défaut d'assurance, manquements déontologiques). Les radiations sont consultables sur le registre.",
    },
    {
      question: "L'inscription ORIAS couvre-t-elle les SCPI étrangères ?",
      answer: "L'inscription ORIAS couvre le professionnel qui distribue ou conseille, quel que soit le produit. Cependant, les SCPI étrangères peuvent relever de régulateurs étrangers.",
    },
    {
      question: "MaximusSCPI est-il inscrit à l'ORIAS ?",
      answer: "Le Cabinet Eric Bellaiche, CGP-CIF inscrit ORIAS n°13001580, est à jour de ses obligations. MaximusSCPI est un outil d'information et de comparaison complété par un accompagnement personnalisé.",
    },
  ],
  comparateurCtaLabel: "Vérifier le cadre d'accompagnement avant une souscription SCPI",
}
