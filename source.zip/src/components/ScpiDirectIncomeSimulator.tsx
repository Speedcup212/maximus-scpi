import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Calculator, Calendar, Euro, Info } from 'lucide-react';
import { estimateSimpleScpiIncomeTax } from '../domain/scpi/simpleDirectFiscal';
import EricAvatar from './EricAvatar';
import { trackFunnelEvent } from '../utils/funnelAnalytics';

interface ScpiDirectIncomeSimulatorProps {
  defaultAmount?: number;
  defaultYield?: number;
  defaultTmi?: number;
  embedded?: boolean;
  onRdvClick?: () => void;
}

const formatEuro = (value: number) =>
  new Intl.NumberFormat('fr-FR', {
    style: 'currency',
    currency: 'EUR',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(value);

const clamp = (value: number, min: number, max: number) => Math.min(max, Math.max(min, value));

const ScpiDirectIncomeSimulator: React.FC<ScpiDirectIncomeSimulatorProps> = ({
  defaultAmount = 50000,
  defaultYield = 5,
  defaultTmi = 30,
  embedded = false,
  onRdvClick,
}) => {
  const [amount, setAmount] = useState(defaultAmount);
  const [amountInput, setAmountInput] = useState(String(defaultAmount));
  const [yieldRate, setYieldRate] = useState(defaultYield);
  const [yieldWasCustomized, setYieldWasCustomized] = useState(false);
  const [tmi, setTmi] = useState(defaultTmi);
  const [origin, setOrigin] = useState<'france' | 'international'>('france');
  const [delaiJouissanceMois, setDelaiJouissanceMois] = useState(6);
  const [horizon, setHorizon] = useState(10);
  const [interactionTick, setInteractionTick] = useState(0);
  const simulationStartedRef = useRef(false);
  const simulationResultTrackedRef = useRef(false);

  const markSimulationInteraction = () => {
    if (!simulationStartedRef.current) {
      simulationStartedRef.current = true;
      trackFunnelEvent('simulation_start', { source: 'simulateur_scpi' });
    }
    setInteractionTick(value => value + 1);
  };


  useEffect(() => {
    try {
      sessionStorage.setItem('maximus_simulator_amount', String(amount));
    } catch {
      // Non-bloquant : le formulaire restera simplement éditable manuellement.
    }
  }, [amount]);

  useEffect(() => {
    if (interactionTick === 0 || simulationResultTrackedRef.current) return;

    simulationResultTrackedRef.current = true;
    trackFunnelEvent('simulation_result', {
      source: 'simulateur_scpi',
      amount,
      yield_rate: yieldRate,
      origin,
      horizon,
    });
  }, [interactionTick, amount, yieldRate, origin, horizon]);


  const calculations = useMemo(() => {
    const fullYearGross = amount * (yieldRate / 100);
    const productiveMonths = Math.max(0, 12 - delaiJouissanceMois);
    const firstYearGross = fullYearGross * (productiveMonths / 12);

    const commonTaxInput = {
      origin,
      tmiRate: tmi / 100,
    } as const;

    const fullYearTax = estimateSimpleScpiIncomeTax({
      grossIncome: fullYearGross,
      ...commonTaxInput,
    });

    const firstYearTax = estimateSimpleScpiIncomeTax({
      grossIncome: firstYearGross,
      ...commonTaxInput,
    });

    const netFull = fullYearTax.netIncome;
    const netFirst = firstYearTax.netIncome;
    const cumulativeGross =
      firstYearGross + Math.max(0, horizon - 1) * fullYearGross;
    const cumulativeNet =
      netFull !== null && netFirst !== null
        ? netFirst + Math.max(0, horizon - 1) * netFull
        : null;
    return {
      fullYearGross,
      firstYearGross,
      fullYearTax,
      firstYearTax,
      cumulativeGross,
      cumulativeNet,
      productiveMonths,
    };
  }, [amount, yieldRate, delaiJouissanceMois, origin, tmi, horizon]);

  const taxEstimateAvailable = calculations.fullYearTax.available;
  const netAnnual = calculations.fullYearTax.netIncome;
  const netMonthly = netAnnual !== null ? netAnnual / 12 : null;
  const firstYearNet = calculations.firstYearTax.netIncome;

  return (
    <section className="px-4 py-8">
      <div className="mx-auto max-w-6xl">
        {!embedded && (
          <header className="mx-auto mb-8 max-w-3xl text-center">
            <h1 className="text-4xl font-bold tracking-tight text-gray-950 dark:text-white">
              Simulateur SCPI : revenus après fiscalité
            </h1>
            <p className="mt-3 text-lg text-gray-600 dark:text-gray-300">
              Estimez vos revenus à partir de vos hypothèses avec une approche fiscale simplifiée.
            </p>
          </header>
        )}

        <div
          className="grid gap-7 lg:grid-cols-[0.95fr_1.05fr]"
          onChangeCapture={markSimulationInteraction}
          onClickCapture={(event) => {
            if ((event.target as HTMLElement).closest('button')) markSimulationInteraction();
          }}
        >
          <div className="space-y-5">
            <div className="rounded-2xl bg-white p-6 shadow-sm dark:bg-gray-800">
              <label className="block text-sm font-semibold text-gray-700 dark:text-gray-200">
                Montant investi
              </label>
              <div className="mt-3 flex items-center gap-3">
                <input
                  type="number"
                  min={1000}
                  max={5000000}
                  step={1000}
                  value={amountInput}
                  onChange={(event) => {
                    const rawValue = event.target.value;
                    setAmountInput(rawValue);

                    if (rawValue === '') return;

                    const parsedValue = Number(rawValue);
                    if (Number.isFinite(parsedValue)) {
                      setAmount(clamp(parsedValue, 1000, 5000000));
                    }
                  }}
                  onBlur={() => {
                    if (amountInput === '') {
                      setAmountInput(String(amount));
                      return;
                    }

                    const normalizedAmount = clamp(Number(amountInput) || amount, 1000, 5000000);
                    setAmount(normalizedAmount);
                    setAmountInput(String(normalizedAmount));
                  }}
                  onFocus={(event) => event.currentTarget.select()}
                  className="w-full rounded-xl border border-gray-300 bg-white px-4 py-3 text-xl font-bold text-gray-950 outline-none focus:border-green-600 dark:border-gray-600 dark:bg-gray-900 dark:text-white"
                />
                <Euro className="h-5 w-5 shrink-0 text-gray-400" />
              </div>
              <input
                type="range"
                min={1000}
                max={5000000}
                step={1000}
                value={amount}
                onChange={(event) => {
                  const nextAmount = Number(event.target.value);
                  setAmount(nextAmount);
                  setAmountInput(String(nextAmount));
                }}
                className="mt-4 w-full"
              />
            </div>

            <div className="rounded-2xl bg-white p-6 shadow-sm dark:bg-gray-800">
              <label className="block text-sm font-semibold text-gray-700 dark:text-gray-200">
                Hypothèse de taux de distribution : <span className="text-green-700 dark:text-green-400">{yieldRate.toFixed(1)} %</span>
              </label>
              <input
                type="range"
                min={2}
                max={10}
                step={0.1}
                value={yieldRate}
                onChange={(event) => {
                  setYieldRate(Number(event.target.value));
                  setYieldWasCustomized(true);
                }}
                className="mt-4 w-full"
              />
              <p className="mt-2 text-xs leading-5 text-gray-500 dark:text-gray-400">
                Hypothèse indicative pour la simulation. Le taux de distribution réel dépend de chaque SCPI et n'est pas garanti.
              </p>
            </div>

            <div className="rounded-2xl bg-white p-6 shadow-sm dark:bg-gray-800">
              <label className="block text-sm font-semibold text-gray-700 dark:text-gray-200">
                Délai de jouissance : {delaiJouissanceMois} mois
              </label>
              <input
                type="range"
                min={0}
                max={12}
                step={1}
                value={delaiJouissanceMois}
                onChange={(event) => setDelaiJouissanceMois(Number(event.target.value))}
                className="mt-3 w-full"
              />
            </div>

            <div className="rounded-2xl bg-white p-6 shadow-sm dark:bg-gray-800">
              <p className="text-sm font-semibold text-gray-700 dark:text-gray-200">Origine des revenus immobiliers</p>
              <div className="mt-3 grid gap-3 sm:grid-cols-2">
                <button
                  type="button"
                  onClick={() => {
                    setOrigin('france');
                    if (!yieldWasCustomized) setYieldRate(5);
                  }}
                  className={`rounded-xl border-2 p-4 text-left transition ${
                    origin === 'france'
                      ? 'border-green-600 bg-green-50 dark:bg-green-950/20'
                      : 'border-gray-200 dark:border-gray-700'
                  }`}
                >
                  <span className="block font-semibold text-gray-950 dark:text-white">France</span>
                  <span className="mt-1 block text-xs text-gray-600 dark:text-gray-400">Estimation simplifiée au barème + prélèvements sociaux.</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setOrigin('international');
                    if (!yieldWasCustomized) setYieldRate(6);
                  }}
                  className={`rounded-xl border-2 p-4 text-left transition ${
                    origin === 'international'
                      ? 'border-green-600 bg-green-50 dark:bg-green-950/20'
                      : 'border-gray-200 dark:border-gray-700'
                  }`}
                >
                  <span className="block font-semibold text-gray-950 dark:text-white">Europe / international</span>
                  <span className="mt-1 block text-xs text-gray-600 dark:text-gray-400">Estimation simplifiée à la TMI, sans prélèvements sociaux français.</span>
                </button>
              </div>
            </div>

            <div className="rounded-2xl bg-white p-6 shadow-sm dark:bg-gray-800">
              <label className="block text-sm font-semibold text-gray-700 dark:text-gray-200">
                Tranche marginale d'imposition
              </label>
              <select
                value={tmi}
                onChange={(event) => setTmi(Number(event.target.value))}
                className="mt-3 w-full rounded-xl border border-gray-300 bg-white px-4 py-3 text-lg text-gray-950 outline-none focus:border-green-600 dark:border-gray-600 dark:bg-gray-900 dark:text-white"
              >
                <option value={0}>0 %</option>
                <option value={11}>11 %</option>
                <option value={30}>30 %</option>
                <option value={41}>41 %</option>
                <option value={45}>45 %</option>
              </select>
              <p className="mt-2 text-xs leading-5 text-gray-500 dark:text-gray-400">
                {origin === 'france'
                  ? "Le calcul applique une approximation marginale sur le revenu simulé. La base fiscale réelle communiquée par la SCPI peut différer du montant distribué."
                  : "Hypothèse simplifiée Europe : IR estimé à la TMI et prélèvements sociaux français supposés non applicables. Le traitement réel dépend des pays détenus et des conventions fiscales."}
              </p>
            </div>

          </div>

          <div className="space-y-5">
            <div className="rounded-2xl bg-gray-950 p-6 text-white shadow-sm">
              <div className="flex items-center gap-2 text-sm font-semibold text-green-400">
                <Calculator className="h-5 w-5" />
                Résultat de la simulation
              </div>

              {taxEstimateAvailable && netAnnual !== null && netMonthly !== null ? (
                <>
                  <p className="mt-5 text-sm text-gray-300">Revenu annuel après fiscalité estimée</p>
                  <p className="mt-1 text-4xl font-bold">{formatEuro(netAnnual)}</p>
                  <p className="mt-2 text-lg text-gray-200">{formatEuro(netMonthly)} / mois en année pleine</p>
                  <p className="mt-3 text-xs leading-5 text-gray-400">
                    Sur la base d'un revenu brut de {formatEuro(calculations.fullYearGross)} et des seules hypothèses affichées.
                  </p>
                </>
              ) : (
                <>
                  <p className="mt-5 text-sm text-gray-300">Revenu brut annuel estimé</p>
                  <p className="mt-1 text-4xl font-bold">{formatEuro(calculations.fullYearGross)}</p>
                  <div className="mt-4 rounded-xl border border-slate-700 bg-slate-800/70 p-4 text-sm text-slate-200">
                    La fiscalité nette dépend des pays détenus par la SCPI et des conventions fiscales applicables. Le simulateur affiche donc ici uniquement le revenu brut.
                  </div>
                </>
              )}
            </div>

            {onRdvClick && amount >= 50000 && (
              <div className="rounded-2xl border border-green-500/30 bg-green-50 p-5 shadow-sm dark:border-green-500/30 dark:bg-green-950/20">
                <div className="flex items-center gap-4">
                  <EricAvatar size={64} className="shrink-0 ring-2 ring-green-500/30" />
                  <div>
                    <p className="text-sm font-semibold text-green-700 dark:text-green-400">Projet de 50 000 € ou plus ?</p>
                    <p className="mt-1 text-base font-bold text-gray-950 dark:text-white">
                      Faites analyser votre simulation par un conseiller MaximusSCPI.
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={onRdvClick}
                  className="mt-4 w-full rounded-xl bg-green-600 px-5 py-3.5 text-base font-bold text-white transition hover:bg-green-700"
                >
                  Faire analyser ma simulation
                </button>
                <p className="mt-2 text-center text-xs text-gray-500 dark:text-gray-400">
                  Analyse de la cohérence du projet et des SCPI adaptées à votre objectif.
                </p>
              </div>
            )}

            {onRdvClick && amount < 50000 && (
              <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-700 dark:bg-gray-800">
                <p className="text-sm font-semibold text-gray-950 dark:text-white">
                  Projet inférieur à 50 000 € ?
                </p>
                <p className="mt-1 text-sm leading-6 text-gray-600 dark:text-gray-300">
                  Comparez les SCPI et leurs principaux indicateurs avant d’aller plus loin.
                </p>
                <a
                  href="/comparateur-scpi/"
                  className="mt-4 inline-flex w-full items-center justify-center rounded-xl border border-gray-300 px-5 py-3.5 text-base font-bold text-gray-900 transition hover:bg-gray-50 dark:border-gray-600 dark:text-white dark:hover:bg-gray-700"
                >
                  Comparer les SCPI
                </a>
              </div>
            )}

            <div className="rounded-2xl bg-white p-6 shadow-sm dark:bg-gray-800">
              <h2 className="text-lg font-bold text-gray-950 dark:text-white">Comment est calculé votre revenu net ?</h2>
              <div className="mt-4 space-y-3 text-sm">
                <div className="flex justify-between gap-4">
                  <span className="text-gray-600 dark:text-gray-300">Revenus bruts annuels</span>
                  <strong className="text-gray-950 dark:text-white">{formatEuro(calculations.fullYearGross)}</strong>
                </div>

                <>
                  <div className="flex justify-between gap-4">
                    <span className="text-gray-600 dark:text-gray-300">IR estimatif au taux marginal ({tmi} %)</span>
                    <strong className="text-red-600">- {formatEuro(calculations.fullYearTax.ir || 0)}</strong>
                  </div>
                  <div className="flex justify-between gap-4">
                    <span className="text-gray-600 dark:text-gray-300">
                      {origin === 'france' ? 'Prélèvements sociaux (17,2 %)' : 'Prélèvements sociaux français (hypothèse)'}
                    </span>
                    <strong className={origin === 'france' ? 'text-red-600' : 'text-gray-950 dark:text-white'}>
                      {origin === 'france' ? '- ' : ''}{formatEuro(calculations.fullYearTax.socialContributions || 0)}
                    </strong>
                  </div>
                  <div className="flex justify-between gap-4 border-t border-gray-200 pt-3 dark:border-gray-700">
                    <span className="font-semibold text-gray-700 dark:text-gray-200">Revenu net annuel estimé</span>
                    <strong className="text-green-700 dark:text-green-400">{formatEuro(netAnnual || 0)}</strong>
                  </div>
                </>
              </div>
            </div>

            <div className="rounded-2xl bg-white p-6 shadow-sm dark:bg-gray-800">
              <h2 className="text-lg font-bold text-gray-950 dark:text-white">Première année</h2>
              <p className="mt-2 text-sm leading-6 text-gray-600 dark:text-gray-300">
                Avec un délai de jouissance de {delaiJouissanceMois} mois, la première année comprend {calculations.productiveMonths} mois productifs.
              </p>
              <p className="mt-3 text-3xl font-bold text-gray-950 dark:text-white">
                {firstYearNet !== null ? formatEuro(firstYearNet) : formatEuro(calculations.firstYearGross) + ' brut'}
              </p>
              <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
                Revenus estimés sur la première année de détention.
              </p>
            </div>

            <div className="rounded-2xl bg-white p-6 shadow-sm dark:bg-gray-800">
              <h2 className="flex items-center gap-2 text-lg font-bold text-gray-950 dark:text-white">
                <Calendar className="h-5 w-5 text-green-600" />
                Projection simple
              </h2>
              <div className="mt-4 flex items-center gap-3">
                {[10, 15, 20].map((years) => (
                  <button
                    type="button"
                    key={years}
                    onClick={() => setHorizon(years)}
                    className={`rounded-full px-4 py-2 text-sm font-semibold ${
                      horizon === years
                        ? 'bg-green-600 text-white'
                        : 'bg-gray-100 text-gray-700 dark:bg-gray-700 dark:text-gray-200'
                    }`}
                  >
                    {years} ans
                  </button>
                ))}
              </div>

              {calculations.cumulativeNet !== null ? (
                <div className="mt-5">
                  <p className="text-sm text-gray-600 dark:text-gray-300">
                    Revenus nets cumulés estimatifs sur {horizon} ans, sans réinvestissement
                  </p>
                  <p className="mt-1 text-3xl font-bold text-gray-950 dark:text-white">
                    {formatEuro(calculations.cumulativeNet)}
                  </p>
                </div>
              ) : (
                <div className="mt-5">
                  <p className="text-sm text-gray-600 dark:text-gray-300">
                    Revenus bruts cumulés estimatifs sur {horizon} ans, sans réinvestissement
                  </p>
                  <p className="mt-1 text-3xl font-bold text-gray-950 dark:text-white">
                    {formatEuro(calculations.cumulativeGross)}
                  </p>
                </div>
              )}
            </div>


            <div className="rounded-2xl border border-slate-200 bg-slate-50 p-5 text-sm leading-6 text-slate-700 dark:border-slate-700 dark:bg-slate-800/60 dark:text-slate-300">
              <div className="flex gap-3">
                <Info className="mt-0.5 h-5 w-5 shrink-0 text-sky-500" />
                <div>
                  <p className="font-semibold">Limites de la simulation</p>
                  <p className="mt-1">
                    {origin === 'france'
                      ? "Le calcul applique de façon pédagogique la TMI et 17,2 % de prélèvements sociaux au revenu brut simulé. La base imposable réelle de la SCPI, les charges déductibles, les intérêts d'emprunt, les éventuels revenus financiers et la situation du foyer peuvent modifier le résultat."
                      : "Pour simplifier la comparaison, le calcul Europe applique la TMI au revenu brut simulé et retient 0 % de prélèvements sociaux français. Cette hypothèse pédagogique ne reproduit pas les mécanismes précis des conventions fiscales, crédits d'impôt ou impositions étrangères."}
                  </p>
                  <p className="mt-2">
                    Les revenus et la valeur des parts de SCPI ne sont pas garantis. Il existe un risque de perte en capital et un risque de liquidité.
                  </p>
                </div>
              </div>
            </div>

            <div className="flex items-start gap-2 text-xs leading-5 text-gray-500 dark:text-gray-400">
              <Info className="mt-0.5 h-4 w-4 shrink-0" />
              <p>
                Simulation indicative et non contractuelle. Elle ne constitue pas une recommandation personnalisée ni une consultation fiscale.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ScpiDirectIncomeSimulator;
