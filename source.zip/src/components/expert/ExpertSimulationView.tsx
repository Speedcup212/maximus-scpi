import React, { useState, useEffect } from 'react';
import { ArrowLeft, TrendingUp, Euro, Calculator, Clock, ChevronDown, ChevronRight, Shield, Loader2, AlertCircle } from 'lucide-react';
import { getExpertSimulationById } from '../../utils/expertDossiersSupabase';
import type { ExpertSimulationSnapshot } from '../../types/expertDossier';

const formatSafeCurrency = (value: unknown): string => {
  if (value === null || value === undefined) return '—';
  const n = Number(value);
  if (!Number.isFinite(n)) return '—';
  return new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR', maximumFractionDigits: 0 }).format(n);
};

const fmtEuro = (v: unknown) => formatSafeCurrency(v);
const fmtPercent = (v: unknown) => {
  const n = Number(v);
  if (!Number.isFinite(n)) return '—';
  return new Intl.NumberFormat('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(n) + '\u202f%';
};
const fmtSafeNumber = (v: unknown): string => {
  const n = Number(v);
  if (!Number.isFinite(n)) return '—';
  return new Intl.NumberFormat('fr-FR').format(n);
};
const fmtDate = (iso: string) =>
  new Date(iso).toLocaleString('fr-FR', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });

interface ExpertSimulationViewProps {
  simulationId: string;
  onBack: () => void;
}

const ExpertSimulationView: React.FC<ExpertSimulationViewProps> = ({ simulationId, onBack }) => {
  const [sim, setSim] = useState<ExpertSimulationSnapshot | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [showProjections, setShowProjections] = useState(false);
  const [showHypotheses, setShowHypotheses] = useState(false);

  useEffect(() => {
    let cancelled = false;
    const load = async () => {
      setLoading(true);
      setError('');
      try {
        const s = await getExpertSimulationById(simulationId);
        if (!cancelled) {
          if (!s) {
            setError('Simulation introuvable.');
          } else {
            setSim(s);
          }
        }
      } catch (err: unknown) {
        if (!cancelled) {
          setError(err instanceof Error ? err.message : 'Impossible de charger la simulation.');
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    };
    load();
    return () => { cancelled = true; };
  }, [simulationId]);

  if (loading) {
    return (
      <div className="p-6 lg:p-10 max-w-6xl mx-auto">
        <div className="flex items-center justify-center py-20">
          <Loader2 className="w-8 h-8 text-blue-400 animate-spin" />
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-6 lg:p-10 max-w-6xl mx-auto">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-10 text-center">
          <AlertCircle className="w-8 h-8 text-red-400 mx-auto mb-3" />
          <p className="text-slate-500 mb-4">{error}</p>
          <button onClick={onBack} className="px-4 py-2 text-blue-400 text-sm hover:underline">Retour</button>
        </div>
      </div>
    );
  }

  if (!sim) {
    return (
      <div className="p-6 lg:p-10 max-w-6xl mx-auto">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-10 text-center">
          <p className="text-slate-500">Simulation introuvable.</p>
          <button onClick={onBack} className="mt-4 text-blue-400 text-sm hover:underline">Retour</button>
        </div>
      </div>
    );
  }

  const r = sim.results as Record<string, unknown>;
  const s = sim.summary;

  return (
    <div className="p-6 lg:p-10 max-w-6xl mx-auto">
      <button onClick={onBack} className="flex items-center gap-1 text-xs text-slate-500 hover:text-slate-300 transition-colors mb-6">
        <ArrowLeft className="w-3 h-3" /> Détail dossier
      </button>

      <div className="mb-6">
        <h1 className="text-2xl font-bold text-white">{sim.label}</h1>
        <p className="text-xs text-slate-500 mt-1">Enregistrée le {fmtDate(sim.createdAt)}</p>
      </div>

      {/* Synthèse KPI */}
      <div className="grid grid-cols-2 md:grid-cols-6 gap-3 mb-8">
        <Kpi label="Effort" value={fmtEuro(s.totalCashEffort)} color="blue" />
        <Kpi label="Trésorerie résid." value={fmtEuro(s.residualTreasury)} color="slate" />
        <Kpi label="Cash-flow A1" value={fmtEuro(s.yearOneNetCashFlow)} color="emerald" />
        <Kpi label="Impact IS A1" value={'+' + fmtEuro(s.yearOneTaxImpact)} color="orange" />
        <Kpi label="Rend. cash-flow" value={fmtPercent(s.cashFlowAverageReturn ?? s.averageAnnualNetYield)} color="amber" />
        <Kpi label="Flux op. cumulé" value={fmtEuro(s.cumulativeNetCashFlow)} color="emerald" />
        <Kpi label="Gain net après extinction" value={fmtEuro(s.gainNetAfterUsufructExtinction)} color="emerald" />
        <Kpi label="Rend. après extinction" value={fmtPercent(s.annualizedSimpleReturnAfterExtinction)} color="emerald" />
        {(s.recoverableVatAmount ?? s.nonRecoverableVatAmount) !== undefined && (
          <Kpi label="TVA récupérable" value={fmtEuro(s.recoverableVatAmount)} color="emerald" />
        )}
        {s.nonRecoverableVatAmount !== undefined && s.nonRecoverableVatAmount > 0 && (
          <Kpi label="TVA non récupérable" value={fmtEuro(s.nonRecoverableVatAmount)} color="orange" />
        )}
        {s.indicativeIrr !== undefined && s.indicativeIrr !== null && (
          <Kpi label="TRI indicatif" value={fmtPercent(s.indicativeIrr)} color="violet" />
        )}
        {s.indicativeIrr !== undefined && s.indicativeIrr === null && (
          <Kpi label="TRI indicatif" value="—" color="violet" />
        )}
        {s.alternativeAnnualNetYield !== undefined && s.alternativeAnnualNetYield > 0 && (
          <Kpi label="Altern. rendement net" value={fmtPercent(s.alternativeAnnualNetYield)} color="emerald" />
        )}
        {s.alternativeComparisonSpread !== undefined && (
          <Kpi label="Écart vs alternative" value={fmtEuro(s.alternativeComparisonSpread)} color={s.alternativeComparisonSpread >= 0 ? 'emerald' : 'orange'} />
        )}
      </div>

      {/* Comparatif avant / après */}
      {r.comparatif && (
        <div className="mb-8">
          <h2 className="text-sm font-bold text-white uppercase tracking-wider mb-4 flex items-center gap-2">
            <Calculator className="w-4 h-4 text-blue-400" /> Comparatif avant / après
          </h2>
          <ComparatifTable data={r.comparatif as ComparatifRow[]} />
        </div>
      )}

      {/* Projection annuelle */}
      {r.projections && (
        <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden mb-8">
          <button
            onClick={() => setShowProjections(!showProjections)}
            className="w-full flex items-center justify-between px-4 py-3 text-left hover:bg-slate-800/50 transition-colors"
          >
            <h2 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-emerald-400" /> Projection annuelle
            </h2>
            {showProjections ? <ChevronDown className="w-4 h-4 text-slate-500" /> : <ChevronRight className="w-4 h-4 text-slate-500" />}
          </button>
          {showProjections && (
            <div className="px-4 pb-4 overflow-x-auto">
              <ProjectionsTable projections={r.projections as ProjectionRow[]} />
            </div>
          )}
        </div>
      )}

      {/* Hypothèses */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden mb-8">
        <button
          onClick={() => setShowHypotheses(!showHypotheses)}
          className="w-full flex items-center justify-between px-4 py-3 text-left hover:bg-slate-800/50 transition-colors"
        >
          <h2 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <Shield className="w-4 h-4 text-amber-400" /> Hypothèses
          </h2>
          {showHypotheses ? <ChevronDown className="w-4 h-4 text-slate-500" /> : <ChevronRight className="w-4 h-4 text-slate-500" />}
        </button>
        {showHypotheses && (
          <div className="px-4 pb-4">
            <HypothesesBlock inputs={sim.inputs} />
          </div>
        )}
      </div>

      <div className="text-center">
        <p className="text-[10px] text-slate-600">
          Stockage sécurisé Supabase — synchronisé avec votre compte cabinet.
        </p>
      </div>
    </div>
  );
};

/* ── Sub‑components ── */

const colorMap: Record<string, string> = {
  emerald: 'text-emerald-400',
  blue: 'text-blue-400',
  orange: 'text-orange-400',
  slate: 'text-slate-400',
};

const Kpi: React.FC<{ label: string; value: string; color: string }> = ({ label, value, color }) => (
  <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-3">
    <span className="text-[10px] text-slate-500 uppercase tracking-wider font-semibold">{label}</span>
    <p className={`font-bold text-sm ${colorMap[color] || 'text-slate-200'}`}>{value}</p>
  </div>
);

interface ComparatifRow {
  label: string;
  avant: string;
  apres: string;
  impact: string;
  positive?: boolean;
}

const ComparatifTable: React.FC<{ data: ComparatifRow[] }> = ({ data }) => (
  <div className="overflow-x-auto">
    <table className="w-full text-left text-xs">
      <thead>
        <tr className="border-b border-slate-700 bg-slate-950/50">
          <th className="py-2 px-3 text-[10px] uppercase tracking-wider text-slate-500 font-semibold">Poste</th>
          <th className="py-2 px-3 text-[10px] uppercase tracking-wider text-slate-500 font-semibold text-right">Avant</th>
          <th className="py-2 px-3 text-[10px] uppercase tracking-wider text-slate-500 font-semibold text-right">Après</th>
          <th className="py-2 px-3 text-[10px] uppercase tracking-wider text-slate-500 font-semibold text-right">Impact</th>
        </tr>
      </thead>
      <tbody className="divide-y divide-slate-800/50">
        {data.map((row, i) => (
          <tr key={i} className={i % 2 === 0 ? 'bg-slate-900/30' : ''}>
            <td className="py-2 px-3 text-slate-300 font-medium">{row.label}</td>
            <td className="py-2 px-3 text-right text-slate-400">{row.avant}</td>
            <td className="py-2 px-3 text-right text-slate-300">{row.apres}</td>
            <td className={`py-2 px-3 text-right font-semibold ${row.positive !== undefined ? (row.positive ? 'text-emerald-400' : 'text-orange-400') : 'text-slate-300'}`}>
              {row.impact}
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  </div>
);

/** ProjectionRow matches the raw jsonb structure from HoldingISYearProjection */
interface ProjectionRow {
  year: number;
  grossIncome: number;
  amortization: number;
  feesFiscal?: number;
  feesCash?: number;
  fiscalResultOperationOnly: number;
  fiscalResultAfterOperation: number;
  isBeforeOperation: number;
  isAfterOperation: number;
  isImpact: number;
  netCashFlow: number;
  netCashFlowAfterFees: number;
  cumulativeNetCashFlow: number;
  cumulativeNetCashFlowAfterFees?: number;
}

const ProjectionsTable: React.FC<{ projections: ProjectionRow[] }> = ({ projections }) => (
  <table className="w-full text-left text-[11px]">
    <thead>
      <tr className="border-b border-slate-700">
        <th className="py-2 px-2 text-[10px] uppercase text-slate-500">Année</th>
        <th className="py-2 px-2 text-[10px] uppercase text-slate-500 text-right">Revenu brut</th>
        <th className="py-2 px-2 text-[10px] uppercase text-slate-500 text-right">Amort.</th>
        <th className="py-2 px-2 text-[10px] uppercase text-slate-500 text-right">IS avant</th>
        <th className="py-2 px-2 text-[10px] uppercase text-slate-500 text-right">IS après</th>
        <th className="py-2 px-2 text-[10px] uppercase text-slate-500 text-right">Impact IS</th>
        <th className="py-2 px-2 text-[10px] uppercase text-slate-500 text-right">Cash-flow</th>
        <th className="py-2 px-2 text-[10px] uppercase text-slate-500 text-right">Cumul</th>
      </tr>
    </thead>
    <tbody className="divide-y divide-slate-800/50">
      {projections.map((p) => (
        <tr key={p.year}>
          <td className="py-1.5 px-2 font-semibold text-slate-300">A{p.year}</td>
          <td className="py-1.5 px-2 text-right text-slate-400">{fmtEuro(p.grossIncome)}</td>
          <td className="py-1.5 px-2 text-right text-slate-400">{fmtEuro(p.amortization)}</td>
          <td className="py-1.5 px-2 text-right text-slate-400">{fmtEuro(p.isBeforeOperation)}</td>
          <td className="py-1.5 px-2 text-right text-slate-300">{fmtEuro(p.isAfterOperation)}</td>
          <td className="py-1.5 px-2 text-right text-orange-400 font-semibold">+{fmtEuro(p.isImpact)}</td>
          <td className="py-1.5 px-2 text-right text-emerald-400">{fmtEuro(p.netCashFlow)}</td>
          <td className="py-1.5 px-2 text-right text-emerald-400 font-semibold">{fmtEuro(p.cumulativeNetCashFlowAfterFees ?? p.cumulativeNetCashFlow)}</td>
        </tr>
      ))}
    </tbody>
  </table>
);

const HypothesesBlock: React.FC<{ inputs: Record<string, unknown> }> = ({ inputs }) => {
  const entries = Object.entries(inputs);
  if (entries.length === 0) return <p className="text-xs text-slate-500 py-4">Aucune hypothèse enregistrée.</p>;
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 gap-2 py-2">
      {entries.map(([key, value]) => (
        <div key={key} className="text-xs">
          <span className="text-slate-500">{key}: </span>
          <span className="text-slate-300">
            {typeof value === 'boolean' ? (value ? 'Oui' : 'Non') : typeof value === 'number' ? fmtSafeNumber(value) : String(value)}
          </span>
        </div>
      ))}
    </div>
  );
};

export default ExpertSimulationView;
