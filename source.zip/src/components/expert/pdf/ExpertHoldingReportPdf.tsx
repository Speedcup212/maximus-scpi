import React from 'react';
import {
  Document,
  Page,
  Text,
  View,
  StyleSheet,
} from '@react-pdf/renderer';
import type { HoldingISInputs, HoldingISResult } from '../../../utils/holdingSimulation';
import { getVerificationProfile } from '../../../utils/expertVerification';
import { getCurrentRoleFromCache } from '../../../utils/expertAccess';
import { formatDisplayName } from '../../../utils/formatters';

/* ── Helpers formatage ── */

/**
 * Normalise les espaces pour @react-pdf/renderer.
 * Intl.NumberFormat('fr-FR') produit des espaces insécables (\u202F, \u00A0)
 * qui ne sont pas rendus correctement par react-pdf (affichage de "/").
 * On les remplace par des espaces ASCII standards.
 */
const norm = (s: string): string => s.replace(/[\s\u202F\u00A0]/g, ' ');

const fmtEuro = (v: number | null | undefined): string => {
  if (v === null || v === undefined || !Number.isFinite(v)) return '\u2014 \u20AC';
  return norm(new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR', maximumFractionDigits: 0 }).format(v));
};

const fmtPercent = (v: number | null | undefined): string => {
  if (v === null || v === undefined || !Number.isFinite(v)) return '\u2014';
  return norm(new Intl.NumberFormat('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(v)) + ' %';
};

const fmtNumber = (v: number | null | undefined): string => {
  if (v === null || v === undefined || !Number.isFinite(v)) return '\u2014';
  return norm(new Intl.NumberFormat('fr-FR').format(v));
};

const fmtDate = () => {
  const now = new Date();
  return new Intl.DateTimeFormat('fr-FR', { day: '2-digit', month: 'long', year: 'numeric' }).format(now);
};

const FEES_TREATMENT_SHORT: Record<string, string> = {
  'not-integrated': 'Non intégré',
  'deductible-year1': 'Déductible année 1',
  'amortized': 'Amorti sur la durée',
  'non-deductible': 'Non déductible',
};

/* ── Helpers TVA safe ── */

/** Affiche le taux de récupération TVA de façon sûre — jamais "undefined". */
const formatVatRecoveryRate = (vatRecoveryRate: unknown): string => {
  const n = Number(vatRecoveryRate);
  if (!Number.isFinite(n)) return 'à qualifier';
  return fmtNumber(n) + ' %';
};

/** Libellé complet du profil TVA holding */
const formatHoldingVatProfile = (profile: string, vatRecoveryRate: unknown): string => {
  if (profile === 'pure') return 'Holding pure';
  if (profile === 'animator') return 'Holding animatrice';
  if (profile === 'mixed') {
    const n = Number(vatRecoveryRate);
    return Number.isFinite(n)
      ? `Holding mixte — ${fmtNumber(n)} % récupérable`
      : 'Holding mixte — taux de récupération TVA à qualifier';
  }
  return 'À qualifier';
};

/* ── Styles ── */

const colors = {
  dark: '#1a1a2e',
  primary: '#1e3a5f',
  accent: '#059669',
  orange: '#c2410c',
  light: '#f8fafc',
  muted: '#94a3b8',
  border: '#e2e8f0',
  rowAlt: '#f1f5f9',
};

const styles = StyleSheet.create({
  page: {
    backgroundColor: '#ffffff',
    paddingVertical: 28,
    paddingHorizontal: 36,
    fontFamily: 'Helvetica',
    fontSize: 10,
    color: '#1e293b',
  },
  pageLandscape: {
    backgroundColor: '#ffffff',
    padding: 30,
    fontFamily: 'Helvetica',
    fontSize: 9,
    color: '#1e293b',
  },
  header: {
    marginBottom: 6,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
    paddingBottom: 8,
  },
  headerTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 4,
  },
  headerTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: colors.primary,
    marginBottom: 1,
  },
  headerSubtitle: {
    fontSize: 10,
    color: colors.muted,
    marginBottom: 2,
  },
  headerMeta: {
    fontSize: 8,
    color: colors.muted,
    lineHeight: 1.5,
  },
  headerBadge: {
    fontSize: 7,
    color: colors.accent,
    backgroundColor: '#d1fae5',
    paddingHorizontal: 7,
    paddingVertical: 2,
    borderRadius: 4,
    alignSelf: 'flex-start',
    marginBottom: 3,
  },
  sectionTitle: {
    fontSize: 11,
    fontWeight: 'bold',
    color: colors.primary,
    marginBottom: 6,
    marginTop: 2,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
    paddingBottom: 4,
  },
  grid2: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 0,
    marginBottom: 4,
  },
  kpiRow: {
    flexDirection: 'row',
    marginBottom: 4,
  },
  kpiCard: {
    width: '48%',
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 4,
    paddingVertical: 5,
    paddingHorizontal: 8,
    marginBottom: 6,
    marginRight: '4%',
  },
  kpiCardLast: {
    width: '48%',
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 4,
    paddingVertical: 5,
    paddingHorizontal: 8,
    marginBottom: 6,
  },
  kpiLabel: {
    fontSize: 7,
    color: colors.muted,
    textTransform: 'uppercase',
    marginBottom: 2,
    fontWeight: 'bold',
  },
  kpiValue: {
    fontSize: 12,
    fontWeight: 'bold',
    color: colors.dark,
  },
  kpiValueGreen: {
    fontSize: 12,
    fontWeight: 'bold',
    color: colors.accent,
  },
  kpiValueOrange: {
    fontSize: 12,
    fontWeight: 'bold',
    color: colors.orange,
  },
  kpiSublabel: {
    fontSize: 7,
    color: '#94a3b8',
    marginTop: 1,
  },
  table: {
    marginBottom: 8,
  },
  tableHeader: {
    flexDirection: 'row',
    backgroundColor: colors.primary,
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 2,
  },
  tableHeaderCell: {
    color: '#ffffff',
    fontSize: 8,
    fontWeight: 'bold',
    textTransform: 'uppercase',
  },
  tableRow: {
    flexDirection: 'row',
    paddingVertical: 5,
    paddingHorizontal: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  tableRowAlt: {
    backgroundColor: colors.rowAlt,
  },
  tableCell: {
    fontSize: 8,
    color: colors.dark,
  },
  tableCellRight: {
    fontSize: 8,
    color: colors.dark,
    textAlign: 'right',
  },
  tableCellMuted: {
    fontSize: 8,
    color: colors.muted,
    textAlign: 'right',
  },
  tableCellGreen: {
    fontSize: 8,
    color: colors.accent,
    textAlign: 'right',
    fontWeight: 'bold',
  },
  tableCellOrange: {
    fontSize: 8,
    color: colors.orange,
    textAlign: 'right',
  },
  tableCellBold: {
    fontSize: 8,
    color: colors.dark,
    textAlign: 'right',
    fontWeight: 'bold',
  },
  opinionBox: {
    backgroundColor: '#f0f9ff',
    borderLeftWidth: 3,
    borderLeftColor: colors.primary,
    padding: 8,
    marginBottom: 8,
    borderRadius: 2,
  },
  opinionTitle: {
    fontSize: 10,
    fontWeight: 'bold',
    color: colors.primary,
    marginBottom: 5,
  },
  opinionItem: {
    fontSize: 8,
    color: '#334155',
    lineHeight: 1.4,
    marginBottom: 1,
  },
  infoBox: {
    backgroundColor: colors.rowAlt,
    padding: 8,
    marginBottom: 8,
    borderRadius: 2,
  },
  infoTitle: {
    fontSize: 10,
    fontWeight: 'bold',
    color: colors.primary,
    marginBottom: 5,
  },
  infoItem: {
    fontSize: 8,
    color: '#475569',
    lineHeight: 1.5,
    marginBottom: 1,
  },
  syntheseBox: {
    backgroundColor: '#f0f9ff',
    borderLeftWidth: 3,
    borderLeftColor: colors.primary,
    paddingVertical: 7,
    paddingHorizontal: 10,
    marginBottom: 10,
    borderRadius: 2,
  },
  syntheseTitle: {
    fontSize: 11,
    fontWeight: 'bold',
    color: colors.primary,
    marginBottom: 5,
  },
  syntheseText: {
    fontSize: 8,
    color: '#1e293b',
    lineHeight: 1.6,
  },
  conclusionText: {
    fontSize: 8,
    color: '#475569',
    lineHeight: 1.5,
    marginTop: 4,
  },
  hypothesesGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginBottom: 2,
  },
  hypothesesItem: {
    width: '31%',
    marginRight: '2%',
    marginBottom: 5,
    paddingVertical: 3,
    paddingHorizontal: 7,
    backgroundColor: '#f8fafc',
    borderRadius: 2,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  hypothesesLabel: {
    fontSize: 7,
    color: '#94a3b8',
    textTransform: 'uppercase',
    fontWeight: 'bold',
    marginBottom: 1,
  },
  hypothesesValue: {
    fontSize: 8,
    fontWeight: 'bold',
    color: '#334155',
  },
  detailTable: {
    marginBottom: 8,
  },
  detailTableRow: {
    flexDirection: 'row',
    paddingVertical: 3,
    paddingHorizontal: 8,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  detailTableRowAlt: {
    backgroundColor: colors.rowAlt,
  },
  detailTableLabel: {
    fontSize: 8,
    color: colors.dark,
    flex: 2,
    fontWeight: 'bold',
  },
  detailTableValue: {
    fontSize: 8,
    color: colors.dark,
    flex: 1.5,
    textAlign: 'right',
  },
  detailTableValueGreen: {
    fontSize: 8,
    color: colors.accent,
    flex: 1.5,
    textAlign: 'right',
    fontWeight: 'bold',
  },
  detailTableValueOrange: {
    fontSize: 8,
    color: colors.orange,
    flex: 1.5,
    textAlign: 'right',
    fontWeight: 'bold',
  },
  vigilanceBox: {
    backgroundColor: '#fff7ed',
    borderLeftWidth: 3,
    borderLeftColor: colors.orange,
    padding: 8,
    marginTop: 6,
    borderRadius: 2,
  },
  vigilanceTitle: {
    fontSize: 10,
    fontWeight: 'bold',
    color: colors.orange,
    marginBottom: 5,
  },
  vigilanceItem: {
    fontSize: 8,
    color: '#78350f',
    lineHeight: 1.4,
    marginBottom: 1,
  },
  visaBox: {
    marginTop: 12,
    paddingTop: 8,
    borderTopWidth: 2,
    borderTopColor: colors.primary,
  },
  visaTitle: {
    fontSize: 11,
    fontWeight: 'bold',
    color: colors.primary,
    marginBottom: 6,
  },
  visaText: {
    fontSize: 8,
    color: '#475569',
    lineHeight: 1.5,
    marginBottom: 6,
  },
  visaField: {
    fontSize: 8,
    color: '#334155',
    lineHeight: 1.8,
    marginBottom: 1,
  },
  vatBadge: {
    fontSize: 7,
    paddingHorizontal: 5,
    paddingVertical: 1,
    borderRadius: 3,
    alignSelf: 'flex-start',
    marginTop: 2,
  },
  disclaimer: {
    backgroundColor: '#fff7ed',
    borderLeftWidth: 3,
    borderLeftColor: colors.orange,
    padding: 8,
    marginTop: 6,
    borderRadius: 2,
  },
  disclaimerText: {
    fontSize: 7,
    color: '#78350f',
    lineHeight: 1.4,
  },
  footer: {
    position: 'absolute',
    bottom: 14,
    left: 36,
    right: 36,
    fontSize: 7,
    color: colors.muted,
    textAlign: 'center',
    borderTopWidth: 1,
    borderTopColor: colors.border,
    paddingTop: 5,
  },
  pageNumber: {
    position: 'absolute',
    bottom: 14,
    right: 36,
    fontSize: 7,
    color: colors.muted,
  },
});

/* ── Props ── */

interface ExpertHoldingReportPdfProps {
  inputs: HoldingISInputs;
  result: HoldingISResult;
  isSansOperation: number;
  /** Nom réel du dossier client (depuis Supabase). Prioritaire sur inputs.dossierName. */
  dossierName?: string;
  /** Affiche le badge "Mode admin — document de test" uniquement si explicitement demandé. */
  includeAdminTestBadge?: boolean;
}

/* ── Composant Document ── */

const ExpertHoldingReportPdf: React.FC<ExpertHoldingReportPdfProps> = ({
  inputs, result, isSansOperation, dossierName: dossierNameProp, includeAdminTestBadge = false,
}) => {
  const tresorerieResiduelle = inputs.availableCash - result.effortEconomique;

  /* Résolution du nom de dossier :
     1. dossierName prop (depuis Supabase)
     2. inputs.dossierName (saisi dans le simulateur)
     3. Fallback "Simulation Holding IS"
  */
  const resolvedDossierName = dossierNameProp || inputs.dossierName || 'Simulation Holding IS';
  const resolvedDossierDisplayName = formatDisplayName(resolvedDossierName);
  const dossierTitle = resolvedDossierName
    .replace(/[^a-zA-Z0-9\-_\s]/g, '')
    .replace(/\s+/g, '-')
    .substring(0, 50);
  const dossierFooterName = resolvedDossierDisplayName; // nom lisible dans le footer
  const verificationProfile = getVerificationProfile();
  const cabinetName = verificationProfile?.firmName || null;
  const isAdmin = getCurrentRoleFromCache() === 'admin';

  const headerFragment = (
    <View style={styles.header}>
      <View style={styles.headerTop}>
        <View>
          <Text style={styles.headerTitle}>Note de chiffrage Expert-Comptable</Text>
          <Text style={styles.headerSubtitle}>Société IS — Usufruit temporaire SCPI</Text>
        </View>
        <View>
          {isAdmin && includeAdminTestBadge ? (
            <>
              <Text style={{ ...styles.headerBadge, backgroundColor: '#7c3aed20', color: '#a78bfa' }}>Mode admin — document de test</Text>
            </>
          ) : (
            <>
              <Text style={styles.headerBadge}>Espace Expert-Comptable</Text>
              {cabinetName && (
                <Text style={{ fontSize: 7, color: '#64748b', marginTop: 4, textAlign: 'right' }}>
                  Cabinet : {cabinetName}
                </Text>
              )}
            </>
          )}
        </View>
      </View>
      <View style={styles.headerMeta}>
        <Text>Date : {fmtDate()}</Text>
        <Text>Dossier : {resolvedDossierDisplayName}</Text>
        <Text>Type de société : {inputs.companyType}</Text>
        <Text>Simulation indicative — validation cabinet requise</Text>
      </View>
    </View>
  );

  const footerFragment = (page: number) => (
    <>
      <Text style={styles.footer}>
        MaximusSCPI — Espace Expert-Comptable — {fmtDate()} — {dossierFooterName}
      </Text>
      <Text style={styles.pageNumber}>Page {page}</Text>
    </>
  );

  return (
    <Document
      title={`Rapport Holding IS – ${dossierTitle}`}
      author="MaximusSCPI – Espace Expert-Comptable"
      subject="Note de chiffrage — Société IS, Usufruit temporaire SCPI"
    >
      {/* ═══════════════════════════════════════════════════════
          PAGE 1 — Synthèse décisionnelle
          ═══════════════════════════════════════════════════════ */}
      <Page size="A4" style={styles.page} wrap={false}>
        {headerFragment}

        {/* Hypothèses principales retenues */}
        <Text style={styles.sectionTitle}>Hypothèses principales retenues</Text>
        <View style={styles.hypothesesGrid}>
          <View style={styles.hypothesesItem}>
            <Text style={styles.hypothesesLabel}>Type de société</Text>
            <Text style={styles.hypothesesValue}>{inputs.companyType}</Text>
          </View>
          <View style={styles.hypothesesItem}>
            <Text style={styles.hypothesesLabel}>Régime IS</Text>
            <Text style={styles.hypothesesValue}>
              {inputs.reducedRateEligible ? 'Taux réduit PME (15 % / 25 %)' : 'Taux normal (25 %)'}
            </Text>
          </View>
          <View style={styles.hypothesesItem}>
            <Text style={styles.hypothesesLabel}>Trésorerie disponible</Text>
            <Text style={styles.hypothesesValue}>{fmtEuro(inputs.availableCash)}</Text>
          </View>
          <View style={styles.hypothesesItem}>
            <Text style={styles.hypothesesLabel}>Usufruit investi</Text>
            <Text style={styles.hypothesesValue}>{fmtEuro(inputs.usufruitInvestment)}</Text>
          </View>
          <View style={styles.hypothesesItem}>
            <Text style={styles.hypothesesLabel}>Durée de l'usufruit</Text>
            <Text style={styles.hypothesesValue}>{inputs.usufruitDuration} ans</Text>
          </View>
          <View style={styles.hypothesesItem}>
            <Text style={styles.hypothesesLabel}>Clé d'usufruit</Text>
            <Text style={styles.hypothesesValue}>{fmtPercent(inputs.usufruitKeyPercent)}</Text>
          </View>
          <View style={styles.hypothesesItem}>
            <Text style={styles.hypothesesLabel}>Taux distribution brut</Text>
            <Text style={styles.hypothesesValue}>{fmtPercent(inputs.grossYieldRate)}</Text>
          </View>
          <View style={styles.hypothesesItem}>
            <Text style={styles.hypothesesLabel}>Revalorisation annuelle</Text>
            <Text style={styles.hypothesesValue}>{inputs.revalorizationRate} %</Text>
          </View>
          {inputs.feesEnabled && (
            <>
              <View style={styles.hypothesesItem}>
                <Text style={styles.hypothesesLabel}>Frais de mission HT</Text>
                <Text style={styles.hypothesesValue}>{fmtEuro(result.feesHT)}</Text>
              </View>
              <View style={styles.hypothesesItem}>
                <Text style={styles.hypothesesLabel}>TVA ({inputs.feesVatRate} %)</Text>
                <Text style={styles.hypothesesValue}>{fmtEuro(result.feesVAT)}</Text>
              </View>
              <View style={styles.hypothesesItem}>
                <Text style={styles.hypothesesLabel}>Profil TVA holding</Text>
                <Text style={styles.hypothesesValue}>
                  {inputs.holdingVatProfile === 'to-qualify'
                    ? 'À qualifier'
                    : inputs.holdingVatProfile === 'animator'
                      ? 'Holding animatrice'
                      : inputs.holdingVatProfile === 'pure'
                        ? 'Holding pure'
                        : 'Holding mixte'}
                </Text>
              </View>
              {/* TVA récupérable */}
              <View style={styles.hypothesesItem}>
                <Text style={styles.hypothesesLabel}>TVA récupérable retenue</Text>
                <Text style={result.recoverableVatAmount > 0
                  ? { ...styles.hypothesesValue, color: '#059669' }
                  : { ...styles.hypothesesValue, color: '#c2410c' }}>
                  {result.recoverableVatAmount > 0 ? fmtEuro(result.recoverableVatAmount) : '0 €'}
                </Text>
              </View>
              {/* TVA non récupérable (si applicable) */}
              {result.nonRecoverableVatAmount > 0 && (
                <View style={styles.hypothesesItem}>
                  <Text style={styles.hypothesesLabel}>TVA non récupérable</Text>
                  <Text style={{ ...styles.hypothesesValue, color: '#c2410c' }}>{fmtEuro(result.nonRecoverableVatAmount)}</Text>
                </View>
              )}
              {/* Taux récupération mixte */}
              {inputs.holdingVatProfile === 'mixed' && (
                <View style={{ ...styles.hypothesesItem, width: '64%' }}>
                  <Text style={styles.hypothesesLabel}>Taux de récupération TVA</Text>
                  <Text style={styles.hypothesesValue}>{formatVatRecoveryRate(inputs.vatRecoveryRate)}</Text>
                </View>
              )}
              {/* Vigilance selon profil */}
              {inputs.holdingVatProfile === 'to-qualify' && (
                <View style={{ ...styles.hypothesesItem, width: '64%' }}>
                  <Text style={styles.hypothesesLabel}>Vigilance TVA</Text>
                  <Text style={{ ...styles.hypothesesValue, fontSize: 7, color: '#c2410c' }}>
                    Droit à récupération TVA à valider par le cabinet.
                  </Text>
                </View>
              )}
              {inputs.holdingVatProfile === 'animator' && (
                <View style={{ ...styles.hypothesesItem, width: '64%' }}>
                  <Text style={styles.hypothesesLabel}>Vigilance TVA</Text>
                  <Text style={{ ...styles.hypothesesValue, fontSize: 7 }}>
                    Récupération sous réserve d'activité économique taxable.
                  </Text>
                </View>
              )}
              {inputs.holdingVatProfile === 'pure' && (
                <View style={{ ...styles.hypothesesItem, width: '64%' }}>
                  <Text style={styles.hypothesesLabel}>Vigilance TVA</Text>
                  <Text style={{ ...styles.hypothesesValue, fontSize: 7, color: '#c2410c' }}>
                    Holding pure : TVA non récupérable intégrée à l'effort économique.
                  </Text>
                </View>
              )}
              <View style={{ ...styles.hypothesesItem, width: '64%' }}>
                <Text style={styles.hypothesesLabel}>Traitement frais de mission</Text>
                <Text style={styles.hypothesesValue}>{FEES_TREATMENT_SHORT[inputs.feesTreatment]}</Text>
              </View>
            </>
          )}
        </View>

        {/* Synthèse de l'opération */}
        <View style={styles.syntheseBox}>
          <Text style={styles.syntheseTitle}>Synthèse de l'opération</Text>
          <Text style={styles.syntheseText}>
            La société mobilise {fmtEuro(result.effortEconomique)} au démarrage, incluant l'usufruit et les frais de mission HT.
          </Text>
          <Text style={styles.syntheseText}>
            Trésorerie résiduelle théorique après opération : {fmtEuro(tresorerieResiduelle)}.
          </Text>
          <Text style={styles.syntheseText}>
            Le flux net de lancement après frais de mission isolés ressort à {fmtEuro(result.annualNetCashFlowAfterFees)} en année 1.
          </Text>
          <Text style={styles.syntheseText}>
            Impact IS année 1 : {result.annualISImpact >= 0 ? '+' : ''}{fmtEuro(result.annualISImpact)}.
          </Text>
          <Text style={styles.syntheseText}>
            Les flux opérationnels cumulés sur {inputs.usufruitDuration} ans ressortent à {fmtEuro(result.economicCumulativeNetCashFlow)}.
          </Text>
          <Text style={styles.syntheseText}>
            Le gain économique après extinction ressort à {fmtEuro(result.gainNetAfterUsufructExtinction)}, calculé sur les flux opérationnels cumulés moins l'effort initial.
          </Text>
          <Text style={styles.syntheseText}>
            Rendement cash-flow moyen annuel : {fmtPercent(result.cashFlowAverageReturn)} (flux net moyen / effort initial).
          </Text>
          {result.indicativeIrr !== null && (
            <Text style={styles.syntheseText}>
              TRI indicatif après extinction : {fmtPercent(result.indicativeIrr)} (flux opérationnels annuels, sans valeur résiduelle).
            </Text>
          )}
          <Text style={{ ...styles.syntheseText, fontStyle: 'italic', color: '#64748b', marginTop: 2 }}>
            Le TRI est indicatif. Il dépend des hypothèses de flux et ne constitue pas une recommandation d'investissement.
          </Text>
          <Text style={{ ...styles.syntheseText, marginTop: 3, paddingTop: 3, borderTopWidth: 1, borderTopColor: '#cbd5e1' }}>
            Le flux de lancement cumulé après frais ressort à {fmtEuro(result.cumulativeNetCashFlowAfterFees)}. Il est présenté à titre de lecture de trésorerie mais n'est pas retenu comme base du gain économique afin d'éviter un double comptage des frais déjà inclus dans l'effort initial.
          </Text>
        </View>

        {/* Vue synthétique */}
        <Text style={styles.sectionTitle}>Vue synthétique</Text>
        <View style={styles.kpiRow}>
          <View style={styles.kpiCard}>
            <Text style={styles.kpiLabel}>Effort initial total</Text>
            <Text style={styles.kpiValue}>{fmtEuro(result.effortEconomique)}</Text>
            <Text style={styles.kpiSublabel}>Dont frais de mission au démarrage</Text>
          </View>
          <View style={styles.kpiCardLast}>
            <Text style={styles.kpiLabel}>Trésorerie résiduelle</Text>
            <Text style={tresorerieResiduelle >= 0 ? styles.kpiValueGreen : styles.kpiValueOrange}>
              {fmtEuro(tresorerieResiduelle)}
            </Text>
          </View>
        </View>
        <View style={styles.kpiRow}>
          <View style={styles.kpiCard}>
            <Text style={styles.kpiLabel}>Flux net année 1</Text>
            <Text style={result.annualNetCashFlowAfterFees >= 0 ? styles.kpiValueGreen : styles.kpiValueOrange}>
              {fmtEuro(result.annualNetCashFlowAfterFees)}
            </Text>
            <Text style={styles.kpiSublabel}>Après frais de mission initiaux</Text>
          </View>
          <View style={styles.kpiCardLast}>
            <Text style={styles.kpiLabel}>Impact IS année 1</Text>
            <Text style={styles.kpiValueOrange}>
              {result.annualISImpact >= 0 ? '+' : ''}{fmtEuro(result.annualISImpact)}
            </Text>
          </View>
        </View>
        <View style={styles.kpiRow}>
          <View style={styles.kpiCard}>
            <Text style={styles.kpiLabel}>Rendement cash-flow moyen</Text>
            <Text style={result.cashFlowAverageReturn >= 0 ? styles.kpiValueGreen : styles.kpiValueOrange}>
              {fmtPercent(result.cashFlowAverageReturn)}
            </Text>
            <Text style={styles.kpiSublabel}>Flux net moyen / effort initial</Text>
          </View>
          <View style={styles.kpiCardLast}>
            <Text style={styles.kpiLabel}>Flux de lancement cumulé</Text>
            <Text style={styles.kpiValueGreen}>{fmtEuro(result.cumulativeNetCashFlowAfterFees)}</Text>
            <Text style={styles.kpiSublabel}>Après frais de mission isolés en année 1</Text>
          </View>
        </View>
        <View style={styles.kpiRow}>
          <View style={styles.kpiCard}>
            <Text style={styles.kpiLabel}>Flux opérationnel cumulé</Text>
            <Text style={styles.kpiValueGreen}>{fmtEuro(result.economicCumulativeNetCashFlow)}</Text>
            <Text style={styles.kpiSublabel}>Base du gain économique et du TRI</Text>
          </View>
          <View style={styles.kpiCardLast}>
            <Text style={styles.kpiLabel}>Gain économique après extinction</Text>
            <Text style={result.gainNetAfterUsufructExtinction >= 0 ? styles.kpiValueGreen : styles.kpiValueOrange}>
              {fmtEuro(result.gainNetAfterUsufructExtinction)}
            </Text>
            <Text style={styles.kpiSublabel}>Flux opérationnel cumulé – effort initial</Text>
          </View>
        </View>
        <View style={styles.kpiRow}>
          <View style={styles.kpiCard}>
            <Text style={styles.kpiLabel}>Rendement simple après extinction</Text>
            <Text style={result.annualizedSimpleReturnAfterExtinction >= 0 ? styles.kpiValueGreen : styles.kpiValueOrange}>
              {fmtPercent(result.annualizedSimpleReturnAfterExtinction)}
            </Text>
            <Text style={styles.kpiSublabel}>/ an</Text>
          </View>
          <View style={styles.kpiCardLast}>
            <Text style={styles.kpiLabel}>TRI indicatif après extinction</Text>
            <Text style={result.indicativeIrr !== null && result.indicativeIrr >= 0 ? styles.kpiValueGreen : styles.kpiValueOrange}>
              {result.indicativeIrr !== null ? fmtPercent(result.indicativeIrr) : '—'}
            </Text>
            <Text style={styles.kpiSublabel}>Flux nets annuels, sans valeur résiduelle</Text>
          </View>
        </View>

        {/* Conclusion courte */}
        <Text style={styles.conclusionText}>
          L'opération génère un résultat fiscal additionnel de {fmtEuro(result.annualFiscalResultOperationOnly)} la première année.{' '}
          Le flux de lancement cumulé après frais ressort à {fmtEuro(result.cumulativeNetCashFlowAfterFees)}.{' '}
          Les flux opérationnels cumulés ressortent à {fmtEuro(result.economicCumulativeNetCashFlow)}, base retenue pour le gain économique après extinction de {fmtEuro(result.gainNetAfterUsufructExtinction)}.{' '}
          L'usufruit temporaire s'éteint sans valeur résiduelle à l'échéance.{' '}
          Validation comptable et fiscale requise avant toute présentation client.
        </Text>

        {footerFragment(1)}
      </Page>

      {/* ═══════════════════════════════════════════════════════
          PAGE 2 — Analyse fiscale année 1
          ═══════════════════════════════════════════════════════ */}
      <Page size="A4" style={styles.page} wrap={false}>
        <Text style={styles.sectionTitle}>Analyse fiscale année 1</Text>

        {/* Frais de mission et TVA — tableau compact */}
        {inputs.feesEnabled && result.feesHT > 0 && (
          <>
            <Text style={{ ...styles.sectionTitle, fontSize: 10, borderBottomWidth: 0, marginBottom: 3 }}>
              Frais de mission et TVA
            </Text>
            <View style={styles.detailTable}>
              <View style={styles.detailTableRow}>
                <Text style={styles.detailTableLabel}>Frais de mission HT</Text>
                <Text style={styles.detailTableValue}>{fmtEuro(result.feesHT)}</Text>
              </View>
              <View style={{ ...styles.detailTableRow, ...styles.detailTableRowAlt }}>
                <Text style={styles.detailTableLabel}>TVA ({inputs.feesVatRate} %)</Text>
                <Text style={styles.detailTableValue}>{fmtEuro(result.feesVAT)}</Text>
              </View>
              <View style={styles.detailTableRow}>
                <Text style={styles.detailTableLabel}>Frais de mission TTC</Text>
                <Text style={styles.detailTableValue}>{fmtEuro(result.feesTTC)}</Text>
              </View>
              <View style={{ ...styles.detailTableRow, ...styles.detailTableRowAlt }}>
                <Text style={styles.detailTableLabel}>TVA récupérable</Text>
                <Text style={result.recoverableVatAmount > 0 ? styles.detailTableValueGreen : styles.detailTableValueOrange}>
                  {result.recoverableVatAmount > 0 ? `${fmtEuro(result.recoverableVatAmount)}` : 'Non'}
                </Text>
              </View>
              {result.nonRecoverableVatAmount > 0 && (
                <View style={styles.detailTableRow}>
                  <Text style={styles.detailTableLabel}>TVA non récupérable</Text>
                  <Text style={styles.detailTableValueOrange}>{fmtEuro(result.nonRecoverableVatAmount)}</Text>
                </View>
              )}
              <View style={{ ...styles.detailTableRow, ...styles.detailTableRowAlt }}>
                <Text style={styles.detailTableLabel}>Traitement fiscal/comptable retenu</Text>
                <Text style={styles.detailTableValue}>{FEES_TREATMENT_SHORT[inputs.feesTreatment]}</Text>
              </View>
            </View>
          </>
        )}

        {/* Détail résultat fiscal et IS — année 1 */}
        <Text style={styles.sectionTitle}>Détail résultat fiscal et IS — année 1</Text>
        <View style={styles.detailTable}>
          <View style={styles.detailTableRow}>
            <Text style={styles.detailTableLabel}>Résultat fiscal avant opération</Text>
            <Text style={styles.detailTableValue}>{fmtEuro(inputs.preTaxProfit)}</Text>
          </View>
          <View style={{ ...styles.detailTableRow, ...styles.detailTableRowAlt }}>
            <Text style={styles.detailTableLabel}>Résultat fiscal de l'opération</Text>
            <Text style={styles.detailTableValue}>{fmtEuro(result.annualFiscalResultOperationOnly)}</Text>
          </View>
          <View style={styles.detailTableRow}>
            <Text style={styles.detailTableLabel}>Résultat fiscal après opération</Text>
            <Text style={styles.detailTableValue}>{fmtEuro(result.annualFiscalResultAfterOperation)}</Text>
          </View>
          <View style={{ ...styles.detailTableRow, ...styles.detailTableRowAlt }}>
            <Text style={styles.detailTableLabel}>IS sans opération</Text>
            <Text style={styles.detailTableValue}>{fmtEuro(isSansOperation)}</Text>
          </View>
          <View style={styles.detailTableRow}>
            <Text style={styles.detailTableLabel}>IS avec opération</Text>
            <Text style={styles.detailTableValueOrange}>{fmtEuro(result.annualISAfterOperation)}</Text>
          </View>
          <View style={{ ...styles.detailTableRow, ...styles.detailTableRowAlt }}>
            <Text style={styles.detailTableLabel}>Impact IS net</Text>
            <Text style={styles.detailTableValueOrange}>
              {result.annualISImpact >= 0 ? '+' : ''}{fmtEuro(result.annualISImpact)}
            </Text>
          </View>
          <View style={styles.detailTableRow}>
            <Text style={styles.detailTableLabel}>Revenus bruts annuels SCPI</Text>
            <Text style={styles.detailTableValue}>{fmtEuro(result.annualGrossIncome)}</Text>
          </View>
          <View style={{ ...styles.detailTableRow, ...styles.detailTableRowAlt }}>
            <Text style={styles.detailTableLabel}>Amortissement annuel usufruit</Text>
            <Text style={styles.detailTableValue}>{fmtEuro(result.annualAmortization)}</Text>
          </View>
          <View style={styles.detailTableRow}>
            <Text style={styles.detailTableLabel}>Frais de mission — année 1</Text>
            <Text style={styles.detailTableValue}>{fmtEuro(result.feesFiscalYear1)}</Text>
          </View>
        </View>

        {/* Lecture fiscale */}
        <View style={styles.opinionBox}>
          <Text style={styles.opinionTitle}>Lecture fiscale</Text>
          <Text style={styles.opinionItem}>
            Résultat fiscal avant opération : {fmtEuro(inputs.preTaxProfit)}.
          </Text>
          <Text style={styles.opinionItem}>
            Résultat fiscal additionnel généré par l'opération : {fmtEuro(result.annualFiscalResultOperationOnly)}.
          </Text>
          <Text style={styles.opinionItem}>
            Résultat fiscal après opération : {fmtEuro(result.annualFiscalResultAfterOperation)}.
          </Text>
          <Text style={styles.opinionItem}>
            IS additionnel année 1 : {result.annualISImpact >= 0 ? '+' : ''}{fmtEuro(result.annualISImpact)}.
          </Text>
          <Text style={styles.opinionItem}>
            L'amortissement de l'usufruit réduit la base taxable de {fmtEuro(result.annualAmortization)} par an.
          </Text>
          {inputs.feesEnabled && (
            <Text style={styles.opinionItem}>
              Les frais de mission sont traités selon l'option retenue dans les hypothèses : {FEES_TREATMENT_SHORT[inputs.feesTreatment].toLowerCase()}.
            </Text>
          )}
          {inputs.reducedRateEligible && inputs.preTaxProfit >= 42500 && (
            <Text style={{ ...styles.opinionItem, color: '#c2410c', marginTop: 2 }}>
              La tranche d'IS à taux réduit étant déjà consommée par le résultat fiscal initial, le résultat additionnel est imposé au taux marginal applicable.
            </Text>
          )}
        </View>

        {footerFragment(2)}
      </Page>

      {/* ═══════════════════════════════════════════════════════
          PAGE 3 — Comparatif avant / après
          ═══════════════════════════════════════════════════════ */}
      <Page size="A4" style={styles.page} wrap={false}>
        <Text style={styles.sectionTitle}>Comparatif avant / après opération (année 1)</Text>

        <View style={styles.table}>
          <View style={styles.tableHeader}>
            <Text style={{ ...styles.tableHeaderCell, width: '40%' }}>Indicateur</Text>
            <Text style={{ ...styles.tableHeaderCell, width: '20%', textAlign: 'right' }}>Sans opération</Text>
            <Text style={{ ...styles.tableHeaderCell, width: '20%', textAlign: 'right' }}>Avec opération</Text>
            <Text style={{ ...styles.tableHeaderCell, width: '20%', textAlign: 'right' }}>Montant / Impact</Text>
          </View>

          <View style={styles.tableRow}>
            <Text style={{ ...styles.tableCell, width: '40%' }}>Résultat fiscal société</Text>
            <Text style={{ ...styles.tableCellMuted, width: '20%' }}>{fmtNumber(inputs.preTaxProfit)} €</Text>
            <Text style={{ ...styles.tableCell, width: '20%', textAlign: 'right' }}>{fmtNumber(result.annualFiscalResultAfterOperation)} €</Text>
            <Text style={{ ...styles.tableCellBold, width: '20%' }}>+{fmtNumber(result.annualFiscalResultAfterOperation - inputs.preTaxProfit)} €</Text>
          </View>

          <View style={{ ...styles.tableRow, ...styles.tableRowAlt }}>
            <Text style={{ ...styles.tableCell, width: '40%' }}>IS estimé</Text>
            <Text style={{ ...styles.tableCellMuted, width: '20%' }}>{fmtNumber(isSansOperation)} €</Text>
            <Text style={{ ...styles.tableCell, width: '20%', textAlign: 'right' }}>{fmtNumber(result.annualISAfterOperation)} €</Text>
            <Text style={{ ...styles.tableCellOrange, width: '20%', fontWeight: 'bold' }}>
              {result.annualISImpact >= 0 ? '+' : ''}{fmtNumber(result.annualISImpact)} €
            </Text>
          </View>

          <View style={styles.tableRow}>
            <Text style={{ ...styles.tableCell, width: '40%' }}>Revenus bruts SCPI</Text>
            <Text style={{ ...styles.tableCellMuted, width: '20%' }}>0 €</Text>
            <Text style={{ ...styles.tableCell, width: '20%', textAlign: 'right' }}>{fmtNumber(result.annualGrossIncome)} €</Text>
            <Text style={{ ...styles.tableCellBold, width: '20%' }}>+{fmtNumber(result.annualGrossIncome)} €</Text>
          </View>

          <View style={{ ...styles.tableRow, ...styles.tableRowAlt }}>
            <Text style={{ ...styles.tableCell, width: '40%' }}>Charge déductible : amort. usufruit</Text>
            <Text style={{ ...styles.tableCellMuted, width: '20%' }}>0 €</Text>
            <Text style={{ ...styles.tableCell, width: '20%', textAlign: 'right' }}>{fmtNumber(result.annualAmortization)} €</Text>
            <Text style={{ ...styles.tableCellOrange, width: '20%' }}>Charge retenue : {fmtNumber(result.annualAmortization)} €</Text>
          </View>

          {inputs.feesEnabled && result.feesFiscalYear1 > 0 && (
            <View style={styles.tableRow}>
              <Text style={{ ...styles.tableCell, width: '40%' }}>Frais de mission — année 1</Text>
              <Text style={{ ...styles.tableCellMuted, width: '20%' }}>0 €</Text>
              <Text style={{ ...styles.tableCell, width: '20%', textAlign: 'right' }}>{fmtNumber(result.feesFiscalYear1)} €</Text>
              <Text style={{ ...styles.tableCellOrange, width: '20%' }}>Charge retenue : {fmtNumber(result.feesFiscalYear1)} €</Text>
            </View>
          )}

          <View style={{ ...styles.tableRow, backgroundColor: '#d1fae5' }}>
            <Text style={{ ...styles.tableCell, width: '40%', fontWeight: 'bold' }}>Flux net société (après frais de mission)</Text>
            <Text style={{ ...styles.tableCellMuted, width: '20%' }}>0 €</Text>
            <Text style={{ ...styles.tableCell, width: '20%', textAlign: 'right', fontWeight: 'bold' }}>{fmtNumber(result.annualNetCashFlowAfterFees)} €</Text>
            <Text style={{ ...styles.tableCellGreen, width: '20%' }}>+{fmtNumber(result.annualNetCashFlowAfterFees)} €</Text>
          </View>
        </View>

        {/* Lecture comptable courte */}
        <View style={styles.opinionBox}>
          <Text style={styles.opinionTitle}>Lecture comptable</Text>
          <Text style={styles.opinionItem}>
            L'effort initial total de {fmtEuro(result.effortEconomique)} intègre l'usufruit et les frais de mission payés au démarrage.
          </Text>
          <Text style={styles.opinionItem}>
            Après prise en compte des revenus générés et de l'impact IS, le flux net année 1 ressort à {fmtEuro(result.annualNetCashFlowAfterFees)}.
          </Text>
          <Text style={styles.opinionItem}>
            Le rendement cash-flow moyen annuel de {fmtPercent(result.cashFlowAverageReturn)} sur {inputs.usufruitDuration} ans mesure le rapport entre les flux nets moyens et l'effort initial.
          </Text>
          {inputs.feesEnabled && (
            <Text style={styles.opinionItem}>
              Frais de mission : {fmtEuro(result.feesHT)} HT + {fmtEuro(result.feesVAT)} TVA = {fmtEuro(result.feesTTC)} TTC
              {inputs.holdingVatProfile === 'mixed'
                ? ` (TVA récupérable partielle : ${formatVatRecoveryRate(inputs.vatRecoveryRate)})`
                : inputs.holdingVatProfile === 'pure'
                  ? ' (TVA non récupérable — holding pure)'
                  : result.recoverableVatAmount > 0 ? ' (TVA récupérable)' : ' (TVA non récupérable)'}.
            </Text>
          )}
        </View>

        {/* Lecture économique après extinction */}
        <View style={{ ...styles.opinionBox, marginTop: 8 }}>
          <Text style={styles.opinionTitle}>Lecture économique après extinction de l'usufruit</Text>
          <Text style={styles.opinionItem}>
            Flux opérationnels encaissés sur {inputs.usufruitDuration} ans : {fmtEuro(result.economicCumulativeNetCashFlow)}.
          </Text>
          <Text style={styles.opinionItem}>
            Flux de lancement cumulé après frais de mission : {fmtEuro(result.cumulativeNetCashFlowAfterFees)}.
          </Text>
          <Text style={styles.opinionItem}>
            Effort initial total : {fmtEuro(result.effortEconomique)} (usufruit + frais de mission HT).
          </Text>
          <Text style={styles.opinionItem}>
            Gain économique après extinction de l'usufruit : {fmtEuro(result.gainNetAfterUsufructExtinction)}.
          </Text>
          <Text style={styles.opinionItem}>
            Rendement cash-flow moyen annuel : {fmtPercent(result.cashFlowAverageReturn)}.
          </Text>
          {result.indicativeIrr !== null && (
            <Text style={styles.opinionItem}>
              TRI indicatif après extinction : {fmtPercent(result.indicativeIrr)}.
            </Text>
          )}
          <Text style={styles.opinionItem}>
            Rendement simple après extinction : {fmtPercent(result.annualizedSimpleReturnAfterExtinction)} / an.
          </Text>
          <Text style={styles.opinionItem}>
            L'usufruit temporaire s'éteint sans valeur résiduelle à l'échéance.
          </Text>
          <Text style={{ ...styles.opinionItem, color: '#64748b', fontStyle: 'italic', marginTop: 2 }}>
            Le flux de lancement cumulé après frais de mission est distinct du flux opérationnel cumulé. Le gain économique et le TRI sont calculés sur les flux opérationnels afin d'éviter de déduire deux fois les frais déjà intégrés dans l'effort initial.
          </Text>
          <Text style={{ ...styles.opinionItem, color: '#64748b', fontStyle: 'italic' }}>
            Ce rendement cash-flow moyen ne constitue pas un TRI. Le TRI est indicatif et dépend des hypothèses de flux — il ne constitue pas une recommandation d'investissement.
          </Text>
        </View>

        {/* ── Comparaison trésorerie alternative ── */}
        {inputs.alternativeType && inputs.alternativeGrossRate && inputs.alternativeGrossRate > 0 && (
          <View style={{ ...styles.opinionBox, marginTop: 8, backgroundColor: '#ecfdf5', borderLeftColor: '#059669' }}>
            <Text style={{ ...styles.opinionTitle, color: '#059669' }}>Comparaison trésorerie alternative</Text>
            <Text style={styles.opinionItem}>
              {inputs.alternativeType === 'compte_terme' ? 'Compte à terme'
                : inputs.alternativeType === 'fonds_monetaire' ? 'Fonds monétaire'
                : 'Taux personnalisé'} — taux annuel {inputs.alternativeRateMode === 'brut' ? 'brut avant IS' : 'net d\'IS'} : {String(inputs.alternativeGrossRate ?? '').replace('.', ',')} %.
            </Text>
            <Text style={styles.opinionItem}>
              Rendement net estimé : {fmtPercent(result.alternativeAnnualNetYield)} / an.
            </Text>
            <Text style={styles.opinionItem}>
              Gain net cumulé sur {inputs.usufruitDuration} ans : {fmtEuro(result.alternativeCumulativeNetIncome)}.
            </Text>
            <Text style={styles.opinionItem}>
              Capital final conservé : {fmtEuro(result.alternativeEndingCapital)}.
            </Text>
            <Text style={styles.opinionItem}>
              Valeur totale après {inputs.usufruitDuration} ans : {fmtEuro(result.alternativeTotalValue)}.
            </Text>
            <Text style={{ ...styles.opinionItem, fontWeight: 'bold', marginTop: 2 }}>
              Écart avec l'usufruit : {result.alternativeComparisonSpread >= 0
                ? `+${fmtEuro(result.alternativeComparisonSpread)} en faveur de l'usufruit`
                : `${fmtEuro(Math.abs(result.alternativeComparisonSpread))} en faveur de l'alternative`}.
            </Text>
            <Text style={{ ...styles.opinionItem, color: '#64748b', fontStyle: 'italic', marginTop: 2 }}>
              L'alternative conserve le capital. L'usufruit s'éteint sans valeur résiduelle. La comparaison porte sur les flux nets et le capital final. Les hypothèses de taux sont saisies par le cabinet.
            </Text>
          </View>
        )}

        {/* Points de vigilance */}
        <View style={styles.vigilanceBox}>
          <Text style={styles.vigilanceTitle}>Points de vigilance</Text>
          <Text style={styles.vigilanceItem}>• L'usufruit temporaire s'éteint sans valeur résiduelle à l'échéance.</Text>
          <Text style={styles.vigilanceItem}>• Le rendement cash-flow moyen ne constitue pas un TRI. Il doit être lu avec l'extinction de l'usufruit à l'échéance.</Text>
          <Text style={styles.vigilanceItem}>• Les revenus futurs des SCPI ne sont pas garantis et dépendent du marché immobilier.</Text>
          <Text style={styles.vigilanceItem}>• La fiscalité IS dépend de la structure juridique et de l'éligibilité au taux réduit.</Text>
          {inputs.feesEnabled && (
            <>
              <Text style={styles.vigilanceItem}>• Le traitement fiscal des frais de mission doit être validé selon la nature de la facture et le régime TVA de la société.</Text>
              <Text style={styles.vigilanceItem}>• Le droit à récupération de TVA dépend du statut de la holding : pure, animatrice ou mixte.</Text>
              {inputs.holdingVatProfile === 'mixed' && (
                <Text style={styles.vigilanceItem}>• En cas de holding mixte, le taux de récupération TVA doit être documenté selon le coefficient de taxation applicable.</Text>
              )}
              {inputs.holdingVatProfile === 'to-qualify' && (
                <Text style={styles.vigilanceItem}>• Le profil TVA de la holding reste à qualifier avant validation de la récupération de TVA.</Text>
              )}
              {inputs.holdingVatProfile === 'pure' && (
                <Text style={styles.vigilanceItem}>• Holding pure : la TVA non récupérable doit être intégrée dans l'effort économique.</Text>
              )}
            </>
          )}
          <Text style={styles.vigilanceItem}>• Ce document constitue une note de travail, pas un conseil fiscal engageant.</Text>
        </View>

        {/* ── Contrôles cabinet ── */}
        {result.cabinetChecks && result.cabinetChecks.length > 0 && (
          <View style={{ ...styles.infoBox, marginTop: 6, backgroundColor: '#fef3c7', borderLeftColor: '#d97706' }}>
            <Text style={{ ...styles.infoTitle, color: '#92400e' }}>Contrôles cabinet</Text>
            {result.cabinetChecks
              .filter(c => c.level === 'critical' || c.level === 'warning')
              .slice(0, 6)
              .map((c, i) => (
                <Text key={i} style={{ ...styles.infoItem, color: c.level === 'critical' ? '#c2410c' : '#92400e', marginBottom: 1 }}>
                  • [{c.level === 'critical' ? 'CRITIQUE' : 'ATTENTION'}] {c.message}
                </Text>
              ))}
            {result.cabinetChecks.filter(c => c.level === 'critical' || c.level === 'warning').length === 0 && (
              <Text style={styles.infoItem}>Aucun point bloquant détecté selon les hypothèses renseignées.</Text>
            )}
          </View>
        )}

        <View style={styles.disclaimer}>
          <Text style={styles.disclaimerText}>
            Simulation indicative. Ce document constitue une note de travail. Il ne constitue ni un conseil fiscal,
            ni une recommandation d'investissement. Les hypothèses fiscales, comptables et financières doivent
            être validées par l'expert-comptable selon la situation réelle de la société.
          </Text>
        </View>

        {footerFragment(3)}
      </Page>

      {/* ═══════════════════════════════════════════════════════
          PAGE 4 — Projection annuelle (paysage)
          ═══════════════════════════════════════════════════════ */}
      <Page size="A4" orientation="landscape" style={styles.pageLandscape} wrap={false}>
        <Text style={styles.sectionTitle}>Projection annuelle sur la durée retenue ({inputs.usufruitDuration} ans)</Text>

        <View style={styles.table}>
          <View style={styles.tableHeader}>
            <Text style={{ ...styles.tableHeaderCell, flex: 0.6 }}>Année</Text>
            <Text style={{ ...styles.tableHeaderCell, flex: 1.2, textAlign: 'right' }}>Revenus</Text>
            <Text style={{ ...styles.tableHeaderCell, flex: 1.1, textAlign: 'right' }}>Amort.</Text>
            {inputs.feesEnabled && (
              <Text style={{ ...styles.tableHeaderCell, flex: 1, textAlign: 'right' }}>FRAIS</Text>
            )}
            <Text style={{ ...styles.tableHeaderCell, flex: 1.3, textAlign: 'right' }}>Rés. fiscal op.</Text>
            <Text style={{ ...styles.tableHeaderCell, flex: 1.2, textAlign: 'right' }}>IS sans</Text>
            <Text style={{ ...styles.tableHeaderCell, flex: 1.2, textAlign: 'right' }}>IS avec</Text>
            <Text style={{ ...styles.tableHeaderCell, flex: 1.2, textAlign: 'right' }}>Impact IS</Text>
            <Text style={{ ...styles.tableHeaderCell, flex: 1.4, textAlign: 'right' }}>Cash-flow net</Text>
          </View>

          {result.projections.map((row, i) => (
            <View key={row.year} style={[styles.tableRow, i % 2 === 0 && styles.tableRowAlt]}>
              <Text style={{ ...styles.tableCell, flex: 0.6, fontWeight: 'bold' }}>A{row.year}</Text>
              <Text style={{ ...styles.tableCellRight, flex: 1.2, color: '#7c3aed' }}>{fmtNumber(row.grossIncome)} €</Text>
              <Text style={{ ...styles.tableCellRight, flex: 1.1 }}>{fmtNumber(row.amortization)} €</Text>
              {inputs.feesEnabled && (
                <Text style={{ ...styles.tableCellRight, flex: 1 }}>
                  {row.feesFiscal > 0 ? fmtNumber(row.feesFiscal) + ' €' : '—'}
                </Text>
              )}
              <Text style={{ ...styles.tableCellRight, flex: 1.3 }}>{fmtNumber(row.fiscalResultOperationOnly)} €</Text>
              <Text style={{ ...styles.tableCellMuted, flex: 1.2 }}>{fmtNumber(row.isBeforeOperation)} €</Text>
              <Text style={{ ...styles.tableCellOrange, flex: 1.2 }}>{fmtNumber(row.isAfterOperation)} €</Text>
              <Text style={{ ...styles.tableCellRight, flex: 1.2, fontWeight: 'bold', color: row.isImpact > 0 ? colors.orange : colors.accent }}>
                {row.isImpact >= 0 ? '+' : ''}{fmtNumber(row.isImpact)} €
              </Text>
              <Text style={{ ...styles.tableCellGreen, flex: 1.4 }}>
                {fmtNumber(inputs.feesEnabled ? row.netCashFlowAfterFees : row.netCashFlow)} €
              </Text>
            </View>
          ))}
        </View>

        {/* Cumul */}
        <View style={{ ...styles.infoBox, marginTop: -4 }}>
          <Text style={styles.infoTitle}>Flux cumulés sur la durée</Text>
          <Text style={styles.infoItem}>
            Flux de lancement cumulé après frais : {fmtEuro(inputs.feesEnabled ? result.cumulativeNetCashFlowAfterFees : result.cumulativeNetCashFlow)}
          </Text>
          <Text style={styles.infoItem}>
            Flux opérationnel cumulé : {fmtEuro(result.cumulativeNetCashFlow)}
          </Text>
          <Text style={{ ...styles.infoItem, fontSize: 7, color: '#64748b', marginTop: 2, fontStyle: 'italic' }}>
            Les frais de mission étant inclus dans l'effort initial, le flux opérationnel cumulé sert de base au gain économique et au TRI.
          </Text>
        </View>

        {/* Hypothèses fiscales */}
        <Text style={styles.sectionTitle}>Hypothèses comptables et fiscales</Text>
        <View style={styles.infoBox}>
          <Text style={styles.infoItem}>• Usufruit temporaire amorti linéairement sur la durée retenue.</Text>
          <Text style={styles.infoItem}>• Aucune valeur résiduelle retenue à l'échéance de l'usufruit.</Text>
          <Text style={styles.infoItem}>• Le montant investi en usufruit est réputé correspondre au prix d'acquisition total de l'usufruit selon la clé de démembrement. Les frais de souscription SCPI sont réputés intégrés dans ce prix, sauf modalité spécifique de la société de gestion.</Text>
          <Text style={styles.infoItem}>• Revenus SCPI supposés constants sur la durée, sauf revalorisation renseignée ({inputs.revalorizationRate} %).</Text>
          <Text style={styles.infoItem}>• Simulation hors frais spécifiques, hors délais de jouissance et hors fiscalité étrangère.</Text>
          <Text style={styles.infoItem}>• Taux d'IS : taux réduit PME (15 % / 25 %) ou taux normal (25 %) selon éligibilité déclarée ({inputs.reducedRateEligible ? 'éligible' : 'non éligible'}).</Text>
          {inputs.feesEnabled && (
            <>
              <Text style={styles.infoItem}>• Les frais de mission sont supposés payés au démarrage et intégrés dans l'effort initial. Ils sont isolés en année 1 pour mesurer le flux net complet de lancement.</Text>
              <Text style={styles.infoItem}>• Frais de mission : {inputs.feesVatMode}, TVA {inputs.feesVatRate} %, {inputs.feesVatRecoverable ? 'récupérable' : 'non récupérable'}.</Text>
              {inputs.holdingVatProfile !== 'to-qualify' && (
                <Text style={styles.infoItem}>• Profil TVA holding : {formatHoldingVatProfile(inputs.holdingVatProfile, inputs.vatRecoveryRate)}.</Text>
              )}
              {inputs.holdingVatProfile === 'mixed' && (
                <Text style={styles.infoItem}>• Le droit à déduction de TVA doit être validé selon l'activité réelle de la holding.</Text>
              )}
              <Text style={styles.infoItem}>• Traitement fiscal : {FEES_TREATMENT_SHORT[inputs.feesTreatment].toLowerCase()}.</Text>
              <Text style={styles.infoItem}>• Déductibilité sur base {inputs.feesVatRecoverable ? 'HT' : 'TTC'}.</Text>
              <Text style={styles.infoItem}>• Le traitement des frais de mission dépend de leur nature, justification et comptabilisation.</Text>
              {inputs.alternativeType && inputs.alternativeGrossRate && inputs.alternativeGrossRate > 0 && (
                <Text style={styles.infoItem}>• Comparaison alternative : {inputs.alternativeType === 'compte_terme' ? 'compte à terme' : inputs.alternativeType === 'fonds_monetaire' ? 'fonds monétaire' : 'taux personnalisé'} à {String(inputs.alternativeGrossRate ?? '').replace('.', ',')} % ({inputs.alternativeRateMode === 'brut' ? 'brut avant IS' : 'net d\'IS'}). L'alternative conserve le capital ; l'usufruit s'éteint sans valeur résiduelle.</Text>
              )}
            </>
          )}
        </View>

        {/* Disclaimer */}
        <View style={styles.disclaimer}>
          <Text style={styles.disclaimerText}>
            Ce document constitue une note de travail indicative. Il ne constitue ni un conseil fiscal,
            ni une recommandation d'investissement, ni une déclaration d'adéquation. Les hypothèses fiscales,
            comptables et financières doivent être validées par l'expert-comptable selon la situation réelle
            de la société.
          </Text>
        </View>

        {/* Visa cabinet */}
        <View style={styles.visaBox}>
          <Text style={styles.visaTitle}>Visa cabinet</Text>
          <Text style={styles.visaText}>
            Document visé pour intégration au dossier de travail du cabinet.
          </Text>
          <Text style={styles.visaField}>Date de validation : ____ / ____ / ________</Text>
          <Text style={styles.visaField}>Nom du cabinet : ____________________________________________</Text>
          <Text style={styles.visaField}>Visa de l'Expert-Comptable : ____________________________________________</Text>
          <Text style={styles.visaField}>Observations : ____________________________________________</Text>
        </View>

        {footerFragment(4)}
      </Page>

      {/* ────────────────────────────────────────────
          PAGE 5 — Annexe Méthodologie de calcul
          ──────────────────────────────────────────── */}
      <Page size="A4" style={styles.page} wrap={false}>
        <Text style={styles.sectionTitle}>Annexe — Méthodologie de calcul</Text>
        <Text style={{ fontSize: 10, color: '#64748b', marginBottom: 12 }}>
          Détail des formules utilisées dans la simulation
        </Text>

        <View style={styles.infoBox}>
          <Text style={styles.infoTitle}>Pleine propriété reconstituée</Text>
          <Text style={styles.infoItem}>Pleine propriété = Usufruit investi / Clé d'usufruit ({fmtPercent(inputs.usufruitKeyPercent)})</Text>
          <Text style={styles.infoItem}>Pleine propriété = {fmtEuro(inputs.usufruitInvestment)} / {fmtPercent(inputs.usufruitKeyPercent)} = {fmtEuro(result.reconstitutedFullProperty)}</Text>
        </View>

        <View style={styles.infoBox}>
          <Text style={styles.infoTitle}>Revenus bruts annuels SCPI</Text>
          <Text style={styles.infoItem}>Revenus bruts annuels = Pleine propriété × Taux de distribution ({fmtPercent(inputs.grossYieldRate)})</Text>
          <Text style={styles.infoItem}>Revenus bruts annuels = {fmtEuro(result.reconstitutedFullProperty)} × {fmtPercent(inputs.grossYieldRate)} = {fmtEuro(result.annualGrossIncome)}</Text>
          {inputs.incomeRevaluationRate > 0 && (
            <Text style={styles.infoItem}>Revalorisés à {inputs.incomeRevaluationRate} % / an les années suivantes.</Text>
          )}
        </View>

        <View style={styles.infoBox}>
          <Text style={styles.infoTitle}>Amortissement annuel de l'usufruit</Text>
          <Text style={styles.infoItem}>Amortissement annuel = Usufruit investi / Durée</Text>
          <Text style={styles.infoItem}>Amortissement annuel = {fmtEuro(inputs.usufruitInvestment)} / {inputs.usufruitDuration} = {fmtEuro(result.annualAmortization)}</Text>
        </View>

        <View style={styles.infoBox}>
          <Text style={styles.infoTitle}>Résultat fiscal de l'opération — année 1</Text>
          {inputs.feesEnabled ? (
            <>
              <Text style={styles.infoItem}>Résultat fiscal opération = Revenus bruts - Amortissement - Frais de mission déductibles</Text>
              <Text style={styles.infoItem}>Résultat fiscal opération = {fmtEuro(result.annualGrossIncome)} - {fmtEuro(result.annualAmortization)} - {fmtEuro(result.feesFiscalYear1)} = {fmtEuro(result.annualFiscalResultOperationOnly)}</Text>
            </>
          ) : (
            <>
              <Text style={styles.infoItem}>Résultat fiscal opération = Revenus bruts - Amortissement</Text>
              <Text style={styles.infoItem}>Résultat fiscal opération = {fmtEuro(result.annualGrossIncome)} - {fmtEuro(result.annualAmortization)} = {fmtEuro(result.annualFiscalResultOperationOnly)}</Text>
            </>
          )}
        </View>

        <View style={styles.infoBox}>
          <Text style={styles.infoTitle}>Résultat fiscal après opération</Text>
          <Text style={styles.infoItem}>Résultat fiscal après opération = Résultat avant opération + Résultat fiscal opération</Text>
          <Text style={styles.infoItem}>Résultat fiscal après opération = {fmtEuro(inputs.preTaxProfit)} + {fmtEuro(result.annualFiscalResultOperationOnly)} = {fmtEuro(result.annualFiscalResultAfterOperation)}</Text>
        </View>

        <View style={styles.infoBox}>
          <Text style={styles.infoTitle}>Impôt sur les sociétés — avant / après opération</Text>
          <Text style={styles.infoItem}>IS sans opération = Résultat avant opération × Taux IS applicable</Text>
          <Text style={styles.infoItem}>IS avec opération = Résultat après opération × Taux IS applicable</Text>
          <Text style={styles.infoItem}>Impact IS = IS avec opération - IS sans opération</Text>
          <Text style={styles.infoItem}>IS sans opération = {fmtEuro(isSansOperation)}</Text>
          <Text style={styles.infoItem}>IS avec opération = {fmtEuro(result.annualISAfterOperation)}</Text>
          <Text style={styles.infoItem}>Impact IS = {fmtEuro(result.annualISAfterOperation)} - {fmtEuro(isSansOperation)} = {result.annualISImpact >= 0 ? '+' : ''}{fmtEuro(result.annualISImpact)}</Text>
          <Text style={{ ...styles.infoItem, marginTop: 4, color: '#64748b', fontStyle: 'italic', fontSize: 8 }}>
            Le calcul tient compte de la tranche à taux réduit PME lorsque l'option est activée et selon les hypothèses d'éligibilité renseignées.
          </Text>
        </View>

        <View style={styles.infoBox}>
          <Text style={styles.infoTitle}>Flux net année 1</Text>
          {inputs.feesEnabled ? (
            <Text style={styles.infoItem}>Flux net année 1 = Revenus bruts - Impact IS - Frais de mission isolés en année 1</Text>
          ) : (
            <Text style={styles.infoItem}>Flux net année 1 = Revenus bruts - Impact IS</Text>
          )}
          <Text style={styles.infoItem}>Flux net année 1 = {fmtEuro(result.annualGrossIncome)} - {fmtEuro(Math.abs(result.annualISImpact))}{inputs.feesEnabled ? ` - ${fmtEuro(result.feesEconomicOutflow ?? result.feesFiscalYear1)}` : ''} = {fmtEuro(result.annualNetCashFlowAfterFees)}</Text>
        </View>

        {inputs.feesEnabled && (
          <View style={styles.infoBox}>
            <Text style={styles.infoTitle}>Convention économique retenue</Text>
            <Text style={styles.infoItem}>Effort initial économique = Usufruit investi + Frais de mission HT + TVA non récupérable</Text>
            <Text style={styles.infoItem}>Effort initial économique = {fmtEuro(inputs.usufruitInvestment)} + {fmtEuro(result.feesHT ?? 0)} + {fmtEuro(result.nonRecoverableVatAmount ?? 0)} = {fmtEuro(result.effortEconomique)}</Text>
            <Text style={styles.infoItem}>Flux opérationnel annuel = Revenus bruts - Impact IS (les frais ne sont pas déduits une seconde fois)</Text>
            <Text style={styles.infoItem}>Flux de lancement cumulé = Flux opérationnels - Frais de mission isolés en année 1 (lecture trésorerie)</Text>
            <Text style={styles.infoItem}>Gain économique et TRI calculés sur les flux opérationnels, pour éviter le double comptage des frais déjà intégrés dans l'effort initial.</Text>
          </View>
        )}

        <View style={styles.infoBox}>
          <Text style={styles.infoTitle}>Rendement cash-flow moyen annuel</Text>
          <Text style={styles.infoItem}>Rendement cash-flow moyen = (Flux net moyen annuel / Effort initial) × 100</Text>
          <Text style={styles.infoItem}>Rendement cash-flow moyen = {fmtPercent(result.cashFlowAverageReturn)}</Text>
        </View>

        <View style={styles.infoBox}>
          <Text style={styles.infoTitle}>Rendement simple après extinction</Text>
          <Text style={styles.infoItem}>Rendement simple = Gain économique / Effort initial / Durée × 100</Text>
          <Text style={styles.infoItem}>Rendement simple = {fmtEuro(result.economicGainAfterExtinction ?? result.gainNetAfterUsufructExtinction)} / {fmtEuro(result.effortEconomique)} / {inputs.usufruitDuration} × 100 = {fmtPercent(result.annualizedSimpleReturnAfterExtinction)} / an</Text>
        </View>

        <View style={styles.infoBox}>
          <Text style={styles.infoTitle}>TRI indicatif après extinction</Text>
          <Text style={styles.infoItem}>TRI = taux d'actualisation tel que la VAN des flux opérationnels = 0</Text>
          <Text style={styles.infoItem}>Année 0 : -{fmtEuro(result.effortEconomique)}</Text>
          <Text style={styles.infoItem}>Années 1 à {inputs.usufruitDuration} : flux opérationnels annuels</Text>
          <Text style={styles.infoItem}>Valeur finale de l'usufruit : 0 €</Text>
          <Text style={styles.infoItem}>Flux : [-{fmtEuro(result.effortEconomique)} ; {(result.irrCashFlows && result.irrCashFlows.length > 1 ? result.irrCashFlows.slice(1, 5).map(f => fmtEuro(f)).join(' ; ') + (result.irrCashFlows.length > 5 ? ' ; ...' : '') : result.projections && result.projections.length > 0 ? result.projections.slice(0, 3).map((p: Record<string, unknown>) => fmtEuro((p.netCashFlow as number) ?? 0)).join(' ; ') + (result.projections.length > 3 ? ' ; ...' : '') : '—')}]</Text>
          <Text style={styles.infoItem}>TRI indicatif = {result.indicativeIrr !== null ? fmtPercent(result.indicativeIrr) : 'Non calculable'}</Text>
        </View>

        <View style={styles.infoBox}>
          <Text style={styles.infoTitle}>TVA et frais de mission</Text>
          {inputs.feesEnabled ? (
            <>
              <Text style={styles.infoItem}>Frais de mission HT : {fmtEuro(result.feesHT ?? inputs.missionFeesAmount)}</Text>
              <Text style={styles.infoItem}>TVA ({inputs.feesVatRate ?? 20} %) : {fmtEuro(result.feesVAT ?? 0)}</Text>
              <Text style={styles.infoItem}>Total TTC : {fmtEuro(result.feesTTC ?? 0)}</Text>
              <Text style={styles.infoItem}>TVA récupérable : {fmtEuro(result.recoverableVatAmount ?? 0)}</Text>
              <Text style={styles.infoItem}>TVA non récupérable (incluse dans l'effort initial) : {fmtEuro(result.nonRecoverableVatAmount ?? 0)}</Text>
            </>
          ) : (
            <Text style={styles.infoItem}>Aucun frais de mission renseigné dans la simulation.</Text>
          )}
        </View>

        <View style={styles.infoBox}>
          <Text style={styles.infoTitle}>Frais de souscription SCPI</Text>
          <Text style={styles.infoItem}>Les frais de souscription SCPI sont réputés intégrés dans le prix d'acquisition de l'usufruit selon la clé de démembrement, sauf modalité spécifique de la société de gestion.</Text>
        </View>

        {/* Disclaimer */}
        <View style={styles.disclaimer}>
          <Text style={styles.disclaimerText}>
            Cette annexe méthodologique est fournie à titre informatif. Les formules et hypothèses
            doivent être validées par l'expert-comptable selon la situation réelle de la société.
          </Text>
        </View>

        {footerFragment(5)}
      </Page>
    </Document>
  );
};

export default ExpertHoldingReportPdf;
