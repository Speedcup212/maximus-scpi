import React, { useEffect, useMemo, useState } from 'react';
import { ArrowLeft, CheckCircle, Shield, TrendingUp, Info, BarChart3, Building, PieChart as PieChartIcon, DollarSign, Calendar, MessageCircle, ArrowRight, Phone } from 'lucide-react';
import { CALENDLY_URL } from '../../config/calendly';
import { PortfolioRecommendation, GuidedJourneyAnswers } from '../../types/guidedJourney';
import { Scpi } from '../../types/scpi';
import { scpiData } from '../../data/scpiData';
import { analyzePortfolio } from '../../utils/portfolioAnalysis';
import { normalizeGeoLabel, normalizeSectorLabel } from '../../utils/labelNormalization';
import { adaptPortfolioToAmount, getMaxScpiCount } from '../../utils/portfolioAdaptation';
import { createSlugFromName } from '../../utils/scpiSlugMapper';
import { PieChart as RechartsPie, Pie, Cell, ResponsiveContainer, Tooltip, BarChart, Bar, XAxis, YAxis, CartesianGrid, Legend } from 'recharts';
import SectionRepliable from './SectionRepliable';

interface GuidedJourneyResultsProps {
  recommendation: PortfolioRecommendation;
  answers: GuidedJourneyAnswers;
  onBack: () => void;
  onStartSubscription?: (scpiIds: number[]) => void;
  onCalendlyClick?: () => void;
}

interface PortfolioAnalysisModuleProps {
  portfolioScpis: Array<{ scpi: Scpi; allocation: number }>;
  analysis: ReturnType<typeof analyzePortfolio>;
  investmentAmount: number;
  onInvestmentAmountChange: (amount: number) => void;
}

const GRADIENT_IDS = {
  sectors: ['gradBlue', 'gradTeal', 'gradOrange', 'gradPink', 'gradPurple', 'gradCyan', 'gradLime', 'gradRed'],
  geography: ['gradBlue2', 'gradTeal2', 'gradOrange2', 'gradPink2', 'gradPurple2', 'gradCyan2', 'gradLime2', 'gradRed2']
};

const LEGEND_COLORS = {
  sectors: ['#2563eb', '#059669', '#d97706', '#db2777', '#7c3aed', '#0891b2', '#65a30d', '#ea580c'],
  geography: ['#2563eb', '#059669', '#d97706', '#db2777', '#7c3aed', '#0891b2', '#65a30d', '#ea580c']
};

const CustomTooltip = ({ active, payload }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-slate-800 px-4 py-2 rounded-lg border border-slate-600 shadow-xl">
        <p className="text-white font-semibold text-sm">{payload[0].name}</p>
        <p className="text-emerald-400 font-bold text-lg">{payload[0].value.toFixed(1)}%</p>
      </div>
    );
  }
  return null;
};

const PortfolioAnalysisModule: React.FC<PortfolioAnalysisModuleProps> = ({
  portfolioScpis,
  analysis,
  investmentAmount,
  onInvestmentAmountChange
}) => {
  const [investmentYears, setInvestmentYears] = useState<number>(15);

  // Calculer le montant investi (réallocation automatique du reliquat)
  const { actualInvestment } = useMemo(() => {
    const allocations = portfolioScpis.map((item) => {
      const targetAmount = (investmentAmount * item.allocation) / 100;
      const shares = Math.floor(targetAmount / item.scpi.price);
      return {
        id: item.id,
        allocation: item.allocation,
        price: item.scpi.price,
        targetAmount,
        shares,
        investedAmount: shares * item.scpi.price
      };
    });

    const minPrice = Math.min(...allocations.map((item) => item.price));
    let invested = allocations.reduce((total, item) => total + item.investedAmount, 0);
    let remaining = Math.max(0, investmentAmount - invested);
    let loopGuard = 0;

    while (remaining >= minPrice && loopGuard < 10000) {
      const candidates = allocations.filter((item) => remaining >= item.price);
      if (candidates.length === 0) break;

      candidates.sort((a, b) => {
        const gapA = a.targetAmount - a.investedAmount;
        const gapB = b.targetAmount - b.investedAmount;
        if (gapA !== gapB) return gapB - gapA;
        return a.price - b.price;
      });

      const chosen = candidates[0];
      chosen.shares += 1;
      chosen.investedAmount += chosen.price;
      invested += chosen.price;
      remaining -= chosen.price;
      loopGuard += 1;
    }

    return {
      actualInvestment: invested
    };
  }, [investmentAmount, portfolioScpis]);

  const annualRevenue = (actualInvestment * analysis.averageYield) / 100;
  const monthlyRevenue = annualRevenue / 12;

  const projectionData = Array.from({ length: investmentYears + 1 }, (_, year) => {
    const totalRevenue = annualRevenue * year;
    const totalValue = actualInvestment + totalRevenue;
    return {
      year: year === 0 ? 'Début' : `An ${year}`,
      capital: actualInvestment,
      revenus: totalRevenue,
      total: totalValue
    };
  });

  // Préparer les données pour les camemberts
  const sectorData = Object.values(
    Object.entries(analysis.sectorDistribution).reduce((acc, [name, value]) => {
      const normalized = normalizeSectorLabel(name);
      acc[normalized.key] = acc[normalized.key]
        ? { ...acc[normalized.key], value: acc[normalized.key].value + value }
        : { name: normalized.label, value };
      return acc;
    }, {} as Record<string, { name: string; value: number }>)
  )
    .map((item, index) => ({
      name: item.name,
      value: Math.round(item.value * 10) / 10,
      color: LEGEND_COLORS.sectors[index % LEGEND_COLORS.sectors.length]
    }))
    .sort((a, b) => b.value - a.value)
    .filter(item => item.value > 0);

  const geoData = Object.values(
    Object.entries(analysis.geoDistribution).reduce((acc, [name, value]) => {
      const normalized = normalizeGeoLabel(name);
      if (!acc[normalized.key]) {
        acc[normalized.key] = { name: normalized.label, value: 0 };
      }
      acc[normalized.key].value += value;
      return acc;
    }, {} as Record<string, { name: string; value: number }>)
  )
    .map((item, index) => ({
      name: item.name,
      value: Math.round(item.value * 10) / 10,
      color: LEGEND_COLORS.geography[index % LEGEND_COLORS.geography.length]
    }))
    .sort((a, b) => b.value - a.value)
    .filter(item => item.value > 0);

  // Trouver le prix minimum pour le step
  const minPrice = Math.min(...portfolioScpis.map(item => item.scpi.price));
  const minInvestment = Math.max(...portfolioScpis.map(item => item.scpi.minInvestment || item.scpi.price));

  return (
    <div className="bg-slate-900/80 border border-slate-700 rounded-xl sm:rounded-2xl shadow-xl p-4 sm:p-6 lg:p-8 mb-4 sm:mb-6">
      <h2 className="text-lg sm:text-xl lg:text-2xl font-bold text-white mb-2 sm:mb-3 flex items-center gap-2">
        <BarChart3 className="w-5 h-5 sm:w-6 sm:h-6 text-emerald-400 flex-shrink-0" />
        <span className="break-words">Analyse détaillée du portefeuille (pour mieux comprendre)</span>
      </h2>
      <p className="text-slate-300 mb-4 sm:mb-6 text-xs sm:text-sm">
        Les éléments ci-dessous vous permettent de mieux comprendre la construction de votre portefeuille recommandé.
      </p>

      <div className="space-y-4 sm:space-y-6">
        {/* Répartitions Sectorielle et Géographique */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6">
          {/* Répartition Sectorielle */}
          <div className="bg-slate-700/30 rounded-lg sm:rounded-xl border border-slate-700 p-4 sm:p-6">
            <h3 className="text-base sm:text-lg font-bold text-white mb-2 flex items-center gap-2">
              <PieChartIcon className="w-4 h-4 sm:w-5 sm:h-5 text-blue-400 flex-shrink-0" />
              Répartition Sectorielle
            </h3>
            <p className="text-xs sm:text-sm text-slate-300 mb-3 sm:mb-4">
              Cette répartition sectorielle permet de limiter la dépendance à un seul cycle immobilier. 
              En diversifiant les secteurs, vous réduisez l'impact d'une baisse temporaire dans un domaine spécifique.
            </p>
            <div className="relative">
              <ResponsiveContainer width="100%" height={220}>
                <RechartsPie>
                  <defs>
                    {GRADIENT_IDS.sectors.map((id, index) => (
                      <linearGradient key={id} id={id} x1="0" y1="0" x2="1" y2="1">
                        <stop offset="0%" stopColor={LEGEND_COLORS.sectors[index]} stopOpacity={1} />
                        <stop offset="100%" stopColor={LEGEND_COLORS.sectors[index]} stopOpacity={0.7} />
                      </linearGradient>
                    ))}
                  </defs>
                  <Pie
                    data={sectorData}
                    cx="50%"
                    cy="50%"
                    innerRadius="50%"
                    outerRadius="90%"
                    paddingAngle={0}
                    dataKey="value"
                    animationBegin={0}
                    animationDuration={800}
                    animationEasing="ease-out"
                  >
                    {sectorData.map((entry, index) => (
                      <Cell
                        key={`cell-${index}`}
                        fill={`url(#${GRADIENT_IDS.sectors[index % GRADIENT_IDS.sectors.length]})`}
                        stroke="#1e293b"
                        strokeWidth={2}
                        style={{ outline: 'none' }}
                      />
                    ))}
                  </Pie>
                  <Tooltip content={<CustomTooltip />} />
                </RechartsPie>
              </ResponsiveContainer>
              <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-center pointer-events-none">
                <div className="text-2xl sm:text-3xl font-bold text-white">{sectorData.length}</div>
                <div className="text-xs sm:text-sm text-slate-400">secteurs</div>
              </div>
            </div>
            <div className="mt-3 sm:mt-4 space-y-1.5 sm:space-y-2">
              {sectorData.map((sector, index) => (
                <div key={sector.name} className="flex items-center justify-between text-xs sm:text-sm">
                  <div className="flex items-center gap-2 min-w-0 flex-1">
                    <div
                      className="w-2.5 h-2.5 sm:w-3 sm:h-3 rounded-full flex-shrink-0"
                      style={{ backgroundColor: sector.color }}
                    ></div>
                    <span className="text-slate-300 truncate">{sector.name}</span>
                  </div>
                  <span className="font-semibold text-white ml-2 flex-shrink-0">{sector.value.toFixed(1)}%</span>
                </div>
              ))}
            </div>
          </div>

              {/* Répartition Géographique */}
              <div className="bg-slate-700/30 rounded-lg sm:rounded-xl border border-slate-700 p-4 sm:p-6">
                <h3 className="text-base sm:text-lg font-bold text-white mb-2 flex items-center gap-2">
                  <PieChartIcon className="w-4 h-4 sm:w-5 sm:h-5 text-green-400 flex-shrink-0" />
                  Répartition Géographique
                </h3>
                <p className="text-xs sm:text-sm text-slate-300 mb-3 sm:mb-4">
                  Cette répartition géographique réduit votre exposition aux risques locaux. 
                  En investissant dans plusieurs zones, vous bénéficiez de la stabilité de marchés complémentaires.
                </p>
            <div className="relative">
              <ResponsiveContainer width="100%" height={220}>
                <RechartsPie>
                  <defs>
                    {GRADIENT_IDS.geography.map((id, index) => (
                      <linearGradient key={id} id={id} x1="0" y1="0" x2="1" y2="1">
                        <stop offset="0%" stopColor={LEGEND_COLORS.geography[index]} stopOpacity={1} />
                        <stop offset="100%" stopColor={LEGEND_COLORS.geography[index]} stopOpacity={0.7} />
                      </linearGradient>
                    ))}
                  </defs>
                  <Pie
                    data={geoData}
                    cx="50%"
                    cy="50%"
                    innerRadius="50%"
                    outerRadius="90%"
                    paddingAngle={0}
                    dataKey="value"
                    animationBegin={0}
                    animationDuration={800}
                    animationEasing="ease-out"
                  >
                    {geoData.map((entry, index) => (
                      <Cell
                        key={`cell-${index}`}
                        fill={`url(#${GRADIENT_IDS.geography[index % GRADIENT_IDS.geography.length]})`}
                        stroke="#1e293b"
                        strokeWidth={2}
                        style={{ outline: 'none' }}
                      />
                    ))}
                  </Pie>
                  <Tooltip content={<CustomTooltip />} />
                </RechartsPie>
              </ResponsiveContainer>
              <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-center pointer-events-none">
                <div className="text-2xl sm:text-3xl font-bold text-white">{geoData.length}</div>
                <div className="text-xs sm:text-sm text-slate-400">pays</div>
              </div>
            </div>
            <div className="mt-3 sm:mt-4 space-y-1.5 sm:space-y-2">
              {geoData.map((geo, index) => (
                <div key={geo.name} className="flex items-center justify-between text-xs sm:text-sm">
                  <div className="flex items-center gap-2 min-w-0 flex-1">
                    <div
                      className="w-2.5 h-2.5 sm:w-3 sm:h-3 rounded-full flex-shrink-0"
                      style={{ backgroundColor: geo.color }}
                    ></div>
                    <span className="text-slate-300 truncate">{geo.name}</span>
                  </div>
                  <span className="font-semibold text-white ml-2 flex-shrink-0">{geo.value.toFixed(1)}%</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Montant à Investir */}
        <div className="bg-gradient-to-br from-emerald-500/10 to-emerald-600/5 rounded-lg sm:rounded-xl border border-emerald-500/20 p-4 sm:p-6">
          <h3 className="text-base sm:text-lg font-bold text-white mb-3 sm:mb-4 flex items-center gap-2">
            <DollarSign className="w-4 h-4 sm:w-5 sm:h-5 text-emerald-400 flex-shrink-0" />
            Montant à Investir
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6">
            <div className="space-y-4">
              <div>
                <label className="text-xs sm:text-sm font-medium text-slate-300 mb-2 block">
                  Montant total envisagé
                </label>
                <div className="relative">
                  <input
                    type="number"
                    value={investmentAmount}
                    onChange={(e) => {
                      const value = e.target.value;
                      if (value === '' || value === '0') {
                        onInvestmentAmountChange(0);
                      } else {
                        onInvestmentAmountChange(Number(value));
                      }
                    }}
                    min={0}
                    step={minPrice}
                    placeholder="Entrez un montant"
                    className="w-full px-3 sm:px-4 py-2 sm:py-3 bg-slate-700 border-2 border-slate-600 text-white rounded-lg text-lg sm:text-xl font-bold focus:outline-none focus:border-emerald-500 transition-colors"
                  />
                  <span className="absolute right-3 sm:right-4 top-1/2 -translate-y-1/2 text-slate-400 font-semibold text-base sm:text-lg">€</span>
                </div>
                <p className="text-xs text-slate-400 mt-1">Minimum: {minInvestment.toLocaleString('fr-FR')}€</p>
              </div>

              <div>
                <p className="text-xs text-slate-400 mb-2">Montants rapides:</p>
                <div className="grid grid-cols-3 gap-1.5 sm:gap-2">
                  {[10000, 25000, 50000, 100000, 200000, 500000].map((amount) => (
                    <button
                      key={amount}
                      onClick={() => onInvestmentAmountChange(amount)}
                      className={`px-2 sm:px-3 py-1.5 sm:py-2 border rounded-lg text-xs sm:text-sm font-semibold transition-all ${
                        investmentAmount === amount
                          ? 'bg-emerald-600 border-emerald-500 text-white'
                          : 'bg-slate-700 hover:bg-emerald-600 border-slate-600 hover:border-emerald-500 text-white'
                      }`}
                    >
                      {amount >= 1000 ? `${amount / 1000}k€` : `${amount}€`}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="space-y-2 sm:space-y-3">
              <div className="bg-slate-700/50 rounded-lg p-3 sm:p-4 border border-slate-600">
                <p className="text-xs sm:text-sm text-slate-400">Montant investi en parts</p>
                <p className="text-xl sm:text-2xl font-bold text-white">{actualInvestment.toLocaleString('fr-FR')}€</p>
                <p className="text-[10px] sm:text-xs text-slate-400 mt-1">
                  Correspond au montant effectivement utilisé pour l'achat de parts de SCPI.
                </p>
              </div>
              <div className="bg-emerald-500/10 rounded-lg p-3 sm:p-4 border border-emerald-500/30">
                <p className="text-xs sm:text-sm text-slate-300 font-medium">Ajustement technique</p>
                <p className="text-[10px] sm:text-xs text-slate-300 mt-1">
                  Ajustement inférieur au prix d'une part (arrondis techniques).
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Projection sur X ans */}
        <div className="bg-slate-700/30 rounded-lg sm:rounded-xl border border-slate-700 p-4 sm:p-6">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 mb-2">
            <h3 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
              <Calendar className="w-4 h-4 sm:w-5 sm:h-5 text-orange-400 flex-shrink-0" />
              Projection sur {investmentYears} ans
            </h3>
            <div className="flex items-center gap-2">
              <label className="text-xs sm:text-sm text-slate-400">Durée:</label>
              <select
                value={investmentYears}
                onChange={(e) => setInvestmentYears(Number(e.target.value))}
                className="px-2 sm:px-3 py-1 sm:py-1.5 bg-slate-700 border border-slate-600 text-white rounded-lg text-xs sm:text-sm focus:outline-none focus:border-emerald-500"
              >
                <option value={5}>5 ans</option>
                <option value={10}>10 ans</option>
                <option value={15}>15 ans</option>
                <option value={20}>20 ans</option>
              </select>
            </div>
          </div>
          <div className="mb-3 sm:mb-4 space-y-2">
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed mb-2 sm:mb-3">
              Cette projection illustre l'évolution potentielle de votre investissement sur {investmentYears} ans, 
              en supposant un rendement constant. Elle vous aide à visualiser l'accumulation progressive des revenus 
              et l'évolution de votre patrimoine, sans garantie de résultat.
            </p>
            <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-lg p-2 sm:p-3">
              <p className="text-xs text-yellow-200 leading-relaxed">
                <strong>Projection indicative basée sur des hypothèses.</strong> Les performances passées ne préjugent pas des performances futures. 
                Les revenus peuvent varier et le capital n'est pas garanti.
              </p>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={[...projectionData]}>
              <CartesianGrid strokeDasharray="3 3" stroke="#475569" />
              <XAxis dataKey="year" stroke="#94a3b8" />
              <YAxis stroke="#94a3b8" tickFormatter={(value) => `${(value / 1000).toFixed(0)}k€`} />
              <Tooltip
                contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #475569', borderRadius: '8px' }}
                labelStyle={{ color: '#fff' }}
                formatter={(value: number) => `${value.toLocaleString('fr-FR')}€`}
              />
              <Legend />
              <Bar dataKey="capital" name="Capital investi" stackId="a" fill="#3b82f6" />
              <Bar dataKey="revenus" name="Revenus cumulés" stackId="a" fill="#10b981" />
            </BarChart>
          </ResponsiveContainer>
          <div className="mt-3 sm:mt-4 bg-slate-800/50 rounded-lg p-3 sm:p-4 border border-slate-600">
            <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-1 sm:gap-0">
              <span className="text-xs sm:text-sm text-slate-300">Patrimoine total après {investmentYears} ans</span>
              <span className="text-xl sm:text-2xl font-bold text-emerald-400 break-words">
                {(actualInvestment + annualRevenue * investmentYears).toLocaleString('fr-FR')}€
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const GuidedJourneyResults: React.FC<GuidedJourneyResultsProps> = ({
  recommendation,
  answers,
  onBack,
  onStartSubscription,
  onCalendlyClick,
}) => {
  const { portfolio, explanation } = recommendation;

  // État pour le montant d'investissement (utilise la valeur du questionnaire ou 50000 par défaut)
  const [investmentAmount, setInvestmentAmount] = useState<number>(answers.investmentAmount || 50000);

  // Récupérer les SCPI du portefeuille original
  const originalPortfolioScpis = useMemo(() => {
    if (!scpiData || scpiData.length === 0) {
      return [];
    }
    
    const result = portfolio.scpis
      .map(p => {
        const scpi = scpiData.find(s => s.id === p.scpiId);
        return scpi
          ? {
              scpi: {
                ...scpi,
                rating: p.maximusIndex,
                isRecommended: true,
              },
              allocation: p.allocation,
              qualityScore: p.qualityScore,
              maximusIndex: p.maximusIndex,
            }
          : null;
      })
      .filter((item): item is { scpi: Scpi; allocation: number; qualityScore?: number; maximusIndex?: number } => item !== null);
    
    return result;
  }, [portfolio.scpis]);

  // Adapter le portefeuille au montant investi
  const { adaptedScpis: portfolioScpis, maxScpiCount } = useMemo(() => 
    adaptPortfolioToAmount(originalPortfolioScpis, portfolio.id, investmentAmount),
    [originalPortfolioScpis, portfolio.id, investmentAmount]
  );

  // Calculer les indicateurs du portefeuille adapté
  const analysis = useMemo(() => analyzePortfolio(portfolioScpis), [portfolioScpis]);
  
  // Vérifier si le portefeuille a été adapté
  const isAdapted = portfolioScpis.length < originalPortfolioScpis.length;

  // Générer la logique globale du portefeuille
  const portfolioLogic = useMemo(() => {
    const { taxSituation, objective, horizon, immediateIncome, tmiEstimate } = answers;
    
    let logic = "✅ Ce portefeuille a été construit en tenant compte de votre situation personnelle. ";
    
    // Fiscalité
    if (taxSituation === 'plus-6000') {
      logic += "💡 Fiscalité : votre imposition élevée oriente la lecture vers des SCPI avec une meilleure efficacité fiscale, notamment européennes. ";
    } else if (taxSituation === 'moins-2000') {
      logic += "💡 Fiscalité : votre faible imposition permet de privilégier le rendement brut sans complexité excessive. ";
    } else if (taxSituation === '2000-6000') {
      logic += "💡 Fiscalité : votre niveau intermédiaire conduit à équilibrer rendement et diversification. ";
    } else if (taxSituation === 'je-ne-sais-pas') {
      logic += "💡 Fiscalité : en l’absence d’information précise, l’analyse reste neutre et prudente. ";
    }

    if (tmiEstimate && ['tmi-30', 'tmi-41', 'tmi-45'].includes(tmiEstimate)) {
      logic += "📌 TMI ≥ 30 % : sélection orientée vers des SCPI européennes avec exposition France limitée. ";
    }
    
    // Objectif
    if (objective === 'revenus-reguliers' || immediateIncome === 'oui') {
      logic += "💶 Objectif : priorité aux revenus réguliers et prévisibles. ";
    } else if (objective === 'croissance-long-terme' || horizon === 'plus-15-ans') {
      logic += "📈 Objectif : focus sur la croissance du capital à long terme. ";
    } else if (objective === 'revenus-et-croissance') {
      logic += "⚖️ Objectif : équilibre recherché entre revenus et croissance. ";
    }
    
    // Horizon
    if (horizon === 'moins-8-ans') {
      logic += "🕒 Horizon : avec un horizon plus court, la stabilité et la liquidité relative sont privilégiées. ";
    } else if (horizon === 'plus-15-ans') {
      logic += "🧭 Horizon : long terme, ce qui permet d’absorber les cycles immobiliers. ";
    }
    
    // Risque
    logic += `🛡️ Risque : niveau ${portfolio.riskLevel === 'faible' ? 'faible' : portfolio.riskLevel === 'modere' ? 'modéré' : 'dynamique'} cohérent avec votre profil.`;
    
    return logic;
  }, [answers, portfolio.riskLevel]);

  const rendementMoyen = analysis.averageYield || 0;
  const revenusAnnuels = (investmentAmount * rendementMoyen) / 100;
  const revenusMensuels = revenusAnnuels / 12;

  const avisMaximus = useMemo(() => {
    const indices = portfolio.scpis
      .map(item => item.maximusIndex)
      .filter((value): value is number => typeof value === 'number');
    const averageIndex = indices.length > 0
      ? indices.reduce((sum, value) => sum + value, 0) / indices.length
      : 3;

    if (averageIndex >= 4.5) return { label: 'Cohérence élevée', detail: 'Portefeuille globalement cohérent sous certaines hypothèses.' };
    if (averageIndex >= 3.5) return { label: 'Cohérence maîtrisée', detail: 'Structure équilibrée à confirmer selon votre situation réelle.' };
    if (averageIndex >= 2.5) return { label: 'Cohérence partielle', detail: 'Plusieurs équilibres restent à consolider.' };
    return { label: 'Cohérence à vérifier', detail: 'Arbitrages à clarifier avant décision.' };
  }, [portfolio.scpis]);


  const prosCons = useMemo(() => {
    const pros: string[] = [];
    const cons: string[] = [];

    if (analysis.averageTof >= 95) {
      pros.push('Qualité locative élevée (TOF moyen solide).');
    } else if (analysis.averageTof >= 92) {
      pros.push('Qualité locative satisfaisante.');
    } else {
      cons.push('Qualité locative perfectible (TOF moyen à surveiller).');
    }

    if (analysis.averageDebt !== null && analysis.averageDebt <= 20) {
      pros.push('Endettement modéré, profil de risque maîtrisé.');
    } else if (analysis.averageDebt !== null && analysis.averageDebt > 30) {
      cons.push('Endettement élevé, sensibilité aux cycles renforcée.');
    }

    const sectorDiversificationCount = Math.max(
      Object.keys(analysis.sectorDistribution || {}).length,
      analysis.sectorCount
    );
    const geoDiversificationCount = Math.max(
      Object.keys(analysis.geoDistribution || {}).length,
      analysis.geographyCount
    );

    if (sectorDiversificationCount >= 5) {
      pros.push('Bonne diversification sectorielle.');
    } else {
      cons.push('Diversification sectorielle limitée.');
    }

    if (geoDiversificationCount >= 4) {
      pros.push('Diversification géographique suffisante.');
    } else {
      cons.push('Exposition géographique concentrée.');
    }

    if (answers.taxSituation === 'plus-6000') {
      pros.push('Lecture fiscale intégrée (TMI élevée).');
    }

    if (answers.horizon === 'moins-8-ans') {
      cons.push('Horizon court : liquidité et cycles immobiliers à considérer.');
    }

    if (cons.length === 0) {
      cons.push('Points de vigilance : rester attentif aux cycles immobiliers et à la liquidité relative des SCPI.');
    }

    return { pros, cons };
  }, [analysis, answers.taxSituation, answers.horizon]);

  const executiveSummary = useMemo(() => {
    const { taxSituation, objective, horizon } = answers;
    const objectiveLabel = objective === 'revenus-reguliers'
      ? 'revenus réguliers'
      : objective === 'croissance-long-terme'
        ? 'croissance du capital'
        : objective === 'revenus-et-croissance'
          ? 'équilibre revenus / croissance'
          : 'orientation guidée';
    const horizonLabel = horizon === 'moins-8-ans'
      ? 'horizon court'
      : horizon === 'plus-15-ans'
        ? 'horizon long'
        : 'horizon intermédiaire';
    const taxLabel = taxSituation === 'plus-6000'
      ? 'fiscalité élevée'
      : taxSituation === 'moins-2000'
        ? 'fiscalité faible'
        : taxSituation === '2000-6000'
          ? 'fiscalité intermédiaire'
          : 'fiscalité non précisée';
    const riskLabel = portfolio.riskLevel === 'faible' ? 'risque faible' : portfolio.riskLevel === 'modere' ? 'risque modéré' : 'risque dynamique';

    return `Profil ${objectiveLabel}, ${horizonLabel}, ${riskLabel}, ${taxLabel}. Logique dominante : cohérence long terme et stabilité de l’allocation.`;
  }, [answers, portfolio.riskLevel]);

  const arbitrages = useMemo(() => {
    const points: string[] = [];
    points.push("Stabilité et cohérence privilégiées plutôt qu’un rendement maximal.");
    points.push("Nombre de SCPI volontairement limité pour garder une allocation lisible.");
    points.push("Diversification géographique pour réduire la dépendance à un seul marché.");
    if (answers.taxSituation === 'plus-6000') {
      points.push("Lecture fiscale orientée vers l’efficacité plutôt qu’une optimisation agressive.");
    }
    return points;
  }, [answers.taxSituation]);

  const allocationReading = useMemo(() => {
    return [
      "Diversification sectorielle : mutualisation du risque locatif.",
      "Diversification géographique : exposition à des cycles immobiliers différents.",
      "Protection : réduction du risque de concentration.",
      "Limites : ne protège pas d’un choc immobilier général ni d’une hausse brutale des taux."
    ];
  }, []);

  const notThisPortfolio = useMemo(() => {
    const points = [
      "Une stratégie opportuniste court terme.",
      "Une recherche de rendement maximal.",
    ];
    if (answers.taxSituation === 'plus-6000') {
      points.push("Une optimisation fiscale agressive.");
    }
    return points;
  }, [answers.taxSituation]);

  const riskLevelColors = {
    faible: 'bg-green-100 text-green-800 border-green-300',
    modere: 'bg-yellow-100 text-yellow-800 border-yellow-300',
    dynamique: 'bg-orange-100 text-orange-800 border-orange-300',
  };

  const riskLevelLabels = {
    faible: 'Faible',
    modere: 'Modéré',
    dynamique: 'Dynamique',
  };

  // Calculer le score de risque sur une échelle de 1 à 7 (toujours entre 3 et 4)
  const riskScore = useMemo(() => {
    const { riskLevel } = portfolio;
    const portfolioType = portfolio.id;
    
    // Toujours entre 3 et 4
    if (riskLevel === 'faible') {
      return 3; // Au lieu de 2, on met 3
    } else if (riskLevel === 'modere') {
      // Pour les portefeuilles européens, score légèrement plus élevé
      if (portfolioType === 'immobilier-europeen') {
        return 4;
      } else {
        return 3;
      }
    } else if (riskLevel === 'dynamique') {
      return 4;
    }
    
    // Par défaut, retourner 3
    return 3;
  }, [portfolio.riskLevel, portfolio.id]);

  const [expandedSections, setExpandedSections] = useState({
    why: false,
    composition: true,
    analysisPro: false,
    analysisDetail: true,
    pedagogy: false,
  });
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    const shouldRestore = sessionStorage.getItem('parcours_restore_scroll');
    if (shouldRestore === '1') {
      const stored = sessionStorage.getItem('parcours_return_scroll');
      const scrollValue = stored ? Number(stored) : 0;
      window.scrollTo({ top: isNaN(scrollValue) ? 0 : scrollValue, behavior: 'auto' });
      sessionStorage.removeItem('parcours_restore_scroll');
    }
  }, []);

  const handleValidate = () => {
    // Lancer directement le tunnel de souscription
    handleStartSubscription();
  };

  const handleCalendlyClick = (e?: React.MouseEvent<HTMLButtonElement>) => {
    if (e) {
      e.preventDefault();
      e.stopPropagation();
    }
    if (onCalendlyClick) {
      onCalendlyClick();
    } else {
      // Fallback : ouvrir Calendly directement
      window.open(CALENDLY_URL, '_blank');
    }
  };

  const handleOpenScpiFiche = (href: string, slug: string, event?: React.MouseEvent<HTMLAnchorElement>) => {
    if (event) {
      event.preventDefault();
      event.stopPropagation();
    }
    sessionStorage.setItem('parcours_return_path', `${window.location.pathname}${window.location.search}`);
    sessionStorage.setItem('parcours_return_scroll', String(window.scrollY));
    const detail = {
      scpi_slug: slug,
      profil_risque: portfolio.riskLevel,
      montant: investmentAmount,
      step_id: 'guided-results'
    };
    window.dispatchEvent(new CustomEvent('scpi_fiche_opened_from_parcours', { detail }));
    window.history.pushState({}, '', href);
    window.dispatchEvent(new PopStateEvent('popstate'));
    window.scrollTo({ top: 0, behavior: 'auto' });
  };

  const handleStartSubscription = async (e?: React.MouseEvent<HTMLButtonElement>) => {
    // Empêcher le comportement par défaut (scroll, navigation, etc.)
    if (e) {
      e.preventDefault();
      e.stopPropagation();
    }

    // Empêcher les clics multiples
    if (isLoading) {
      return;
    }

    try {
      setIsLoading(true);

      // Vérifier que portfolioScpis est défini et non vide
      if (!portfolioScpis || portfolioScpis.length === 0) {
        alert('Erreur : Aucune SCPI sélectionnée. Veuillez réessayer.');
        setIsLoading(false);
        return;
      }

      // Extraire les IDs des SCPI
      const scpiIds = portfolioScpis.map(p => p.scpi.id);

      // Appeler la fonction onStartSubscription passée depuis App.tsx
      if (onStartSubscription) {
        await onStartSubscription(scpiIds);
      } else {
        alert('Erreur : Impossible d\'ouvrir le tunnel. Veuillez réessayer.');
      }
      
      setIsLoading(false);
    } catch (error) {
      console.error('Erreur lors de l\'ouverture du tunnel:', error);
      alert('Une erreur est survenue. Veuillez réessayer.');
      setIsLoading(false);
    }
  };

  // Générer le sous-titre humain selon le type de portefeuille
  const humanSubtitle = useMemo(() => {
    const { objective, immediateIncome, horizon } = answers;
    
    if (objective === 'revenus-reguliers' || immediateIncome === 'oui') {
      return "Pour générer des revenus réguliers tout en privilégiant la stabilité du capital.";
    }
    if (objective === 'croissance-long-terme' || horizon === 'plus-15-ans') {
      return "Pour faire progresser votre capital sur le long terme avec une approche équilibrée.";
    }
    if (objective === 'revenus-et-croissance') {
      return "Pour combiner revenus réguliers et croissance du capital sur le moyen terme.";
    }
    return "Pour vous accompagner dans votre projet d'investissement avec une solution adaptée à votre profil.";
  }, [answers]);

  // Générer les bullet points simplifiés
  const portfolioBulletPoints = useMemo(() => {
    const points: string[] = [];
    const { objective, immediateIncome, horizon } = answers;
    
    if (objective === 'revenus-reguliers' || immediateIncome === 'oui') {
      points.push("💶 Revenus réguliers et prévisibles");
      points.push("🛡️ Préserver le capital investi");
    } else if (objective === 'croissance-long-terme' || horizon === 'plus-15-ans') {
      points.push("📈 Croissance du capital sur le long terme");
      points.push("🌍 Diversification solide pour lisser le risque");
    } else {
      points.push("⚖️ Équilibre revenus / croissance");
      points.push("🏢 Diversification de l’investissement immobilier");
    }
    
    points.push("🧩 Réduction du risque par diversification");
    
    if (horizon === 'moins-8-ans') {
      points.push("🕒 Adapté à un horizon plus court");
    } else if (horizon === 'plus-15-ans') {
      points.push("🧭 Optimisé pour le long terme");
    }
    
    return points.slice(0, 4); // Maximum 4 points
  }, [answers]);

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 py-4 sm:py-12 px-2 sm:px-4">
      <div className="max-w-4xl mx-auto bg-slate-900/60 border border-slate-700 rounded-xl sm:rounded-2xl shadow-xl p-3 sm:p-6 lg:p-8">
        {/* Header */}
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-slate-300 hover:text-white mb-4 sm:mb-6 transition-colors text-sm sm:text-base"
        >
          <ArrowLeft className="w-4 h-4 sm:w-5 sm:h-5" />
          <span className="hidden sm:inline">Retour au questionnaire</span>
          <span className="sm:hidden">Retour</span>
        </button>

        {/* 1️⃣ SYNTHÈSE IMMÉDIATE - Au-dessus de la ligne de flottaison */}
        <div className="bg-gradient-to-br from-emerald-600/20 to-emerald-500/10 border border-emerald-500/30 rounded-xl sm:rounded-2xl p-4 sm:p-6 mb-4 sm:mb-6">
          <div className="text-center mb-4 sm:mb-6">
            <div className="inline-flex items-center justify-center w-12 h-12 sm:w-14 sm:h-14 bg-emerald-600 rounded-full mb-3 sm:mb-4">
              <CheckCircle className="w-6 h-6 sm:w-7 sm:h-7 text-white" />
            </div>
            <h1 className="text-xl sm:text-2xl lg:text-3xl font-bold text-white mb-2">
              Votre portefeuille recommandé
            </h1>
            <p className="text-sm sm:text-base text-slate-300">
              Adapté à votre situation
            </p>
          </div>

          {/* Synthèse en 3 points clés (simplifiée) */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 sm:gap-4 mb-4 sm:mb-6">
            {/* Type de portefeuille */}
            <div className="bg-slate-900/60 rounded-lg sm:rounded-xl p-3 sm:p-4 border border-slate-700">
              <div className="text-xs text-slate-400 mb-1">Portefeuille</div>
              <div className="text-base sm:text-lg font-bold text-white break-words">{portfolio.name}</div>
            </div>

            {/* Objectif principal */}
            <div className="bg-slate-900/60 rounded-lg sm:rounded-xl p-3 sm:p-4 border border-slate-700">
              <div className="text-xs text-slate-400 mb-1">Objectif</div>
              <div className="text-xs sm:text-sm text-slate-200 leading-tight">{humanSubtitle}</div>
            </div>

            {/* Niveau de risque */}
            <div className="bg-slate-900/60 rounded-lg sm:rounded-xl p-3 sm:p-4 border border-slate-700">
              <div className="text-xs text-slate-400 mb-2">Risque</div>
              <div className="flex items-center gap-2 mb-2">
                <span className={`px-2 sm:px-3 py-1 rounded-full text-xs sm:text-sm font-bold border-2 ${riskLevelColors[portfolio.riskLevel]}`}>
                  {riskLevelLabels[portfolio.riskLevel]}
                </span>
              </div>
              {/* Échelle de risque 1-7 */}
              <div className="mt-2">
                <div className="flex items-center gap-1 sm:gap-2 mb-1">
                  <span className="text-xs text-slate-400 hidden sm:inline">Profil :</span>
                  <div className="flex-1 flex flex-col gap-0.5 sm:gap-1">
                    {/* 7 barres distinctes */}
                    <div className="flex gap-0.5 sm:gap-1">
                      {[1, 2, 3, 4, 5, 6, 7].map((num) => {
                        const isActive = num <= riskScore;
                        const barColor = riskScore === 3
                          ? (isActive ? 'bg-green-500' : 'bg-slate-700')
                          : riskScore === 4
                          ? (isActive ? 'bg-orange-500' : 'bg-slate-700')
                          : (isActive ? 'bg-red-500' : 'bg-slate-700');
                        
                        return (
                          <div
                            key={num}
                            className={`flex-1 h-4 sm:h-5 rounded transition-all duration-500 ${barColor}`}
                          />
                        );
                      })}
                    </div>
                    {/* Chiffres 1 à 7 en dessous */}
                    <div className="flex gap-0.5 sm:gap-1">
                      {[1, 2, 3, 4, 5, 6, 7].map((num) => (
                        <div key={num} className="flex-1 text-center">
                          <span className="text-[10px] sm:text-xs text-slate-400">{num}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  <span className="text-[10px] sm:text-xs font-bold text-slate-300 min-w-[2rem] text-right">{riskScore}/7</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Portfolio Card - Détails */}
        <div className="bg-slate-900/80 border border-slate-700 rounded-xl sm:rounded-2xl shadow-xl p-4 sm:p-6 lg:p-8 mb-4 sm:mb-6">

          {/* NIVEAU 2 : JUSTIFICATION - Sections repliables */}

          {/* Section 1 : Composition du portefeuille */}
          <SectionRepliable
            title={`Les ${portfolioScpis.length} SCPI (illustration de la stratégie)`}
            subtitle={isAdapted
              ? `Illustration cohérente de la stratégie retenue pour ${investmentAmount.toLocaleString('fr-FR')} € avec ${portfolioScpis.length} SCPI.`
              : `Illustration cohérente de la stratégie retenue avec ${portfolioScpis.length} SCPI.`
            }
            isExpanded={expandedSections.composition}
            onToggle={() => setExpandedSections(prev => ({ ...prev, composition: !prev.composition }))}
          >
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-3 sm:mb-4">
              <div className="bg-slate-900/60 border border-slate-700 rounded-lg p-3">
                <p className="text-[10px] sm:text-xs text-slate-400">Rendement moyen</p>
                <p className="text-lg sm:text-xl font-bold text-emerald-400">{analysis.averageYield.toFixed(2)}%</p>
              </div>
              <div className="bg-slate-900/60 border border-slate-700 rounded-lg p-3">
                <p className="text-[10px] sm:text-xs text-slate-400">TOF moyen</p>
                <p className="text-lg sm:text-xl font-bold text-slate-100">{analysis.averageTof.toFixed(2)}%</p>
              </div>
              <div className="bg-slate-900/60 border border-slate-700 rounded-lg p-3">
                <p className="text-[10px] sm:text-xs text-slate-400">Endettement moyen</p>
                <p className="text-lg sm:text-xl font-bold text-slate-100">
                  {analysis.averageDebt === null ? 'N/D' : `${analysis.averageDebt.toFixed(1)}%`}
                </p>
              </div>
            </div>
            <div className="space-y-2 sm:space-y-3">
              {portfolioScpis.map(({ scpi, allocation }) => {
                const scpiSlug = createSlugFromName(scpi.name);
                const scpiHref = `/comparateur/scpi/${scpiSlug}?source=parcours&context=allocation&lock=true`;

                return (
                  <div
                    key={scpi.id}
                    className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 p-3 sm:p-4 bg-slate-800/70 rounded-lg border border-slate-700/80 shadow-inner"
                  >
                    <div className="flex-1 min-w-0 pr-2">
                      <div className="font-semibold text-slate-100 text-sm sm:text-base truncate">{scpi.name}</div>
                      <div className="text-[10px] sm:text-xs text-slate-400 truncate">{scpi.company}</div>
                    </div>
                    <div className="flex items-center justify-between sm:justify-end gap-3">
                      <div className="text-right flex-shrink-0">
                        <div className="text-lg sm:text-xl font-bold text-emerald-400">{scpi.yield.toFixed(2)}%</div>
                        <div className="text-[10px] sm:text-xs text-slate-400">Répartition: {allocation.toFixed(1)}%</div>
                      </div>
                      <a
                        href={scpiHref}
                        onClick={(event) => handleOpenScpiFiche(scpiHref, scpiSlug, event)}
                        className="inline-flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-lg text-[10px] sm:text-xs font-semibold border border-emerald-500/30 text-emerald-300 hover:text-emerald-200 hover:border-emerald-400/60 hover:bg-emerald-500/10 transition-colors"
                      >
                        <span>🔍</span>
                        <span>Voir la fiche SCPI</span>
                      </a>
                    </div>
                  </div>
                );
              })}
            </div>
            {isAdapted && (
              <p className="text-sm text-slate-300 leading-relaxed mt-4">
                Cette approche privilégie une allocation lisible et progressive. 
                La diversification pourra être renforcée dans le temps lors de futurs investissements.
              </p>
            )}
          </SectionRepliable>

          {/* Section 2 : Analyse détaillée */}
          <SectionRepliable
            title="Analyse détaillée"
            subtitle="Pour approfondir votre compréhension du portefeuille"
            isExpanded={expandedSections.analysisDetail}
            onToggle={() => setExpandedSections(prev => ({ ...prev, analysisDetail: !prev.analysisDetail }))}
          >
            <div className="bg-slate-800/70 rounded-lg border border-slate-700/80 p-3 sm:p-4">
              <PortfolioAnalysisModule 
                portfolioScpis={portfolioScpis}
                analysis={analysis}
                investmentAmount={investmentAmount}
                onInvestmentAmountChange={setInvestmentAmount}
              />
            </div>
          </SectionRepliable>

          <SectionRepliable
            title="Analyse professionnelle"
            subtitle="Avantages, points de vigilance et indicateurs clés"
            isExpanded={expandedSections.analysisPro}
            onToggle={() => setExpandedSections(prev => ({ ...prev, analysisPro: !prev.analysisPro }))}
          >
            <div className="grid gap-4 lg:grid-cols-2">
              <div className="bg-slate-900/60 border border-slate-700 rounded-xl p-4">
                <h4 className="text-sm font-semibold text-emerald-300 mb-2">✅ Avantages</h4>
                <ul className="space-y-2">
                  {prosCons.pros.map((point, index) => (
                    <li key={index} className="flex items-start gap-3 text-slate-200">
                      <span className="text-emerald-400 mt-1">•</span>
                      <span>{point}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <div className="bg-slate-900/60 border border-slate-700 rounded-xl p-4">
                <h4 className="text-sm font-semibold text-amber-300 mb-2">⚠️ Points de vigilance</h4>
                <ul className="space-y-2">
                  {prosCons.cons.map((point, index) => (
                    <li key={index} className="flex items-start gap-3 text-slate-200">
                      <span className="text-amber-400 mt-1">•</span>
                      <span>{point}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <div className="bg-slate-900/60 border border-slate-700 rounded-xl p-4">
                <h4 className="text-sm font-semibold text-slate-200 mb-2">📊 Rendements & revenus</h4>
                <div className="text-sm text-slate-200 space-y-2">
                  <div className="flex items-center justify-between">
                    <span>Rendement moyen</span>
                    <span className="font-semibold">{rendementMoyen.toFixed(2)} %</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Revenus annuels estimés</span>
                    <span className="font-semibold">{Math.round(revenusAnnuels).toLocaleString('fr-FR')} €</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Revenus mensuels estimés</span>
                    <span className="font-semibold">{Math.round(revenusMensuels).toLocaleString('fr-FR')} €</span>
                  </div>
                </div>
              </div>
              <div className="bg-slate-900/60 border border-slate-700 rounded-xl p-4">
                <h4 className="text-sm font-semibold text-slate-200 mb-2">⭐ Avis MaximusSCPI</h4>
                <p className="text-slate-200 leading-relaxed">
                  {avisMaximus.label} — {avisMaximus.detail}
                </p>
                <p className="mt-2 text-xs text-slate-400">
                  Ce score évalue la cohérence structurelle du portefeuille sélectionné.
                  Il ne constitue ni un conseil personnalisé, ni une promesse de performance future.
                </p>
              </div>
            </div>
          </SectionRepliable>

          {/* Section 3 : Restitution experte */}
          <SectionRepliable
            title="Restitution experte"
            isExpanded={expandedSections.why}
            onToggle={() => setExpandedSections(prev => ({ ...prev, why: !prev.why }))}
          >
            <p className="inline-flex items-center gap-2 text-xs sm:text-sm text-emerald-300/90 mb-4">
              <span className="inline-block h-1.5 w-1.5 rounded-full bg-emerald-400" />
              La sélection des SCPI est présentée plus haut.
            </p>
            <div className="grid gap-4 lg:grid-cols-2">
              <div className="bg-slate-900/60 border border-slate-700 rounded-xl p-4">
                <h4 className="text-sm font-semibold text-emerald-300 mb-2">1️⃣ Synthèse exécutive — verrou décisionnel</h4>
                <p className="text-slate-200 leading-relaxed">{executiveSummary}</p>
              </div>

              <div className="bg-slate-900/60 border border-slate-700 rounded-xl p-4">
                <h4 className="text-sm font-semibold text-emerald-300 mb-2">2️⃣ Arbitrages structurants — cœur expert</h4>
                <ul className="space-y-2">
                  {arbitrages.map((point, index) => (
                    <li key={index} className="flex items-start gap-3 text-slate-200">
                      <span className="text-emerald-400 mt-1">•</span>
                      <span>{point}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="bg-slate-900/60 border border-slate-700 rounded-xl p-4 lg:col-span-2">
                <h4 className="text-sm font-semibold text-emerald-300 mb-2">3️⃣ Pourquoi ce portefeuille est cohérent avec votre situation</h4>
                <p className="text-slate-200 leading-relaxed mb-3">{portfolioLogic}</p>
                <ul className="space-y-2">
                  {portfolioBulletPoints.map((point, index) => (
                    <li key={index} className="flex items-start gap-3 text-slate-200">
                      <span className="text-emerald-400 mt-1">•</span>
                      <span>{point}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="bg-slate-900/60 border border-slate-700 rounded-xl p-4">
                <h4 className="text-sm font-semibold text-emerald-300 mb-2">4️⃣ Lecture experte de l’allocation</h4>
                <ul className="space-y-2">
                  {allocationReading.map((point, index) => (
                    <li key={index} className="flex items-start gap-3 text-slate-200">
                      <span className="text-emerald-400 mt-1">•</span>
                      <span>{point}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="bg-slate-900/60 border border-slate-700 rounded-xl p-4 lg:col-span-2">
                <h4 className="text-sm font-semibold text-emerald-300 mb-2">5️⃣ Produits (SCPI) — illustration, pas justification</h4>
                <p className="text-slate-200 leading-relaxed">
                  Les SCPI présentées plus haut illustrent la logique d’allocation retenue. Elles ne constituent pas une recommandation personnalisée.
                </p>
              </div>
            </div>
          </SectionRepliable>

          {/* Section 4 : Cadres pédagogiques & limites */}
          <SectionRepliable
            title="Cadres pédagogiques & limites"
            isExpanded={expandedSections.pedagogy}
            onToggle={() => setExpandedSections(prev => ({ ...prev, pedagogy: !prev.pedagogy }))}
          >
            <div className="grid gap-4 lg:grid-cols-2">
              <div className="bg-slate-900/60 border border-slate-700 rounded-xl p-4">
                <h4 className="text-sm font-semibold text-emerald-300 mb-2">Ce que ce portefeuille n’est pas — cadre de limites</h4>
                <ul className="space-y-2">
                  {notThisPortfolio.map((point, index) => (
                    <li key={index} className="flex items-start gap-3 text-slate-200">
                      <span className="text-emerald-400 mt-1">•</span>
                      <span>{point}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="bg-slate-900/60 border border-slate-700 rounded-xl p-4 lg:col-span-2">
                <h4 className="text-sm font-semibold text-emerald-300 mb-2">Projection long terme — cadre de lecture, pas promesse</h4>
                <p className="text-slate-200 leading-relaxed mb-3">
                  La projection à 15 ans est un outil de compréhension basé sur des hypothèses constantes, sans valeur prédictive.
                </p>
                <ul className="space-y-2">
                  <li className="flex items-start gap-3 text-slate-200">
                    <span className="text-emerald-400 mt-1">•</span>
                    <span>Scénario central : continuité des tendances observées.</span>
                  </li>
                  <li className="flex items-start gap-3 text-slate-200">
                    <span className="text-emerald-400 mt-1">•</span>
                    <span>Scénario défavorable : pression sur les revenus ou la valorisation.</span>
                  </li>
                  <li className="flex items-start gap-3 text-slate-200">
                    <span className="text-emerald-400 mt-1">•</span>
                    <span>Scénario favorable : amélioration progressive des cycles immobiliers.</span>
                  </li>
                </ul>
                <p className="text-slate-300 text-xs mt-3">Les performances passées ne préjugent pas des performances futures.</p>
              </div>

              <div className="bg-slate-900/60 border border-slate-700 rounded-xl p-4 lg:col-span-2">
                <h4 className="text-sm font-semibold text-emerald-300 mb-2">Cadre non contractuel & mentions pédagogiques</h4>
                <p className="text-slate-200 leading-relaxed">
                  Cette lecture est informative et vise à clarifier la logique d’allocation, sans engagement contractuel.
                </p>
              </div>
            </div>
          </SectionRepliable>

        </div>

        {/* 5️⃣ FIN DE PAGE - Transition vers l'action */}
        <div className="space-y-3 sm:space-y-4">
          {/* Message de rassurance et ouverture */}
          <div className="bg-emerald-500/10 border-l-4 border-emerald-500 rounded-lg p-3 sm:p-4">
            <h3 className="text-base sm:text-lg font-bold text-white mb-2">
              Prochaine étape
            </h3>
            <p className="text-slate-200 leading-relaxed text-xs sm:text-sm">
              Cette analyse constitue une base de travail cohérente. Elle peut être validée, ajustée ou challengée
              avec un professionnel si vous le souhaitez. La décision finale vous appartient.
            </p>
          </div>

          {/* Avertissement réglementaire */}
          <div className="bg-slate-900/80 border border-yellow-500/50 rounded-lg sm:rounded-xl p-4 sm:p-6">
            <div className="flex items-start gap-2 sm:gap-3">
              <Info className="w-5 h-5 sm:w-6 sm:h-6 text-yellow-400 flex-shrink-0 mt-0.5" />
              <div className="text-xs sm:text-sm text-yellow-100">
                <p className="font-semibold mb-1 sm:mb-2">Avertissement important</p>
                <p className="leading-relaxed">
                  Les investissements en SCPI présentent un risque de perte en capital et une liquidité non garantie. 
                  Les performances passées ne préjugent pas des performances futures. 
                  Cette recommandation est indicative et ne constitue pas un engagement contractuel ni une promesse de rendement. 
                  Durée de placement recommandée : 8 à 10 ans minimum.
                </p>
              </div>
            </div>
          </div>

          {/* BOUTONS D'ACTION EN BAS DE PAGE */}
          <div className="mt-4 sm:mt-6">
            <div className="flex flex-col sm:flex-row gap-2 sm:gap-3">
            {/* Bouton Prendre RDV */}
            <button
              type="button"
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                handleCalendlyClick(e);
              }}
              style={{
                position: 'relative',
                zIndex: 1000,
                pointerEvents: 'auto'
              }}
              className="flex-1 px-4 sm:px-6 py-3 sm:py-4 rounded-lg sm:rounded-xl bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white text-sm sm:text-base font-bold transition-colors flex items-center justify-center gap-2 shadow-lg shadow-green-500/20 hover:shadow-green-500/30"
            >
              <Phone className="w-4 h-4 sm:w-5 sm:h-5" />
              <span className="hidden sm:inline">Prendre RDV avec un conseiller</span>
              <span className="sm:hidden">Prendre RDV</span>
            </button>

              <div className="flex-1">
                <p className="text-xs text-slate-300 mb-2 text-center sm:text-left">
                  Cette étape permet de sécuriser votre décision avec un professionnel avant toute souscription définitive.
                </p>
                {/* Bouton Commencer ma souscription */}
                <button
                type="button"
                disabled={isLoading || !portfolioScpis || portfolioScpis.length === 0}
                onClick={async (e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  if (isLoading || !portfolioScpis || portfolioScpis.length === 0) {
                    return;
                  }
                  try {
                    await handleStartSubscription(e);
                  } catch (error) {
                    console.error('Erreur dans handleStartSubscription:', error);
                    alert('Erreur lors de l\'ouverture du tunnel: ' + (error instanceof Error ? error.message : String(error)));
                  }
                }}
                style={{ 
                  position: 'relative',
                  zIndex: 1000,
                  pointerEvents: (isLoading || !portfolioScpis || portfolioScpis.length === 0) ? 'none' : 'auto'
                }}
                className="flex-1 px-4 sm:px-6 py-3 sm:py-4 rounded-lg sm:rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:bg-slate-600 disabled:cursor-not-allowed text-white text-sm sm:text-base font-bold transition-colors flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20 hover:shadow-emerald-500/30 disabled:shadow-none"
                >
                  {isLoading ? (
                    <>
                      <div className="w-4 h-4 sm:w-5 sm:h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      <span className="hidden sm:inline">Ouverture du tunnel de souscription...</span>
                      <span className="sm:hidden">Ouverture...</span>
                    </>
                  ) : (
                    <>
                      <span className="hidden sm:inline">Commencer ma pré-souscription en ligne</span>
                      <span className="sm:hidden">Souscription</span>
                      <ArrowRight className="w-4 h-4 sm:w-5 sm:h-5" />
                    </>
                  )}
                </button>
              </div>
            </div>
            <p className="text-xs text-slate-400 text-center mt-2 sm:mt-3 px-2">
              Accédez au formulaire de souscription avec votre portefeuille pré-rempli
            </p>
          </div>

        </div>
      </div>
    </div>
  );
};

export default GuidedJourneyResults;
