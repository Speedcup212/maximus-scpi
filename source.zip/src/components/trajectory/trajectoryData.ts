export type ScpiHistoryRow = {
  scpi_slug: string;
  snapshot_at: string | null;
  source_period: string | null;
  source_url: string | null;
  qa_status: string | null;
  source_confidence: number | string | null;
  tof: number | string | null;
  td: number | string | null;
  capitalisation: number | string | null;
  prix_souscription: number | string | null;
  prix_reconstitution: number | string | null;
  prix_retrait: number | string | null;
  valeur_realisation: number | string | null;
  endettement: number | string | null;
  distribution_par_part: number | string | null;
  parts_attente_retrait: number | string | null;
  nombre_parts: number | string | null;
  capital_type?: string | null;
  liquidity_basis?: string | null;
  liquidity_pressure_pct?: number | string | null;
  retrait_attente_pct?: number | string | null;
};

export type NormalizedHistoryRow = Omit<
  ScpiHistoryRow,
  | 'tof'
  | 'td'
  | 'capitalisation'
  | 'prix_souscription'
  | 'prix_reconstitution'
  | 'prix_retrait'
  | 'valeur_realisation'
  | 'endettement'
  | 'distribution_par_part'
  | 'parts_attente_retrait'
  | 'nombre_parts'
  | 'source_confidence'
  | 'liquidity_pressure_pct'
  | 'retrait_attente_pct'
> & {
  tof: number | null;
  td: number | null;
  capitalisation: number | null;
  prix_souscription: number | null;
  prix_reconstitution: number | null;
  prix_retrait: number | null;
  valeur_realisation: number | null;
  endettement: number | null;
  distribution_par_part: number | null;
  parts_attente_retrait: number | null;
  nombre_parts: number | null;
  source_confidence: number | null;
  retrait_attente_pct: number | null;
  liquidity_basis: string | null;
  liquidity_pressure_pct: number | null;
};

export const HISTORY_SELECT = [
  'scpi_slug', 'snapshot_at', 'source_period', 'source_url', 'qa_status', 'source_confidence',
  'tof', 'td', 'capitalisation', 'prix_souscription', 'prix_reconstitution', 'prix_retrait',
  'valeur_realisation', 'endettement', 'distribution_par_part', 'parts_attente_retrait', 'nombre_parts',
  'capital_type', 'liquidity_basis',
].join(',');

export const CERTIFIED_HISTORY_SELECT = `${HISTORY_SELECT},retrait_attente_pct,liquidity_pressure_pct`;

export type CertifiedLiquiditySnapshot = {
  scpi_slug: string;
  source_period: string | null;
  liquidity_basis: string | null;
  liquidity_pressure_pct: number | string | null;
  retrait_attente_pct: number | string | null;
  regime_changed: boolean | null;
  signal_certification: string | null;
  niveau_liquidite?: string | null;
};

export type TrajectorySignalGate = {
  scpi_slug: string;
  data_gate: string | null;
  structural_gate: string | null;
  semantic_gate: string | null;
  liquidity_gate: string | null;
  liquidity_signal_eligible: boolean | null;
};

export const normalizeLiquidityBasis = (basis?: string | null, capitalType?: string | null) => {
  if (basis?.startsWith('secondary_market_order_book')) return 'secondary_market_order_book';
  if (basis?.startsWith('fixed_capital')) return 'fixed_capital_market';
  if (basis?.startsWith('withdrawal_queue')) return 'withdrawal_queue';
  if (basis) return null;
  if (capitalType === 'fixe') return 'fixed_capital_market';
  if (capitalType === 'variable') return 'withdrawal_queue';
  return null;
};

export const toFiniteNumber = (value: unknown): number | null => {
  if (value === null || value === undefined || value === '') return null;
  const number = typeof value === 'number' ? value : Number(String(value).replace(',', '.'));
  return Number.isFinite(number) ? number : null;
};

export const parsePeriod = (period: string | null | undefined) => {
  if (!period) return null;
  const trimmed = period.trim();
  const canonical = trimmed.match(/^(\d{4})[- ]?T([1-4])$/i);
  if (canonical) {
    const year = Number(canonical[1]);
    const quarter = Number(canonical[2]);
    return { key: `${year}-T${quarter}`, ordinal: year * 4 + quarter };
  }
  const alternate = trimmed.match(/^T([1-4])[- ]?(\d{4})$/i);
  if (alternate) {
    const quarter = Number(alternate[1]);
    const year = Number(alternate[2]);
    return { key: `${year}-T${quarter}`, ordinal: year * 4 + quarter };
  }
  return null;
};

const rowTimestamp = (row: ScpiHistoryRow) => {
  if (!row.snapshot_at) return 0;
  const timestamp = Date.parse(row.snapshot_at);
  return Number.isFinite(timestamp) ? timestamp : 0;
};

const rowQuality = (row: ScpiHistoryRow) => {
  const confidence = toFiniteNumber(row.source_confidence) ?? 0;
  const qa = (row.qa_status || '').toLowerCase();
  const verified = qa.includes('verified') ? 2 : qa.includes('certified') ? 1 : 0;
  return verified * 100 + confidence;
};

export const isPublishableHistoryRow = (row: ScpiHistoryRow) => {
  const qa = (row.qa_status || '').toLowerCase();
  const confidence = toFiniteNumber(row.source_confidence);
  return Boolean(
    parsePeriod(row.source_period) &&
    row.source_url &&
    !qa.startsWith('invalid') &&
    qa !== 'manual_period_correction' &&
    confidence !== null &&
    confidence >= 0.95,
  );
};

const safePercent = (value: unknown) => {
  const parsed = toFiniteNumber(value);
  return parsed !== null && parsed >= 0 && parsed <= 100 ? parsed : null;
};

const normalizeRow = (row: ScpiHistoryRow): NormalizedHistoryRow => {
  const partsAttente = toFiniteNumber(row.parts_attente_retrait);
  const nombreParts = toFiniteNumber(row.nombre_parts);
  const basis = normalizeLiquidityBasis(row.liquidity_basis, row.capital_type);
  const rawRetraitPct = basis === 'withdrawal_queue' && partsAttente !== null && nombreParts !== null && nombreParts > 0
    ? (partsAttente / nombreParts) * 100
    : null;
  const retraitPct = rawRetraitPct !== null && rawRetraitPct >= 0 && rawRetraitPct <= 100 ? rawRetraitPct : null;

  return {
    ...row,
    tof: safePercent(row.tof),
    td: toFiniteNumber(row.td),
    capitalisation: toFiniteNumber(row.capitalisation),
    prix_souscription: toFiniteNumber(row.prix_souscription),
    prix_reconstitution: toFiniteNumber(row.prix_reconstitution),
    prix_retrait: toFiniteNumber(row.prix_retrait),
    valeur_realisation: toFiniteNumber(row.valeur_realisation),
    endettement: safePercent(row.endettement),
    distribution_par_part: toFiniteNumber(row.distribution_par_part),
    parts_attente_retrait: partsAttente,
    nombre_parts: nombreParts,
    source_confidence: toFiniteNumber(row.source_confidence),
    liquidity_basis: basis,
    retrait_attente_pct: basis === 'withdrawal_queue'
      ? (Object.prototype.hasOwnProperty.call(row, 'retrait_attente_pct') ? safePercent(row.retrait_attente_pct) : retraitPct)
      : null,
    liquidity_pressure_pct: basis === 'withdrawal_queue' || basis === 'secondary_market_order_book'
      ? safePercent(row.liquidity_pressure_pct)
      : null,
  };
};

/** The current certified snapshot is authoritative; no raw fallback on missing gates. */
export const applyCertifiedLiquidity = (
  rows: NormalizedHistoryRow[],
  snapshot: CertifiedLiquiditySnapshot | null,
  gate: TrajectorySignalGate | null,
): NormalizedHistoryRow[] => {
  const usableGate = gate?.data_gate === 'PASS' && gate.structural_gate === 'PASS' && gate.semantic_gate === 'PASS'
    && gate.liquidity_gate?.startsWith('PASS');
  if (!snapshot || !usableGate) {
    return rows.map((row) => ({ ...row, retrait_attente_pct: null, liquidity_pressure_pct: null }));
  }
  const snapshotPeriod = parsePeriod(snapshot.source_period)?.key;
  const usableLevel = ['trajectory_certified', 'level_only', 'stale_last_known'].includes(snapshot.signal_certification || '');
  return rows.map((row) => {
    if (parsePeriod(row.source_period)?.key !== snapshotPeriod) return row;
    const basis = normalizeLiquidityBasis(snapshot.liquidity_basis);
    return {
      ...row,
      liquidity_basis: basis,
      retrait_attente_pct: usableLevel && basis === 'withdrawal_queue' ? safePercent(snapshot.retrait_attente_pct) : null,
      liquidity_pressure_pct: usableLevel && (basis === 'withdrawal_queue' || basis === 'secondary_market_order_book')
        ? safePercent(snapshot.liquidity_pressure_pct) : null,
    };
  });
};

/**
 * Absence de base ≠ changement de régime : ne jamais qualifier d'« non comparable »
 * une donnée dont la méthode n'a simplement pas été renseignée.
 */
export const liquidityLabel = (basis?: string | null) => basis === 'secondary_market_order_book'
  ? 'Pression du marché secondaire'
  : basis === 'withdrawal_queue' ? 'File de retraits'
    : basis === 'fixed_capital_market' ? 'Marché secondaire (capital fixe)'
      : 'Base non documentée';

/** Évite d'afficher 0 % pour une file de retraits réellement positive mais faible. */
export const formatLiquidityPercent = (value: number | null): string => {
  if (value === null || !Number.isFinite(value)) return 'N.D.';
  if (value > 0 && value < 0.01) return '< 0,01 %';
  return `${value.toLocaleString('fr-FR', { maximumFractionDigits: 2 })} %`;
};

export const normalizeAndDedupeHistory = (rows: ScpiHistoryRow[]): NormalizedHistoryRow[] => {
  const byPeriod = new Map<string, ScpiHistoryRow>();
  rows.filter(isPublishableHistoryRow).forEach((row) => {
    const parsed = parsePeriod(row.source_period);
    if (!parsed) return;
    const current = byPeriod.get(parsed.key);
    if (!current || rowQuality(row) > rowQuality(current) || (rowQuality(row) === rowQuality(current) && rowTimestamp(row) >= rowTimestamp(current))) {
      byPeriod.set(parsed.key, row);
    }
  });
  return Array.from(byPeriod.values())
    .sort((a, b) => (parsePeriod(a.source_period)?.ordinal || 0) - (parsePeriod(b.source_period)?.ordinal || 0))
    .map(normalizeRow);
};

export const formatPeriod = (period: string | null | undefined) => {
  const parsed = parsePeriod(period);
  if (!parsed) return period || 'N.D.';
  const [year, quarter] = parsed.key.split('-T');
  return `T${quarter} ${year}`;
};

export const humanizeSlug = (slug: string) => slug.split('-').filter(Boolean).map((part) => part.charAt(0).toUpperCase() + part.slice(1)).join(' ');

export const metricObservations = (rows: NormalizedHistoryRow[], key: keyof NormalizedHistoryRow) => rows
  .map((row) => ({ row, value: toFiniteNumber(row[key]), period: parsePeriod(row.source_period) }))
  .filter((item): item is { row: NormalizedHistoryRow; value: number; period: { key: string; ordinal: number } } => item.value !== null && item.period !== null);

export const latestDelta = (rows: NormalizedHistoryRow[], key: keyof NormalizedHistoryRow, lookback = 4): number | null => {
  const latestRow = rows[rows.length - 1];
  if (!latestRow || toFiniteNumber(latestRow[key]) === null) return null;
  const observations = metricObservations(rows, key);
  if (observations.length < 2) return null;
  const latest = observations[observations.length - 1];
  const targetOrdinal = latest.period.ordinal - lookback;
  const exact = observations.find((item) => item.period.ordinal === targetOrdinal);
  if (!exact) return null;
  if (key === 'retrait_attente_pct' || key === 'liquidity_pressure_pct') {
    const comparableRows = rows.filter((row) => {
      const ordinal = parsePeriod(row.source_period)?.ordinal;
      return ordinal !== undefined && ordinal >= targetOrdinal && ordinal <= latest.period.ordinal;
    });
    if (!latest.row.liquidity_basis || comparableRows.some((row) => row.liquidity_basis !== latest.row.liquidity_basis)) return null;
  }
  return latest.value - exact.value;
};

/** Never backfill a current liquidity signal with an older withdrawal regime. */
export const currentCertifiedLiquidity = (
  rows: NormalizedHistoryRow[],
  snapshot: CertifiedLiquiditySnapshot | null,
  gate: TrajectorySignalGate | null,
) => {
  const certified = applyCertifiedLiquidity(rows, snapshot, gate);
  const latest = certified[certified.length - 1];
  const basis = latest?.liquidity_basis ?? null;
  const key = basis === 'secondary_market_order_book' ? 'liquidity_pressure_pct' : 'retrait_attente_pct';
  const value = latest?.[key] ?? null;
  const eligible = gate?.liquidity_signal_eligible === true
    && snapshot?.signal_certification === 'trajectory_certified' && !snapshot.regime_changed;
  return { basis, value, delta: eligible ? latestDelta(certified, key, 4) : null };
};

export const latestSequentialDelta = (rows: NormalizedHistoryRow[], key: keyof NormalizedHistoryRow): number | null => {
  const observations = metricObservations(rows, key);
  if (observations.length < 2) return null;
  const latest = observations[observations.length - 1];
  const previous = observations[observations.length - 2];
  if (latest.period.ordinal - previous.period.ordinal !== 1) return null;
  return latest.value - previous.value;
};

export const hasTrajectoryDepth = (rows: NormalizedHistoryRow[], key: keyof NormalizedHistoryRow, minimumPoints = 4) => {
  const observations = metricObservations(rows, key);
  return observations.length >= minimumPoints;
};

export const getNumericSeries = (rows: NormalizedHistoryRow[], key: keyof NormalizedHistoryRow) => metricObservations(rows, key).map((item) => item.value);

export const formatSigned = (value: number | null, suffix = '') => {
  if (value === null || !Number.isFinite(value)) return 'N.D.';
  const sign = value > 0 ? '+' : '';
  return `${sign}${value.toLocaleString('fr-FR', { maximumFractionDigits: 2 })}${suffix}`;
};

export const valuationGapPct = (price: number | null, reconstitution: number | null): number | null => {
  if (price === null || reconstitution === null || reconstitution === 0) return null;
  return ((price - reconstitution) / reconstitution) * 100;
};
