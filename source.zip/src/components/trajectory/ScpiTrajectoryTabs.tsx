import React, { useEffect, useMemo, useState } from 'react';
import {
  Activity,
  AlertTriangle,
  BarChart3,
  Database,
  Gauge,
  LineChart as LineChartIcon,
  Scale,
  TrendingUp,
} from 'lucide-react';
import { supabase } from '../../lib/supabase';
import ScpiTrajectoryPanel from './ScpiTrajectoryPanel';
import { scpiData } from '../../data/scpiData';
import { createSlugFromName } from '../../utils/scpiSlugMapper';
import { getScpiDatedDiscount } from '../../utils/scpiDatedDiscount';
import {
  CERTIFIED_HISTORY_SELECT,
  CertifiedLiquiditySnapshot,
  NormalizedHistoryRow,
  ScpiHistoryRow,
  TrajectorySignalGate,
  applyCertifiedLiquidity,
  currentCertifiedLiquidity,
  formatPeriod,
  formatSigned,
  latestDelta,
  latestSequentialDelta,
  liquidityLabel,
  normalizeAndDedupeHistory,
  valuationGapPct,
} from './trajectoryData';

type TabKey = 'trajectory' | 'market';
type Tone = 'positive' | 'neutral' | 'watch' | 'unavailable';

type Signal = {
  title: string;
  value: string;
  detail: string;
  tone: Tone;
  icon: React.ReactNode;
};

const toneClasses: Record<Tone, string> = {
  positive: 'border-emerald-500/25 bg-emerald-500/5',
  neutral: 'border-sky-500/20 bg-sky-500/5',
  watch: 'border-amber-500/30 bg-amber-500/5',
  unavailable: 'border-slate-700 bg-slate-900/40',
};

const toneLabel: Record<Tone, string> = {
  positive: 'Solide',
  neutral: 'Neutre',
  watch: 'À surveiller',
  unavailable: 'Donnée insuffisante',
};

const toneLabelClasses: Record<Tone, string> = {
  positive: 'text-emerald-300 border-emerald-500/30 bg-emerald-500/10',
  neutral: 'text-sky-300 border-sky-500/30 bg-sky-500/10',
  watch: 'text-amber-300 border-amber-500/30 bg-amber-500/10',
  unavailable: 'text-slate-400 border-slate-700 bg-slate-800/60',
};

const latestNumeric = (
  rows: NormalizedHistoryRow[],
  key: keyof NormalizedHistoryRow,
): number | null => {
  for (let i = rows.length - 1; i >= 0; i -= 1) {
    const raw = rows[i][key];
    if (typeof raw === 'number' && Number.isFinite(raw)) return raw;
  }
  return null;
};

const latestRowWith = (
  rows: NormalizedHistoryRow[],
  predicate: (row: NormalizedHistoryRow) => boolean,
) => {
  for (let i = rows.length - 1; i >= 0; i -= 1) {
    if (predicate(rows[i])) return rows[i];
  }
  return null;
};

const formatNumber = (value: number | null, suffix = '', digits = 2) =>
  value === null
    ? 'N.D.'
    : `${value.toLocaleString('fr-FR', { maximumFractionDigits: digits })}${suffix}`;


const findPublishedPartialScpi = (slug: string) => scpiData.find(
  (item) => createSlugFromName(item.name) === slug && item.maximusPublicationStatus === 'published_with_reserves',
);

/** Une source officielle partielle est visible sans être réinjectée dans les séries certifiées. */
const PartialCurrentFacts: React.FC<{ scpiSlug: string }> = ({ scpiSlug }) => {
  const current = findPublishedPartialScpi(scpiSlug);
  if (!current) return null;
  const dated = getScpiDatedDiscount(current);
  const source = current.metricProvenance?.tof?.source_url;
  const sourceUrl = typeof source === 'string' && source.startsWith('https://') ? source : null;
  return (
    <div data-testid="scpi-partial-current-facts" className="mx-4 mt-4 rounded-xl border border-sky-500/20 bg-slate-900/70 p-4 text-slate-200 sm:mx-5">
      <div className="text-sm font-semibold text-white">
        Dernier bulletin officiel : {current.maximusSourcePeriode || 'période à préciser'}
      </div>
      <p className="mt-1 text-xs leading-5 text-slate-400">
        Niveaux observés et datés. Ces valeurs ne sont pas assimilées à des points d'une trajectoire certifiée
        tant que les contrôles de comparaison ne sont pas terminés.
      </p>
      <div className="mt-3 grid grid-cols-2 gap-3 text-sm sm:grid-cols-5">
        <div><span className="block text-xs text-slate-400">TOF</span><strong>{formatNumber(current.tof ?? null, ' %')}</strong></div>
        <div><span className="block text-xs text-slate-400">Prix de souscription</span><strong>{formatNumber(current.price, ' €')}</strong></div>
        <div><span className="block text-xs text-slate-400">Reconstitution</span><strong>{formatNumber(current.valeurReconstitution ?? null, ' €')}</strong></div>
        <div><span className="block text-xs text-slate-400">Endettement</span><strong>{formatNumber(current.debt ?? null, ' %')}</strong></div>
        <div><span className="block text-xs text-slate-400">{dated?.label ?? 'Décote / surcote'}</span><strong>{dated?.formatted ?? 'Non certifiée'}</strong></div>
      </div>
      {dated && <p className="mt-3 text-xs text-slate-400">{dated.comparisonLabel}</p>}
      {sourceUrl && <a href={sourceUrl} target="_blank" rel="noopener noreferrer" className="mt-2 inline-block text-xs text-sky-300 underline">Bulletin officiel</a>}
    </div>
  );
};

const MarketSignalsPanel: React.FC<{ scpiSlug: string }> = ({ scpiSlug }) => {
  const [rows, setRows] = useState<ScpiHistoryRow[]>([]);
  const [liquiditySnapshot, setLiquiditySnapshot] = useState<CertifiedLiquiditySnapshot | null>(null);
  const [signalGate, setSignalGate] = useState<TrajectorySignalGate | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;

    const load = async () => {
      setLoading(true);
      setRows([]);
      setLiquiditySnapshot(null);
      setSignalGate(null);
      if (!supabase || !scpiSlug) {
        if (!cancelled) setLoading(false);
        return;
      }

      const [historyResult, liquidityResult, gateResult] = await Promise.all([
        supabase
        .from('scpi_trajectory_pilot_history')
        .select(CERTIFIED_HISTORY_SELECT)
        .eq('scpi_slug', scpiSlug)
        .order('snapshot_at', { ascending: true })
        .limit(80),
        supabase.from('scpi_trajectory_pilot_liquidity')
          .select('scpi_slug,source_period,liquidity_basis,liquidity_pressure_pct,retrait_attente_pct,regime_changed,signal_certification,niveau_liquidite')
          .eq('scpi_slug', scpiSlug).maybeSingle(),
        supabase.from('scpi_trajectory_signal_gate')
          .select('scpi_slug,data_gate,structural_gate,semantic_gate,liquidity_gate,liquidity_signal_eligible')
          .eq('scpi_slug', scpiSlug).maybeSingle(),
      ]);

      if (cancelled) return;
      if (historyResult.error) {
        console.warn('[MarketSignalsPanel] Historique indisponible.', historyResult.error);
        setLoading(false);
        return;
      }

      setRows((historyResult.data || []) as unknown as ScpiHistoryRow[]);
      if (!liquidityResult.error && !gateResult.error) {
        setLiquiditySnapshot(liquidityResult.data as CertifiedLiquiditySnapshot | null);
        setSignalGate(gateResult.data as TrajectorySignalGate | null);
      }
      setLoading(false);
    };

    void load();
    return () => {
      cancelled = true;
    };
  }, [scpiSlug]);

  const history = useMemo(() => applyCertifiedLiquidity(normalizeAndDedupeHistory(rows), liquiditySnapshot, signalGate), [rows, liquiditySnapshot, signalGate]);
  const hasRestrictedComparison = findPublishedPartialScpi(scpiSlug)?.maximusDisabledFeatures?.includes('uncertified_history_comparison') === true;

  const signals = useMemo<Signal[]>(() => {
    const { value: liquidity, delta: liquidityDelta, basis: liquidityBasis } = currentCertifiedLiquidity(history, liquiditySnapshot, signalGate);
    const tof = latestNumeric(history, 'tof');
    const tofAnnualDelta = latestDelta(history, 'tof', 4);
    const tofQuarterlyDelta = latestSequentialDelta(history, 'tof');
    const tofDelta = tofAnnualDelta ?? tofQuarterlyDelta;
    const tofDeltaLabel = tofAnnualDelta !== null ? 'Sur un an'
      : tofQuarterlyDelta !== null ? 'Sur le trimestre' : 'Variation non calculable';
    const debt = latestNumeric(history, 'endettement');

    const valuationRow = latestRowWith(
      history,
      (row) => row.prix_souscription !== null && row.prix_reconstitution !== null,
    );
    const valuationGap = valuationRow
      ? valuationGapPct(valuationRow.prix_souscription, valuationRow.prix_reconstitution)
      : null;

    const capObservations = history.filter((row) => row.capitalisation !== null && Number.isFinite(row.capitalisation));
    const caps = capObservations.map((row) => row.capitalisation as number);
    const currentCap = caps.length ? caps[caps.length - 1] : null;
    const previousCap = caps.length >= 2 ? caps[Math.max(0, caps.length - 5)] : null;
    const capDeltaPct =
      currentCap !== null && previousCap !== null && previousCap !== 0
        ? ((currentCap - previousCap) / previousCap) * 100
        : null;

    const capPeriodLabel = capObservations.length >= 2
      ? `${formatPeriod(capObservations[Math.max(0, capObservations.length-5)].source_period)} → ${formatPeriod(capObservations[capObservations.length-1].source_period)}`
      : null;

    const liquidityTone: Tone =
      liquidity === null
        ? 'unavailable'
        : liquidityBasis === 'secondary_market_order_book'
          ? liquiditySnapshot?.niveau_liquidite?.startsWith('tension') ? 'watch' : 'neutral'
        : liquidity >= 2 || (liquidityDelta !== null && liquidityDelta >= 0.5)
          ? 'watch'
          : liquidity <= 0.25 && (liquidityDelta === null || liquidityDelta <= 0.1)
            ? 'positive'
            : 'neutral';

    const tofTone: Tone =
      tof === null
        ? 'unavailable'
        : tof < 90 || (tofDelta !== null && tofDelta <= -2)
          ? 'watch'
          : tof >= 95 && (tofDelta === null || tofDelta >= -0.5)
            ? 'positive'
            : 'neutral';

    const valuationTone: Tone =
      valuationGap === null
        ? 'unavailable'
        : valuationGap > 5
          ? 'watch'
          : Math.abs(valuationGap) <= 5
            ? 'neutral'
            : 'positive';

    const capTone: Tone =
      capDeltaPct === null
        ? 'unavailable'
        : capDeltaPct > 25
          ? 'watch'
          : 'neutral';

    const debtTone: Tone =
      debt === null
        ? 'unavailable'
        : debt >= 35
          ? 'watch'
          : debt <= 20
            ? 'positive'
            : 'neutral';

    return [
      {
        title: liquidityLabel(liquidityBasis),
        value: formatNumber(liquidity, ' %', 3),
        detail:
          liquidity === null
            ? liquiditySnapshot?.regime_changed
              ? 'Changement de régime : données du nouveau marché en attente. Une file annulée ne démontre pas une amélioration.'
              : 'Données de liquidité courantes non exploitables ; aucune ancienne file n’est reprise.'
            : liquidityBasis === 'secondary_market_order_book'
              ? `Pression du marché secondaire, distincte de la file de retraits. Variation sur un an : ${formatSigned(liquidityDelta, ' pt')}.`
            : liquidity === 0
              ? 'Aucune tension visible dans la file de retrait publiée ; cela ne garantit pas la liquidité future.'
              : `Variation sur un an : ${formatSigned(liquidityDelta, ' pt')}.`,
        tone: liquidityTone,
        icon: <Activity className="h-5 w-5" />,
      },
      {
        title: 'Occupation locative',
        value: formatNumber(tof, ' %'),
        detail:
          tof === null
            ? 'TOF historique insuffisant.'
            : tofDelta === null
              ? 'Variation non calculable sur les périodes disponibles.'
              : `${tofDeltaLabel} : ${formatSigned(tofDelta, ' pt')}.`,
        tone: tofTone,
        icon: <Gauge className="h-5 w-5" />,
      },
      {
        title: 'Prix / valeur de reconstitution',
        value: valuationGap === null ? 'N.D.' : formatSigned(valuationGap, ' %'),
        detail:
          valuationGap === null
            ? 'Comparaison prix / reconstitution indisponible sur une même période.'
            : valuationGap > 0
              ? 'Le prix de souscription est au-dessus de la valeur de reconstitution observée.'
              : 'Le prix de souscription est sous la valeur de reconstitution observée.',
        tone: valuationTone,
        icon: <Scale className="h-5 w-5" />,
      },
      {
        title: 'Dynamique de capitalisation',
        value: capDeltaPct === null ? 'N.D.' : formatSigned(capDeltaPct, ' %'),
        detail:
          capDeltaPct === null
            ? 'Historique de capitalisation insuffisant.'
            : capDeltaPct > 25
              ? `Croissance rapide (${capPeriodLabel ?? 'périodes comparables'}) : contrôler déploiement de la collecte et acquisitions.`
              : `Évolution sur ${capPeriodLabel ?? 'les observations disponibles'} ; aucune extrapolation annuelle.`,
        tone: capTone,
        icon: <TrendingUp className="h-5 w-5" />,
      },
      {
        title: 'Endettement',
        value: formatNumber(debt, ' %'),
        detail:
          debt === null
            ? 'Donnée d’endettement historique insuffisante.'
            : 'Lecture de résilience financière ; à rapprocher des échéances et du coût de la dette.',
        tone: debtTone,
        icon: <BarChart3 className="h-5 w-5" />,
      },
    ];
  }, [history, liquiditySnapshot, signalGate]);

  const watchCount = signals.filter((signal) => signal.tone === 'watch').length;
  const availableCount = signals.filter((signal) => signal.tone !== 'unavailable').length;
  const latestPeriod = history.length ? formatPeriod(history[history.length - 1]?.source_period) : 'N.D.';

  if (loading) {
    return <div className="h-64 animate-pulse rounded-xl border border-slate-800 bg-slate-900/60" />;
  }
  if (hasRestrictedComparison) {
    return (
      <div data-testid="scpi-market-signals-not-comparable" className="rounded-xl border border-slate-700 bg-slate-900/60 p-5">
        <h3 className="text-sm font-semibold text-white">Signaux du marché : comparaisons non certifiées</h3>
        <p className="mt-2 text-xs leading-5 text-slate-300">
          {history.length} période(s) historique(s) admissible(s). Les derniers niveaux du bulletin officiel figurent ci-dessus,
          mais ils ne déclenchent ni tendance ni alerte automatique tant que les comparaisons historiques ne sont pas certifiées.
          Cette absence de signal ne signifie pas une absence de risque.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <div className="text-sm font-bold text-white">Signaux du marché de la SCPI</div>
          <p className="mt-1 max-w-3xl text-xs leading-5 text-slate-400">
            Lecture dynamique des signaux observables dans les publications de la SCPI : retraits, occupation, valorisation, capitalisation et dette.
          </p>
        </div>
        <div className="inline-flex w-fit items-center gap-2 rounded-lg border border-slate-800 bg-slate-900/70 px-3 py-2 text-[11px] text-slate-400">
          <Database className="h-4 w-4" />
          Dernière période : {latestPeriod}
        </div>
      </div>

      <div
        className={
          watchCount > 0
            ? 'rounded-xl border border-amber-500/25 bg-amber-500/5 p-4'
            : 'rounded-xl border border-emerald-500/20 bg-emerald-500/5 p-4'
        }
      >
        <div className="flex items-start gap-3">
          {watchCount > 0 ? (
            <AlertTriangle className="mt-0.5 h-5 w-5 flex-none text-amber-300" />
          ) : (
            <Activity className="mt-0.5 h-5 w-5 flex-none text-emerald-300" />
          )}
          <div>
            <div className="text-sm font-bold text-white">
              {watchCount > 0
                ? `${watchCount} signal${watchCount > 1 ? 'aux' : ''} à surveiller`
                : 'Pas de signal de tension majeur sur les données disponibles'}
            </div>
            <p className="mt-1 text-xs leading-5 text-slate-400">
              {availableCount}/5 indicateurs exploitables. Les seuils affichés sont des repères d’analyse MaximusSCPI, pas des seuils réglementaires ni une prévision de performance.
            </p>
          </div>
        </div>
      </div>

      <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-5">
        {signals.map((signal) => (
          <div key={signal.title} className={`rounded-xl border p-4 ${toneClasses[signal.tone]}`}>
            <div className="flex items-start justify-between gap-2">
              <div className="text-slate-300">{signal.icon}</div>
              <span className={`rounded-full border px-2 py-1 text-[9px] font-bold uppercase tracking-wide ${toneLabelClasses[signal.tone]}`}>
                {toneLabel[signal.tone]}
              </span>
            </div>
            <div className="mt-4 text-xs font-semibold text-slate-400">{signal.title}</div>
            <div className="mt-1 text-xl font-bold text-white">{signal.value}</div>
            <p className="mt-2 text-[11px] leading-4 text-slate-500">{signal.detail}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

const ScpiTrajectoryTabs: React.FC<{ scpiSlug: string }> = ({ scpiSlug }) => {
  const [activeTab, setActiveTab] = useState<TabKey>('trajectory');

  return (
    <section className="px-6 pb-6" data-maximus-analysis-tabs="true">
      <div className="overflow-hidden rounded-xl border border-slate-700 bg-slate-900/45 shadow-lg">
        <PartialCurrentFacts scpiSlug={scpiSlug} />
        <div className="border-b border-slate-800 px-4 pt-4 sm:px-5">
          <div className="mb-3 flex items-center gap-2 text-[11px] font-bold uppercase tracking-[0.16em] text-sky-300">
            <LineChartIcon className="h-4 w-4" />
            Analyse dynamique
          </div>
          <div className="flex gap-2 overflow-x-auto">
            <button
              type="button"
              onClick={() => setActiveTab('trajectory')}
              className={
                activeTab === 'trajectory'
                  ? 'border-b-2 border-sky-400 px-3 pb-3 text-sm font-bold text-white'
                  : 'border-b-2 border-transparent px-3 pb-3 text-sm font-semibold text-slate-500 hover:text-slate-300'
              }
            >
              Trajectoire
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('market')}
              className={
                activeTab === 'market'
                  ? 'border-b-2 border-sky-400 px-3 pb-3 text-sm font-bold text-white'
                  : 'border-b-2 border-transparent px-3 pb-3 text-sm font-semibold text-slate-500 hover:text-slate-300'
              }
            >
              Signaux du marché de la SCPI
            </button>
          </div>
        </div>

        <div className="p-4 sm:p-5">
          {activeTab === 'trajectory' ? (
            <div className="[&>section]:border-0 [&>section]:bg-transparent [&>section]:py-0 [&>section>div]:px-0">
              <ScpiTrajectoryPanel scpiSlug={scpiSlug} />
            </div>
          ) : (
            <MarketSignalsPanel scpiSlug={scpiSlug} />
          )}
        </div>
      </div>
    </section>
  );
};

export default ScpiTrajectoryTabs;
