import React, { useEffect, useMemo, useState } from 'react';
import {
  CartesianGrid,
  Legend,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { Activity, Database, LineChart as LineChartIcon } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { scpiData } from '../../data/scpiData';
import { getVerifiedAnnualRows } from './scpiAnnualHistoryData';
import { ScpiAnnualHistorySection } from './ScpiAnnualHistorySection';
import { ScpiLeaseDurations } from './ScpiLeaseDurations';
import { metricDateLabel } from '../../utils/scpiFinancialProvenance';
import {
  CERTIFIED_HISTORY_SELECT,
  CertifiedLiquiditySnapshot,
  ScpiHistoryRow,
  TrajectorySignalGate,
  applyCertifiedLiquidity,
  currentCertifiedLiquidity,
  formatPeriod,
  formatLiquidityPercent,
  formatSigned,
  latestMetricSnapshot,
  latestValuationSnapshot,
  liquidityLabel,
  normalizeAndDedupeHistory,
} from './trajectoryData';

type MetricKey = 'tof' | 'liquidite' | 'valorisation' | 'distribution' | 'dette';

type ScpiTrajectoryPanelProps = {
  scpiSlug: string;
};

const metricTabs: Array<{ key: MetricKey; label: string }> = [
  { key: 'tof', label: 'TOF' },
  { key: 'liquidite', label: 'Liquidité' },
  { key: 'valorisation', label: 'Valorisation' },
  { key: 'distribution', label: 'Distribution' },
  { key: 'dette', label: 'Dette' },
];

const numberFormatter = (value: number | null, suffix = '', maxDigits = 2) =>
  value === null
    ? 'N.D.'
    : `${value.toLocaleString('fr-FR', { maximumFractionDigits: maxDigits })}${suffix}`;

const ScpiTrajectoryPanel: React.FC<ScpiTrajectoryPanelProps> = ({ scpiSlug }) => {
  const [activeMetric, setActiveMetric] = useState<MetricKey>('tof');
  const [rows, setRows] = useState<ScpiHistoryRow[]>([]);
  const [liquidity, setLiquidity] = useState<CertifiedLiquiditySnapshot | null>(null);
  const [signalGate, setSignalGate] = useState<TrajectorySignalGate | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;

    const load = async () => {
      setLoading(true);
      setRows([]);
      setLiquidity(null);
      setSignalGate(null);
      if (!supabase || !scpiSlug) {
        if (!cancelled) setLoading(false);
        return;
      }

      const [historyResult, liquidityResult, gateResult] = await Promise.all([
        supabase
        .from('scpi_trajectory_pilot_history')
        .select(CERTIFIED_HISTORY_SELECT)
        .eq('scpi_slug', scpiSlug)
        .order('snapshot_at', { ascending: true })
        .limit(80),
        supabase.from('scpi_trajectory_pilot_liquidity')
          .select('scpi_slug,source_period,liquidity_basis,liquidity_pressure_pct,retrait_attente_pct,regime_changed,signal_certification')
          .eq('scpi_slug', scpiSlug).maybeSingle(),
        supabase.from('scpi_trajectory_signal_gate')
          .select('scpi_slug,data_gate,structural_gate,semantic_gate,liquidity_gate,liquidity_signal_eligible')
          .eq('scpi_slug', scpiSlug).maybeSingle(),
      ]);

      if (cancelled) return;
      if (historyResult.error) {
        console.warn('[ScpiTrajectoryPanel] Historique indisponible.', historyResult.error);
        setLoading(false);
        return;
      }

      setRows((historyResult.data || []) as unknown as ScpiHistoryRow[]);
      if (liquidityResult.error || gateResult.error) {
        console.warn('[ScpiTrajectoryPanel] Contexte de liquidité indisponible : ratios masqués.');
      } else {
        setLiquidity(liquidityResult.data as CertifiedLiquiditySnapshot | null);
        setSignalGate(gateResult.data as TrajectorySignalGate | null);
      }
      setLoading(false);
    };

    void load();
    return () => {
      cancelled = true;
    };
  }, [scpiSlug]);

  const currentScpi = useMemo(() => scpiData.find((row) =>
    row.name.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '') === scpiSlug
  ), [scpiSlug]);
  const annualRows = useMemo(() => getVerifiedAnnualRows(scpiSlug), [scpiSlug]);
  const annualChartData = useMemo(() => annualRows.map(r => ({
    year: String(r.fiscal_year),
    valeur_realisation: r.valeur_realisation_par_part,
    prix_reconstitution: r.valeur_reconstitution_par_part,
  })), [annualRows]);
  const history = useMemo(() => applyCertifiedLiquidity(normalizeAndDedupeHistory(rows), liquidity, signalGate), [rows, liquidity, signalGate]);
  const recentHistory = useMemo(() => history.slice(-16), [history]);
  const latest = history[history.length - 1] || null;
  // A quarterly bulletin can repeat a valuation stopped at an earlier date.
  // Keep quarterly observations sparse; show the prior publisher valuation only
  // with its actual reference date, never as a new quarterly NAV.
  const priorValuation = (row: typeof history[number], field: 'prix_reconstitution' | 'valeur_realisation') => {
    const rowIndex = history.findIndex((item) => item.source_period === row.source_period);
    for (let pos = rowIndex - 1; pos >= 0; pos--) {
      const prior = history[pos];
      const value = prior[field];
      if (value !== null && Number.isFinite(value)) {
        return {
          value,
          date: prior.metric_provenance?.[field]?.reference_date || null,
          period: prior.source_period,
          sourceUrl: prior.metric_provenance?.[field]?.source_url || prior.source_url,
        };
      }
    }
    return null;
  };

  const chartData = useMemo(
    () =>
      recentHistory.map((row) => ({
        period: formatPeriod(row.source_period),
        tof: row.tof,
        retrait_attente_pct: row.retrait_attente_pct,
        secondary_pressure_pct: row.liquidity_basis === 'secondary_market_order_book' ? row.liquidity_pressure_pct : null,
        prix_souscription: row.prix_souscription,
        prix_reconstitution: row.prix_reconstitution,
        valeur_realisation: row.valeur_realisation,
        distribution_par_part: row.distribution_par_part,
        endettement: row.endettement,
      })),
    [recentHistory],
  );

  const tofSnapshot = latestMetricSnapshot(history, 'tof');
  const distributionSnapshot = latestMetricSnapshot(history, 'distribution_par_part');
  const debtSnapshot = latestMetricSnapshot(history, 'endettement');
  const valuationSnapshot = latestValuationSnapshot(history);
  const realisationSnapshot = latestMetricSnapshot(history, 'valeur_realisation');
  const { value: liquidityValue, delta: liquidityDelta } = currentCertifiedLiquidity(history, liquidity, signalGate);

  const reference = (snapshot: { period: string | null; sourceUrl: string | null; isLastKnown: boolean; referenceDate?: string } | null) => (
    <div className="mt-2 text-[11px] leading-4 text-slate-400">
      {snapshot ? <>
        <span className="block">{snapshot.isLastKnown ? 'Dernière valeur connue · ' : 'Observation · '}{formatPeriod(snapshot.period)}</span>
        {snapshot.referenceDate && <span className="block">Valeur arrêtée au {metricDateLabel(snapshot.referenceDate)}</span>}
        {snapshot.isLastKnown && <span className="block text-amber-300">{formatPeriod(latest?.source_period)} : donnée non renseignée ou non validée</span>}
        {snapshot.sourceUrl && <a href={snapshot.sourceUrl} target="_blank" rel="noopener noreferrer" className="text-sky-300 underline">
          {snapshot.sourceUrl.includes('francescpi.com/') ? "Document de l'émetteur (copie archivée) ↗" : 'Source officielle ↗'}
        </a>}
      </> : 'Aucune observation disponible'}
    </div>
  );

  if (loading) {
    return (
      <section className="border-y border-slate-800 bg-slate-950 py-10">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="h-56 animate-pulse rounded-2xl border border-slate-800 bg-slate-900/60" />
        </div>
      </section>
    );
  }

  const comparisonRestricted = currentScpi?.maximusDisabledFeatures?.includes('uncertified_history_comparison') === true;
  if (history.length < 2 || comparisonRestricted) {
    return (
      <section id="trajectoire-scpi" data-testid="scpi-trajectory-insufficient-history" className="border-y border-slate-800 bg-slate-950 py-8 text-white">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <h3 className="text-sm font-semibold text-white">Trajectoire historique en cours de constitution</h3>
          <p className="mt-2 text-xs leading-5 text-slate-300">
            {history.length} période historique admissible.
            Une évolution nécessite au moins deux périodes comparables et certifiées : aucun tracé ni variation n'est inventé.
            Les derniers niveaux du bulletin sont affichés séparément ci-dessus avec leurs dates.
          </p>
          {history.length === 1 && (
            <p className="mt-2 text-xs text-slate-400">
              Dernière observation historique admissible : {formatPeriod(history[0].source_period)}.
            </p>
          )}
          <ScpiLeaseDurations scpiSlug={scpiSlug} className="mt-4" />
          <ScpiAnnualHistorySection scpiSlug={scpiSlug} />
        </div>
      </section>
    );
  }

  const renderChart = () => {
    if (activeMetric === 'liquidite') {
      return (
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={chartData} margin={{ top: 10, right: 12, left: 0, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.14)" />
            <XAxis dataKey="period" tick={{ fill: '#94a3b8', fontSize: 11 }} minTickGap={24} />
            <YAxis tick={{ fill: '#94a3b8', fontSize: 11 }} width={56} domain={['auto', 'auto']} />
            <Tooltip contentStyle={{ background: '#0f172a', border: '1px solid #334155', borderRadius: 10 }} labelStyle={{ color: '#e2e8f0' }} />
            <Legend wrapperStyle={{ fontSize: 12 }} />
            <Line type="linear" dataKey="retrait_attente_pct" name="File de retraits (%)" connectNulls={false} stroke="#f59e0b" strokeWidth={2.6} dot={{ r: 2.8 }} />
            <Line type="linear" dataKey="secondary_pressure_pct" name="Pression du marché secondaire (%)" connectNulls={false} stroke="#38bdf8" strokeWidth={2.6} dot={{ r: 2.8 }} />
          </LineChart>
        </ResponsiveContainer>
      );
    }
    if (activeMetric === 'valorisation' && annualChartData.length > 0) {
      // Pas de point artificiel à T1/T2 : chaque observation reflète le 31/12
      // de son exercice. Les métriques trimestrielles restent dans le tableau.
      return (
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={annualChartData} margin={{ top: 24, right: 24, left: 4, bottom: 6 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.14)" />
            <XAxis dataKey="year" tick={{ fill: '#94a3b8', fontSize: 11 }} />
            <YAxis tick={{ fill: '#94a3b8', fontSize: 11 }} width={62}
              domain={[(min: number) => Math.floor(min - Math.max(5,(Math.abs(min)*0.03))),
                (max: number) => Math.ceil(max + Math.max(5,(Math.abs(max)*0.03)))]} />
            <Tooltip contentStyle={{ background: '#0f172a', border: '1px solid #334155', borderRadius: 10 }}
              labelStyle={{ color: '#e2e8f0' }}
              formatter={(v: any) => [Number(v).toLocaleString('fr-FR', {maximumFractionDigits:2}) + ' € / part', 'Valeur']} />
            <Legend wrapperStyle={{ fontSize: 12 }} />
            <Line type="monotone" dataKey="prix_reconstitution" name="Valeur de reconstitution (31/12)"
              stroke="#34d399" strokeWidth={2.8} dot={{r:4}} activeDot={{r:6}} isAnimationActive={false} connectNulls={false} />
            <Line type="monotone" dataKey="valeur_realisation" name="Valeur de réalisation (31/12)"
              stroke="#fbbf24" strokeWidth={2.8} dot={{r:4}} activeDot={{r:6}} isAnimationActive={false} connectNulls={false} />
          </LineChart>
        </ResponsiveContainer>
      );
    }
    if (activeMetric === 'valorisation') {
      return (
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={chartData} margin={{ top: 10, right: 12, left: 0, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.14)" />
            <XAxis dataKey="period" tick={{ fill: '#94a3b8', fontSize: 11 }} minTickGap={24} />
            <YAxis tick={{ fill: '#94a3b8', fontSize: 11 }} width={56} domain={['auto', 'auto']} />
            <Tooltip
              contentStyle={{ background: '#0f172a', border: '1px solid #334155', borderRadius: 10 }}
              labelStyle={{ color: '#e2e8f0' }}
            />
            <Legend wrapperStyle={{ fontSize: 12 }} />
            <Line type="monotone" dataKey="prix_souscription" name="Prix de part" connectNulls={false} stroke="#38bdf8" strokeWidth={2.4} dot={{ r: 2.5 }} />
            <Line type="monotone" dataKey="prix_reconstitution" name="Valeur de reconstitution" connectNulls={false} stroke="#34d399" strokeWidth={2.4} dot={{ r: 2.5 }} />
            <Line type="monotone" dataKey="valeur_realisation" name="Valeur de réalisation" connectNulls={false} stroke="#fbbf24" strokeWidth={2.1} dot={{ r: 2.2 }} />
          </LineChart>
        </ResponsiveContainer>
      );
    }

    const config =
      activeMetric === 'tof'
        ? { dataKey: 'tof', name: 'TOF (%)', stroke: '#38bdf8' }
        : activeMetric === 'distribution'
            ? { dataKey: 'distribution_par_part', name: 'Distribution / part', stroke: '#34d399' }
            : { dataKey: 'endettement', name: 'Endettement (%)', stroke: '#a78bfa' };

    return (
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={chartData} margin={{ top: 10, right: 12, left: 0, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.14)" />
          <XAxis dataKey="period" tick={{ fill: '#94a3b8', fontSize: 11 }} minTickGap={24} />
          <YAxis tick={{ fill: '#94a3b8', fontSize: 11 }} width={56} domain={['auto', 'auto']} />
          <Tooltip
            contentStyle={{ background: '#0f172a', border: '1px solid #334155', borderRadius: 10 }}
            labelStyle={{ color: '#e2e8f0' }}
          />
          <Line
            type="monotone"
            dataKey={config.dataKey}
            name={config.name}
            connectNulls={false}
            stroke={config.stroke}
            strokeWidth={2.6}
            dot={{ r: 2.8 }}
            activeDot={{ r: 5 }}
          />
        </LineChart>
      </ResponsiveContainer>
    );
  };

  return (
    <section id="trajectoire-scpi" className="border-y border-slate-800 bg-slate-950 py-10 sm:py-14">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mb-6 flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
          <div>
            <div className="mb-2 inline-flex items-center gap-2 text-xs font-bold uppercase tracking-[0.16em] text-sky-300">
              <LineChartIcon className="h-4 w-4" />
              Trajectoire Maximus
            </div>
            <h2 className="text-2xl font-bold text-white sm:text-3xl">L’évolution des fondamentaux dans le temps</h2>
            <p className="mt-2 max-w-3xl text-sm leading-6 text-slate-400">
              Données historiques consolidées à partir des bulletins et documents officiels. Le graphique montre les observations disponibles, sans transformer la tendance en score supplémentaire.
            </p>
          </div>
          <div className="inline-flex items-center gap-2 rounded-lg border border-slate-800 bg-slate-900/70 px-3 py-2 text-xs text-slate-400">
            <Database className="h-4 w-4 text-slate-500" />
            {history.length} périodes observées
          </div>
        </div>

        <div className="mb-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
          <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-4">
            <div className="text-xs text-slate-500">TOF observé</div>
            <div className="mt-1 text-xl font-bold text-white">{numberFormatter(tofSnapshot?.value ?? null, ' %')}</div>
            <div className="mt-1 text-xs text-slate-400">Variation annuelle à cette date : {formatSigned(tofSnapshot?.annualDelta ?? null, ' pt')}</div>
            {reference(tofSnapshot)}
          </div>
          <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-4">
            <div className="text-xs text-slate-500">{liquidityLabel(latest?.liquidity_basis)}</div>
            <div className="mt-1 text-xl font-bold text-white">{formatLiquidityPercent(liquidityValue)}</div>
            <div className="mt-1 text-xs text-slate-400">Variation sur un an : {formatSigned(liquidityDelta, ' pt')}</div>
          </div>
          <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-4">
            <div className="text-xs text-slate-500">Prix / reconstitution</div>
            <div className="mt-1 text-xl font-bold text-white">
              {numberFormatter(valuationSnapshot?.price ?? null, ' €', 0)} / {numberFormatter(valuationSnapshot?.reconstitution ?? null, ' €')}
            </div>
            <div className="mt-1 text-xs text-slate-400">Écart {formatSigned(valuationSnapshot?.gap ?? null, ' %')}</div>
            {reference(valuationSnapshot)}
            <div className="mt-2 border-t border-slate-700 pt-2 text-xs text-slate-300">
              Réalisation : <strong>{numberFormatter(realisationSnapshot?.value ?? null, ' €')}</strong>
              {reference(realisationSnapshot)}
            </div>
            {currentScpi?.valeurRetrait !== undefined && (
              <div data-testid="trajectory-withdrawal-current" className="mt-2 border-t border-slate-700 pt-2 text-xs text-slate-200">
                Retrait par part : <strong>{numberFormatter(currentScpi.valeurRetrait, ' €')}</strong>
                <span className="block text-[10px] text-slate-400">
                  {currentScpi.retraitReferencePeriod || 'Conditions de retrait en vigueur'} · montant non garanti lors d'un retrait non compensé
                </span>
                {currentScpi.retraitSourceUrl && (
                  <a href={currentScpi.retraitSourceUrl} target="_blank" rel="noopener noreferrer"
                     className="mt-1 inline-block text-[10px] text-sky-300 underline">Source officielle du retrait</a>
                )}
              </div>
            )}
          </div>
          <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-4">
            <div className="text-xs text-slate-500">Distribution trimestrielle / part</div>
            <div className="mt-1 text-xl font-bold text-white">{numberFormatter(distributionSnapshot?.value ?? null, ' €')}</div>
            <div className="mt-1 text-xs text-slate-400">Variation annuelle à cette date : {formatSigned(distributionSnapshot?.annualDelta ?? null, ' €')}</div>
            {reference(distributionSnapshot)}
          </div>
          <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-4">
            <div className="text-xs text-slate-500">Endettement</div>
            <div className="mt-1 text-xl font-bold text-white">{numberFormatter(debtSnapshot?.value ?? null, ' %')}</div>
            <div className="mt-1 text-xs text-slate-400">Variation annuelle à cette date : {formatSigned(debtSnapshot?.annualDelta ?? null, ' pt')}</div>
            {reference(debtSnapshot)}
          </div>
        </div>

        {activeMetric === 'liquidite' && (
            <p className="mb-4 text-xs leading-5 text-slate-400">
              {liquidity?.regime_changed
                ? 'Changement de régime confirmé : file de retraits et marché secondaire non comparables. '
                : ''}
              {liquidity?.signal_certification === 'suppressed_regime_change_pending_data'
                ? 'Les données du nouveau marché sont en attente ; aucun ratio ni amélioration ne peut être déduit de l’annulation de la file.'
                : !liquidity || !signalGate
                  ? 'Contexte certifié indisponible ; les ratios de liquidité sont masqués.'
                  : 'Les interruptions indiquent des valeurs non renseignées ou des ruptures de méthode. Une base inconnue ne permet pas de calculer un ratio fiable.'}
            </p>
        )}

        <ScpiLeaseDurations scpiSlug={scpiSlug} className="mb-4" />
        <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-4 sm:p-6">
          <div className="mb-4 flex gap-2 overflow-x-auto pb-1">
            {metricTabs.map((tab) => (
              <button
                key={tab.key}
                type="button"
                onClick={() => setActiveMetric(tab.key)}
                className={
                  activeMetric === tab.key
                    ? 'whitespace-nowrap rounded-lg bg-sky-500 px-3 py-2 text-xs font-bold text-slate-950 sm:text-sm'
                    : 'whitespace-nowrap rounded-lg border border-slate-700 bg-slate-950/60 px-3 py-2 text-xs font-semibold text-slate-300 transition hover:border-slate-500 sm:text-sm'
                }
              >
                {tab.label}
              </button>
            ))}
          </div>

          {activeMetric === 'valorisation' && annualChartData.length > 0 && (
            <p className="mb-3 text-xs leading-5 text-slate-400">
              {annualChartData.length === 1
                ? 'Un seul exercice annuel vérifié : un point de valorisation est affiché, sans courbe ni extrapolation. '
                : 'Historique annuel vérifié, valorisations arrêtées au 31 décembre. '}
              Les références plus récentes des bulletins trimestriels figurent séparément ci-dessous :
              elles ne sont pas reportées artificiellement sur les exercices anciens.
            </p>
          )}
          <div className="h-[300px] w-full sm:h-[360px]">{renderChart()}</div>
        </div>
        <ScpiAnnualHistorySection scpiSlug={scpiSlug} />

        <div className="mt-6 overflow-hidden rounded-2xl border border-slate-800 bg-slate-900/60">
          <div className="flex items-center gap-2 border-b border-slate-800 px-4 py-3 text-sm font-semibold text-white sm:px-5">
            <Activity className="h-4 w-4 text-sky-300" />
            Historique vérifiable
          </div>
          <p className="px-4 pt-3 text-xs leading-5 text-slate-400 sm:px-5">
            « N.D. » ou « — » signifie que la valeur n'est pas renseignée ou validée dans MaximusSCPI pour cette période.
            Pour la réalisation et la reconstitution, une valeur antérieure certifiée peut être affichée
            comme « Dernière valeur officielle connue », avec sa date d'arrêté réelle ; elle ne constitue pas
            une nouvelle valorisation du trimestre.
            et non qu'elle est nulle. « Base non documentée » signifie que le mode de liquidité n'est pas identifié.
            Les files de retraits et les marchés secondaires ne sont pas comparés entre eux.
          </p>
          <div className="overflow-x-auto">
            <table className="min-w-[920px] w-full text-left text-sm">
              <thead className="bg-slate-950/70 text-xs uppercase tracking-wide text-slate-500">
                <tr>
                  <th className="px-4 py-3">Période</th>
                  <th className="px-4 py-3 text-right">TOF</th>
                  <th className="px-4 py-3 text-right">Liquidité / base</th>
                  <th className="px-4 py-3 text-right">Prix</th>
                  <th className="px-4 py-3 text-right">Reconstitution</th>
                  <th className="px-4 py-3 text-right">Réalisation</th>
                  <th className="px-4 py-3 text-right">Dette</th>
                  <th className="px-4 py-3">Source</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800 text-slate-300">
                {history
                  .slice(-8)
                  .reverse()
                  .map((row, index) => (
                    <tr key={`${row.source_period || row.snapshot_at}-${index}`} className="hover:bg-slate-800/30">
                      <td className="px-4 py-3 font-semibold text-white">{formatPeriod(row.source_period)}</td>
                      <td className="px-4 py-3 text-right">{numberFormatter(row.tof, ' %')}</td>
                      <td className="px-4 py-3 text-right">
                        {formatLiquidityPercent(row.liquidity_basis === 'secondary_market_order_book' ? row.liquidity_pressure_pct : row.retrait_attente_pct)}
                        <span className="block text-[10px] text-slate-500">{liquidityLabel(row.liquidity_basis)}</span>
                      </td>
                      <td className="px-4 py-3 text-right">{numberFormatter(row.prix_souscription, ' €')}</td>
                      <td className="px-4 py-3 text-right">
                        {numberFormatter(row.prix_reconstitution ?? priorValuation(row, 'prix_reconstitution')?.value ?? null, ' €')}
                        {row.prix_reconstitution !== null && row.metric_provenance?.prix_reconstitution?.reference_date &&
                          <span className="block text-[10px] text-slate-400">Valeur arrêtée au {metricDateLabel(row.metric_provenance.prix_reconstitution.reference_date)}</span>}
                        {row.prix_reconstitution === null && priorValuation(row, 'prix_reconstitution') && (
                          <span className="block text-[10px] text-amber-200">
                            Dernière valeur officielle connue · arrêtée au{' '}
                            {priorValuation(row, 'prix_reconstitution')!.date
                              ? metricDateLabel(priorValuation(row, 'prix_reconstitution')!.date!)
                              : formatPeriod(priorValuation(row, 'prix_reconstitution')!.period)}
                          </span>
                        )}
                      </td>
                      <td className="px-4 py-3 text-right">
                          {numberFormatter(row.valeur_realisation ?? priorValuation(row, 'valeur_realisation')?.value ?? null, ' €')}
                          {row.valeur_realisation === null && priorValuation(row, 'valeur_realisation') && (
                            <span className="block text-[10px] text-amber-200">
                              Dernière valeur officielle connue · arrêtée au{' '}
                              {priorValuation(row, 'valeur_realisation')!.date
                                ? metricDateLabel(priorValuation(row, 'valeur_realisation')!.date!)
                                : formatPeriod(priorValuation(row, 'valeur_realisation')!.period)}
                            </span>
                          )}
                          {row.metric_provenance?.valeur_realisation?.reference_date && <span className="block text-[10px] text-slate-400">Au {metricDateLabel(row.metric_provenance.valeur_realisation.reference_date)}</span>}
                          {!row.metric_provenance?.valeur_realisation && row.valeur_realisation !== null &&
                            annualRows.some(a => a.fiscal_year === 2025
                              && Math.abs(a.valeur_realisation_par_part - row.valeur_realisation!) < 0.001) &&
                            <span className="block text-[10px] text-slate-400">
                              Valorisation arrêtée au 31/12/2025
                            </span>}
                        </td>
                      <td className="px-4 py-3 text-right" title={row.endettement === null ? 'Taux non renseigné ou non validé pour ce trimestre' : 'Taux publié sur la période indiquée'}>{row.endettement === null ? <span className="text-slate-500">—</span> : numberFormatter(row.endettement, ' %')}</td>
                      <td className="px-4 py-3">
                        {row.source_url ? (
                          <a
                            href={row.metric_provenance?.prix_reconstitution?.source_url
                              || row.metric_provenance?.valeur_realisation?.source_url || row.source_url}
                            target="_blank"
                            rel="noreferrer"
                            className="font-medium text-sky-300 hover:text-sky-200"
                          >
                            {(row.metric_provenance?.prix_reconstitution?.source_url
                              || row.metric_provenance?.valeur_realisation?.source_url || row.source_url).includes('francescpi.com/')
                              ? "Document de l'émetteur (copie archivée) ↗" : 'Document officiel ↗'}
                          </a>
                        ) : (
                          <span className="text-slate-600">N.D.</span>
                        )}
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ScpiTrajectoryPanel;
